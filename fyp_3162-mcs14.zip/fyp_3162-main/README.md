## MCS14 FIT3162 Final Year Project (IoT-Based Smart Classroom Monitoring System)

### Project Overview

This project aims to enhance attendance tracking and student engagement in a university classroom setting; more specifically, Monash School of IT. The motivation behind this project stems from the outdated nature and challenges of manual attendance management, and the need for more valuable insights for both educators and students. IoT technologies are increasingly used in education to automate routine tasks and gather and process valuable data. This project will automatically record attendance via facial recognition, track engagement via motion detection, and gather and process data to generate valuable insights accessible via the interactive academic dashboard and personalised report interface. Many solutions focus solely on either attendance or engagement, whereas the proposed system integrates both into a user-friendly system for both lecturers and students.

### Tech Stack
<img src="https://skillicons.dev/icons?i=java" width="40"/>
<img src="https://skillicons.dev/icons?i=react" width="40"/>
<img src="https://skillicons.dev/icons?i=tailwind" width="40"/>
<img src="https://skillicons.dev/icons?i=firebase" width="40"/>

### Exported Database
path: firebase_db.overall_export_metadata

### Git
Personal Git Link (contains env file for deployment): https://github.com/vectorcrusher/fyp_3162
Monash Gitlab Link: https://git.infotech.monash.edu/fit3162_mcs14/FIT3162_MCS14
Note: personal git link is used for deployment purpose as Monash Gitlab link feels like could not be used for external deployment. The zip file source is from personal git. Monash Gitlab source does not contains env file or other configs for deployment but it can be run in local env and it does not contain the latest source code for other new feature when moved to personal git. It is for evidence purpose that each students contributed into the project.

### Setup Instructions

1. **Dependencies required**

   - make sure your node version is v20.20.0
   - make sure you are using java SDK version 17
   - npm install -D tailwindcss postcss autoprefixer
   - npm install react-router-dom recharts
   - npm install lucide-react
2. **Run the Backend Application**:

   - run in http://localhost:8080 by default
   - Path: backend/src/main/java/FypApplication.java
   - press Run
3. **Run Frontend Application**:

   - run in http://localhost:3000 by default
   - Run following command in local terminal:
   - cd frontend/mcs14_frontend
   - npm start

### How to use our App
1. Lecturer Dashboard
   - email: lecturer@lecturer.monash.edu
   - password: 123
2. Student Dashboard
   - email: student@student.monash.edu
   - password: a
   - this will lead to Student A personalized report interface

### Contact

For questions or support, please contact:

- Arielle Dela Cruz: adel0037@student.monash.edu
- Hew Jia Jing: jhew0010@student.monash.edu
- Yu Jia Ming: jyuu0107@student.monash.edu

package com.fyp.mcs14;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FypApplication {

    public static void main(String[] args) {
        SpringApplication.run(FypApplication.class, args);
    }

}

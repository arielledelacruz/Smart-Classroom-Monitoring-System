package com.fyp.mcs14.analytics;

import com.fyp.mcs14.analytics.insights.StudentInsightExplanationEngine;
import com.fyp.mcs14.model.dto.AnalyticsExplanationDTO;
import com.fyp.mcs14.model.dto.RiskBreakdownDTO;
import com.fyp.mcs14.model.model.StudentAnalyticsResult;
import com.fyp.mcs14.model.model.StudentSessionSummary;
import com.fyp.mcs14.model.model.StudentUnitSummary;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class AnalyticsService {

    @Autowired
    private TrendCalculator trendCalc;

    @Autowired
    private RiskCalculator riskCalc;

    @Autowired
    private InsightEngine insightEngine;

    @Autowired
    private StudentInsightExplanationEngine studentInsightExplanationEngine;

    /**
     * Analyzes a student's attendance data for a unit semester
     *
     * @param summary the aggregated student unit summary
     * @return the computed StudentAnalyticsResult
     */
    public StudentAnalyticsResult analyzeStudentAnalytics(StudentUnitSummary summary) {
        log.info("Analyzing student: {} for unit: {}",
                summary.getStudentId(),
                summary.getUnitYearSemesterId().generateUniqueId());

        // --- 1. Trend Slope ---
        double slope = trendCalc.compute(summary.getSessions());

        // --- 2. Consecutive Absences ---
        int consecutiveAbs = maxConsecutiveAbsence(summary.getSessions());

        // --- 3. Risk Score ---
//        double risk = riskCalc.compute(
//                summary.getAttendanceRate(),
//                consecutiveAbs,
//                slope,
//                summary.getAvgPresenceQuality(),
//                summary.getAvgEngagementScore()
//        );

        RiskBreakdownDTO riskBreakdown = riskCalc.computeBreakdown(
                summary.getAttendanceRate(),
                consecutiveAbs,
                slope,
                summary.getAvgPresenceQuality(),
                summary.getAvgEngagementScore()
        );

        double risk = riskBreakdown.getFinalRiskScore();

        // --- 4. Insights ---
        List<String> insights = insightEngine.generate(
                summary.getAttendanceRate(),
                slope,
                summary.getAvgEngagementScore(),
                summary.getAvgPresenceQuality(),
                consecutiveAbs,
                risk
        );

        // --- 5. Explanation (Insights) ---
        List<AnalyticsExplanationDTO> explanations = studentInsightExplanationEngine.explain(
                summary.getAttendanceRate(),
                summary.getAvgEngagementScore(),
                summary.getAvgPresenceQuality(),
                slope,
                consecutiveAbs,
                risk
        );


        log.debug("Student: {} riskScore: {} attendanceRate: {}",
                summary.getStudentId(), risk, summary.getAttendanceRate());

        return StudentAnalyticsResult.builder()
                .studentId(summary.getStudentId())
                .attendanceRate(summary.getAttendanceRate())
                .engagementScore(summary.getAvgEngagementScore())
                .effectivePresence(summary.getAvgPresenceQuality())
                .trendSlope(slope)
                .consecutiveAbsences(consecutiveAbs)
                .riskScore(risk)
                .riskBreakdown(riskBreakdown)
                .insights(insights)
                .totalEarlyDeparture(summary.getTotalEarlyDeparture())
                .totalLateArrival(summary.getTotalLateArrival())
                .explanations(explanations)
                .build();
    }


    private int maxConsecutiveAbsence(List<StudentSessionSummary> sessions) {
        int max = 0, current = 0;
        for (StudentSessionSummary s : sessions) {
            if (!s.isPresent()) {
                current++;
                max = Math.max(max, current);
            } else {
                current = 0;
            }
        }
        return max;
    }
}

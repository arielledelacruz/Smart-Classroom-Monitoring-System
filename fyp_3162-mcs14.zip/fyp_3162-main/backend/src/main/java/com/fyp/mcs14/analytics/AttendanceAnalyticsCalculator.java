package com.fyp.mcs14.analytics;

import org.springframework.stereotype.Component;

@Component
public class AttendanceAnalyticsCalculator {


}

package com.fyp.mcs14.analytics;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class InsightEngine {

    public List<String> generate(double attendance,
                                 double slope,
                                 double engagement,
                                 double presence,
                                 int consecutiveAbs,
                                 double risk) {

        List<String> insights = new ArrayList<>();

        if (attendance < 0.6)
            insights.add("Low attendance across sessions");

        if (slope < -0.05)
            insights.add("Attendance trend declining");

        if (consecutiveAbs >= 3)
            insights.add("Repeated absence pattern");

        if (engagement < 0.3)
            insights.add("Low classroom interaction detected");

        if (presence < 0.6)
            insights.add("Short participation duration in sessions");

        if (risk > 0.7)
            insights.add("High risk student - intervention recommended");

        return insights;
    }
}
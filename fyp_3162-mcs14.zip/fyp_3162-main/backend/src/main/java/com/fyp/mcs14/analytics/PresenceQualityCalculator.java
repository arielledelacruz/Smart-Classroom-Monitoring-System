package com.fyp.mcs14.analytics;

import com.fyp.mcs14.model.model.excel.RawAttendanceRecord;
import org.springframework.stereotype.Component;

@Component
public class PresenceQualityCalculator {
    public double compute(RawAttendanceRecord record, int startTime, int endTime) {

        if (record.getRecords().isEmpty()) return 0;

        double sessionDuration = record.getSessionDuration();
        double activeDuration = record.getRecords().size();

        return Math.max(0, activeDuration / sessionDuration);
    }
}

package com.fyp.mcs14.analytics;

import com.fyp.mcs14.model.dto.RiskBreakdownDTO;
import org.springframework.stereotype.Component;

@Component
public class RiskCalculator {

    public RiskBreakdownDTO computeBreakdown(double attendanceRate,
                                             int consecutiveAbs,
                                             double slope,
                                             double presence,
                                             double engagement) {

        double attendanceRisk = (1 - attendanceRate) * 0.3;
        double absenceRisk = Math.min(consecutiveAbs / 5.0, 1.0) * 0.2;
        double trendRisk = (slope < 0 ? Math.abs(slope) : 0) * 0.2;
        double presenceRisk = (1 - presence) * 0.15;
        double engagementRisk = (1 - engagement) * 0.15;

        double finalRiskScore =
                attendanceRisk +
                        absenceRisk +
                        trendRisk +
                        presenceRisk +
                        engagementRisk;

        return RiskBreakdownDTO.builder()
                .attendanceRisk(attendanceRisk)
                .absenceRisk(absenceRisk)
                .trendRisk(trendRisk)
                .presenceRisk(presenceRisk)
                .engagementRisk(engagementRisk)
                .finalRiskScore(finalRiskScore)
                .build();
    }
}

package com.fyp.mcs14.analytics;

import com.fyp.mcs14.model.model.StudentSessionSummary;
import com.fyp.mcs14.model.model.excel.RawAttendanceRecord;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class TrendCalculator {

    /**
     * Computes the trend slope of attendance over sessions using linear regression
     * Positive slope = improving attendance, Negative slope = declining attendance
     *
     * @param sessions ordered list of session summaries
     * @return the trend slope
     */
    public double compute(List<StudentSessionSummary> sessions) {
        int n = sessions.size();
        double sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;

        for (int i = 0; i < n; i++) {
            double x = i + 1;
            double y = sessions.get(i).isPresent() ? 1 : 0;
            sumX  += x;
            sumY  += y;
            sumXY += x * y;
            sumX2 += x * x;
        }

        double denom = (n * sumX2 - sumX * sumX);
        return denom == 0 ? 0 : (n * sumXY - sumX * sumY) / denom;
    }
}

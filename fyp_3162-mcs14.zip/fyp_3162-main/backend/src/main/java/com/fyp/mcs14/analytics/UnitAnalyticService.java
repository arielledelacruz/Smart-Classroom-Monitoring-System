package com.fyp.mcs14.analytics;

import com.fyp.mcs14.model.dataobject.UnitAnalyticsSummaryDO;
import com.fyp.mcs14.model.model.StudentAnalyticsResult;
import com.fyp.mcs14.repository.UnitAnalyticsSummaryRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class UnitAnalyticService {

    @Autowired
    private UnitAnalyticsSummaryRepository unitAnalyticsSummaryRepository;

    public UnitAnalyticsSummaryDO getByUnitSemesterId(String unitSemesterId) {
        log.info("getByUnitSemesterId - unit: {}", unitSemesterId);
        return unitAnalyticsSummaryRepository.getByUnitSemesterId(unitSemesterId);
    }

    /**
     * Computes and saves unit-level analytics from student analytics results and clusters
     *
     * @param unitSemesterId   the unit semester id
     * @param analyticsResults list of student analytics results
     * @param clusters         map of studentId to cluster label
     */
    public void computeAndSave(String unitSemesterId,
                               List<StudentAnalyticsResult> analyticsResults,
                               Map<String, String> clusters) {
        log.info("computeAndSave unit analytics - unit: {}", unitSemesterId);

        UnitAnalyticsSummaryDO summaryDO = compute(unitSemesterId, analyticsResults, clusters);
        unitAnalyticsSummaryRepository.save(summaryDO);

        log.info("unit analytics saved - unit: {}", unitSemesterId);
    }

    /**
     * Computes unit-level analytics from student analytics results and clusters
     *
     * @param unitSemesterId   the unit semester id
     * @param analyticsResults list of student analytics results
     * @param clusters         map of studentId to cluster label
     * @return the computed UnitAnalyticsSummaryDO
     */
    private UnitAnalyticsSummaryDO compute(String unitSemesterId,
                                           List<StudentAnalyticsResult> analyticsResults,
                                           Map<String, String> clusters) {
        int totalStudents = analyticsResults.size();

        // ── Averages ───────────────────────────────────────────────────────
        double avgAttendanceRate = analyticsResults.stream()
                .mapToDouble(StudentAnalyticsResult::getAttendanceRate)
                .average().orElse(0);

        double avgEngagementScore = analyticsResults.stream()
                .mapToDouble(StudentAnalyticsResult::getEngagementScore)
                .average().orElse(0);

        double avgPresenceQuality = analyticsResults.stream()
                .mapToDouble(StudentAnalyticsResult::getEffectivePresence)
                .average().orElse(0);

        double avgRiskScore = analyticsResults.stream()
                .mapToDouble(StudentAnalyticsResult::getRiskScore)
                .average().orElse(0);

        double avgTrendSlope = analyticsResults.stream()
                .mapToDouble(StudentAnalyticsResult::getTrendSlope)
                .average().orElse(0);

        // ── Totals ─────────────────────────────────────────────────────────
        int totalLateArrival = analyticsResults.stream()
                .mapToInt(StudentAnalyticsResult::getTotalLateArrival)
                .sum();

        int totalEarlyDeparture = analyticsResults.stream()
                .mapToInt(StudentAnalyticsResult::getTotalEarlyDeparture)
                .sum();

        // ── Risk Distribution ──────────────────────────────────────────────
        int highRiskCount = (int) analyticsResults.stream()
                .filter(r -> r.getRiskScore() >= 0.7).count();

        int mediumRiskCount = (int) analyticsResults.stream()
                .filter(r -> r.getRiskScore() >= 0.4 && r.getRiskScore() < 0.7).count();

        int lowRiskCount = (int) analyticsResults.stream()
                .filter(r -> r.getRiskScore() < 0.4).count();

        // ── Cluster Distribution ───────────────────────────────────────────
        Map<String, Integer> clusterDistribution = new HashMap<>();
        clusters.values().forEach(label ->
                clusterDistribution.merge(label, 1, Integer::sum)
        );

        log.debug("unit: {} - avgAttendance: {} avgEngagement: {} avgRisk: {} highRisk: {}",
                unitSemesterId, avgAttendanceRate, avgEngagementScore, avgRiskScore, highRiskCount);

        return UnitAnalyticsSummaryDO.builder()
                .unitSemesterId(unitSemesterId)
                .totalStudents(totalStudents)
                .avgAttendanceRate(avgAttendanceRate)
                .avgEngagementScore(avgEngagementScore)
                .avgPresenceQuality(avgPresenceQuality)
                .avgRiskScore(avgRiskScore)
                .avgTrendSlope(avgTrendSlope)
                .totalLateArrival(totalLateArrival)
                .totalEarlyDeparture(totalEarlyDeparture)
                .highRiskCount(highRiskCount)
                .mediumRiskCount(mediumRiskCount)
                .lowRiskCount(lowRiskCount)
                .clusterDistribution(clusterDistribution)
                .build();
    }
}
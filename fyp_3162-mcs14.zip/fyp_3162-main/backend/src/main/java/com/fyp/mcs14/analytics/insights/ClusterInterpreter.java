package com.fyp.mcs14.analytics.insights;

import org.springframework.stereotype.Component;

@Component
public class ClusterInterpreter {
    public String interpret(double[] centroid) {

        double attendance = centroid[0];
        double engagement = centroid[1];

        if (attendance > 0.7 && engagement > 0.6)
            return "Engaged";

        if (attendance > 0.7)
            return "Passive";

        if (engagement > 0.6)
            return "Independent";

        return "At Risk";
    }
}

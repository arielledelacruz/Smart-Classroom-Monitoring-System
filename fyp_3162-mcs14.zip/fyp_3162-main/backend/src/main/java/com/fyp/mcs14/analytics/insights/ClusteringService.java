package com.fyp.mcs14.analytics.insights;

import com.fyp.mcs14.analytics.AnalyticsService;
import com.fyp.mcs14.model.model.ClusterPoint;
import com.fyp.mcs14.model.model.StudentAnalyticsResult;
import com.fyp.mcs14.model.model.StudentUnitSummary;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class ClusteringService {

    @Autowired
    private AnalyticsService analyticsService;

    @Autowired
    private KMeansClustering kmeans;

    @Autowired
    private ClusterInterpreter interpreter;

    /**
     * Clusters students based on their analytics results
     *
     * @param summaries list of student unit summaries for all students in a unit
     * @return map of studentId to cluster label
     */
    public Map<String, String> clusterStudents(List<StudentUnitSummary> summaries) {
        log.info("Start clustering students: {}", summaries);
        List<ClusterPoint> points = new ArrayList<>();

        // Step 1: compute analytics per student
        for (StudentUnitSummary summary : summaries) {
            StudentAnalyticsResult result = analyticsService.analyzeStudentAnalytics(summary);

            double[] features = new double[]{
                    result.getAttendanceRate(),
                    result.getEngagementScore(),
                    result.getTrendSlope(),
                    result.getEffectivePresence()
            };

            points.add(new ClusterPoint(summary.getStudentId(), features, -1));
        }

        // Step 2: run clustering
        List<ClusterPoint> clustered = kmeans.cluster(points, 4);

        // Step 3: interpret clusters
        Map<String, String> result = new HashMap<>();
        for (ClusterPoint p : clustered) {
            result.put(p.getStudentId(), interpreter.interpret(p.getFeatures()));
            //             double[] centroid = kmeans.getCentroid(p.getCluster());
            //            result.put(p.getStudentId(), interpreter.interpret(centroid));
        }

        return result;
    }
}

package com.fyp.mcs14.analytics.insights;

import com.fyp.mcs14.model.dataobject.MotionRecordDO;
import com.fyp.mcs14.model.enums.MotionTypeEnum;
import com.fyp.mcs14.model.model.excel.MotionRecord;
import com.fyp.mcs14.model.model.excel.RawAttendanceRecord;
import org.springframework.stereotype.Component;

@Component
public class EngagementCalculator {
    public double compute(RawAttendanceRecord record) {

        double weightedSum = 0;
        double total = 0;

        for (MotionRecord r : record.getRecords()) {

            double weight = switch (r.getMotionType()) {
                case SITTING -> 0.2;
                case STANDING -> 0.4;
                case RAISING_HAND -> 1.0;
            };

            weightedSum += weight * r.getNumberOfMotion();
            total += r.getNumberOfMotion();
        }

        if (total == 0) return 0;

        return weightedSum / total;
    }
}

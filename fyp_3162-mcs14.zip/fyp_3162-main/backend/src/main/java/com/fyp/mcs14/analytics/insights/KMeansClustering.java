package com.fyp.mcs14.analytics.insights;

import com.fyp.mcs14.model.model.ClusterPoint;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Component
public class KMeansClustering {
    private static final int MAX_ITER = 100;
    private List<double[]> finalCentroids;

    public List<ClusterPoint> cluster(List<ClusterPoint> points, int k) {

        List<double[]> centroids = initCentroids(points, k);

        for (int iter = 0; iter < MAX_ITER; iter++) {

            // Step 1: assign clusters
            for (ClusterPoint p : points) {
                p.setCluster(nearestCentroid(p.getFeatures(), centroids));
            }

            // Step 2: recompute centroids
            List<double[]> newCentroids = recomputeCentroids(points, k);

            if (converged(centroids, newCentroids)) break;

            centroids = newCentroids;
        }

        this.finalCentroids = centroids;
        return points;
    }

    public double[] getCentroid(int clusterIndex) {
        return finalCentroids.get(clusterIndex);
    }

    private double distance(double[] a, double[] b) {
        double sum = 0;
        for (int i = 0; i < a.length; i++) {
            sum += Math.pow(a[i] - b[i], 2);
        }
        return Math.sqrt(sum);
    }

    private int nearestCentroid(double[] point, List<double[]> centroids) {

        double minDist = Double.MAX_VALUE;
        int index = 0;

        for (int i = 0; i < centroids.size(); i++) {
            double dist = distance(point, centroids.get(i));
            if (dist < minDist) {
                minDist = dist;
                index = i;
            }
        }
        return index;
    }

    private List<double[]> initCentroids(List<ClusterPoint> points, int k) {

        List<double[]> centroids = new ArrayList<>();
        Random rand = new Random();

        for (int i = 0; i < k; i++) {
            centroids.add(points.get(rand.nextInt(points.size())).getFeatures());
        }

        return centroids;
    }

    private List<double[]> recomputeCentroids(List<ClusterPoint> points, int k) {

        int dim = points.get(0).getFeatures().length;
        double[][] sums = new double[k][dim];
        int[] counts = new int[k];

        for (ClusterPoint p : points) {
            int c = p.getCluster();
            counts[c]++;
            for (int i = 0; i < dim; i++) {
                sums[c][i] += p.getFeatures()[i];
            }
        }

        List<double[]> centroids = new ArrayList<>();

        for (int i = 0; i < k; i++) {
            double[] centroid = new double[dim];
            if (counts[i] == 0) continue;

            for (int j = 0; j < dim; j++) {
                centroid[j] = sums[i][j] / counts[i];
            }
            centroids.add(centroid);
        }

        return centroids;
    }

    private boolean converged(List<double[]> oldC, List<double[]> newC) {

        double threshold = 0.001;

        for (int i = 0; i < oldC.size(); i++) {
            if (distance(oldC.get(i), newC.get(i)) > threshold) {
                return false;
            }
        }
        return true;
    }
}

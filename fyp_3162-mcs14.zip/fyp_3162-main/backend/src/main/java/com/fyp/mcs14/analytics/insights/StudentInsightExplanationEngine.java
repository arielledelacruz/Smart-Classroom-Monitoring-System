package com.fyp.mcs14.analytics.insights;


import com.fyp.mcs14.model.dto.AnalyticsExplanationDTO;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class StudentInsightExplanationEngine {

    public List<AnalyticsExplanationDTO> explain(double attendance,
                                                 double engagement,
                                                 double presence,
                                                 double slope,
                                                 int consecutiveAbsences,
                                                 double risk) {

        List<AnalyticsExplanationDTO> explanations = new ArrayList<>();

        explanations.add(explainAttendance(attendance, consecutiveAbsences));
        explanations.add(explainEngagement(engagement));
        explanations.add(explainPresence(presence));
        explanations.add(explainTrend(slope));
        explanations.add(explainRisk(risk));

        return explanations;
    }

    private AnalyticsExplanationDTO explainAttendance(double attendance, int consecutiveAbsences) {
        String status;
        String meaning;
        String studentRec;
        String lecturerRec;

        if (attendance < 0.6) {
            status = "Low";
            meaning = "The student attended fewer sessions than expected.";
            studentRec = "Attend upcoming sessions consistently to improve attendance rate.";
            lecturerRec = "Monitor the student and consider early intervention.";
        } else if (attendance < 0.8) {
            status = "Moderate";
            meaning = "The student attended some sessions but attendance consistency can improve.";
            studentRec = "Avoid missing consecutive sessions.";
            lecturerRec = "Continue monitoring attendance consistency.";
        } else {
            status = "Good";
            meaning = "The student shows consistent attendance.";
            studentRec = "Maintain current attendance pattern.";
            lecturerRec = "No immediate attendance intervention required.";
        }

        return AnalyticsExplanationDTO.builder()
                .metricName("Attendance Rate")
                .value(attendance)
                .status(status)
                .meaning(meaning)
                .contributingFactor("Consecutive absences: " + consecutiveAbsences)
                .recommendationForStudent(studentRec)
                .recommendationForLecturer(lecturerRec)
                .build();
    }

    private AnalyticsExplanationDTO explainEngagement(double engagement) {
        String status;
        String meaning;
        String studentRec;
        String lecturerRec;

        if (engagement < 0.3) {
            status = "Low";
            meaning = "The student has limited active classroom interaction.";
            studentRec = "Increase active participation such as standing, responding, or raising hand.";
            lecturerRec = "Encourage the student through interactive questions or group activities.";
        } else if (engagement < 0.6) {
            status = "Moderate";
            meaning = "The student shows some engagement but not consistently.";
            studentRec = "Participate more frequently during learning activities.";
            lecturerRec = "Use engagement prompts to increase participation.";
        } else {
            status = "Good";
            meaning = "The student demonstrates active engagement.";
            studentRec = "Maintain active participation.";
            lecturerRec = "Use this student pattern as a positive engagement reference.";
        }

        return AnalyticsExplanationDTO.builder()
                .metricName("Engagement Score")
                .value(engagement)
                .status(status)
                .meaning(meaning)
                .contributingFactor("Calculated from weighted motion types such as sitting, standing, and raising hand.")
                .recommendationForStudent(studentRec)
                .recommendationForLecturer(lecturerRec)
                .build();
    }

    private AnalyticsExplanationDTO explainPresence(double presence) {
        String status;
        String meaning;
        String studentRec;
        String lecturerRec;

        if (presence < 0.6) {
            status = "Low";
            meaning = "The student was detected for a shorter duration within the session.";
            studentRec = "Stay for the full session duration where possible.";
            lecturerRec = "Check whether the student often arrives late or leaves early.";
        } else if (presence < 0.8) {
            status = "Moderate";
            meaning = "The student was present for most but not all of the expected duration.";
            studentRec = "Improve session completion consistency.";
            lecturerRec = "Monitor late arrival and early departure patterns.";
        } else {
            status = "Good";
            meaning = "The student stayed for most of the session duration.";
            studentRec = "Maintain consistent session presence.";
            lecturerRec = "No immediate presence issue detected.";
        }

        return AnalyticsExplanationDTO.builder()
                .metricName("Effective Presence")
                .value(presence)
                .status(status)
                .meaning(meaning)
                .contributingFactor("Based on detected activity duration compared with expected session duration.")
                .recommendationForStudent(studentRec)
                .recommendationForLecturer(lecturerRec)
                .build();
    }

    private AnalyticsExplanationDTO explainTrend(double slope) {
        String status;
        String meaning;
        String studentRec;
        String lecturerRec;

        if (slope < -0.05) {
            status = "Declining";
            meaning = "Attendance pattern is decreasing across sessions.";
            studentRec = "Avoid further absence and improve consistency in upcoming sessions.";
            lecturerRec = "Review recent sessions and contact the student if decline continues.";
        } else if (slope > 0.05) {
            status = "Improving";
            meaning = "Attendance pattern is improving over time.";
            studentRec = "Continue the positive attendance improvement.";
            lecturerRec = "Reinforce the improvement with positive feedback.";
        } else {
            status = "Stable";
            meaning = "Attendance pattern does not show major increase or decrease.";
            studentRec = "Maintain stable attendance.";
            lecturerRec = "Continue regular monitoring.";
        }

        return AnalyticsExplanationDTO.builder()
                .metricName("Attendance Trend")
                .value(slope)
                .status(status)
                .meaning(meaning)
                .contributingFactor("Computed using linear regression over session attendance records.")
                .recommendationForStudent(studentRec)
                .recommendationForLecturer(lecturerRec)
                .build();
    }

    private AnalyticsExplanationDTO explainRisk(double risk) {
        String status;
        String meaning;
        String studentRec;
        String lecturerRec;

        if (risk >= 0.7) {
            status = "High Risk";
            meaning = "The student has multiple negative indicators.";
            studentRec = "Prioritize attendance consistency and active participation.";
            lecturerRec = "Intervention is recommended.";
        } else if (risk >= 0.4) {
            status = "Medium Risk";
            meaning = "The student has some warning indicators.";
            studentRec = "Improve weak areas before risk increases.";
            lecturerRec = "Monitor the student more closely.";
        } else {
            status = "Low Risk";
            meaning = "The student currently shows acceptable attendance and engagement.";
            studentRec = "Maintain current learning behavior.";
            lecturerRec = "No urgent intervention required.";
        }

        return AnalyticsExplanationDTO.builder()
                .metricName("Risk Score")
                .value(risk)
                .status(status)
                .meaning(meaning)
                .contributingFactor("Risk combines attendance, absence pattern, trend, presence quality, and engagement.")
                .recommendationForStudent(studentRec)
                .recommendationForLecturer(lecturerRec)
                .build();
    }
}

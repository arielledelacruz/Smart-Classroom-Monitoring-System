package com.fyp.mcs14.common;

import java.util.Collection;
import java.util.Map;
import java.util.Objects;

/**
 * Utility class providing static assertion methods for use in tests or
 * defensive programming. Throws {@link AssertionError} on failure with
 * descriptive messages.
 */
public final class AssertUtil {

    private AssertUtil() {
        throw new UnsupportedOperationException("Utility class");
    }

    // -------------------------------------------------------------------------
    // Equality
    // -------------------------------------------------------------------------

    /** Asserts that actual equals expected. */
    public static void assertEquals(Object expected, Object actual) {
        assertEquals(expected, actual, null);
    }

    /** Asserts that actual equals expected, with a custom message. */
    public static void assertEquals(Object expected, Object actual, String message) {
        if (!Objects.equals(expected, actual)) {
            fail(message, "Expected <%s> but was <%s>", expected, actual);
        }
    }

    /** Asserts that actual does NOT equal unexpected. */
    public static void assertNotEquals(Object unexpected, Object actual) {
        assertNotEquals(unexpected, actual, null);
    }

    /** Asserts that actual does NOT equal unexpected, with a custom message. */
    public static void assertNotEquals(Object unexpected, Object actual, String message) {
        if (Objects.equals(unexpected, actual)) {
            fail(message, "Expected values to differ but both were <%s>", actual);
        }
    }

    // -------------------------------------------------------------------------
    // Null checks
    // -------------------------------------------------------------------------

    /** Asserts that value is null. */
    public static void assertNull(Object value) {
        assertNull(value, null);
    }

    /** Asserts that value is null, with a custom message. */
    public static void assertNull(Object value, String message) {
        if (value != null) {
            fail(message, "Expected null but was <%s>", value);
        }
    }

    /** Asserts that value is not null. */
    public static void assertNotNull(Object value) {
        assertNotNull(value, null);
    }

    /** Asserts that value is not null, with a custom message. */
    public static void assertNotNull(Object value, String message) {
        if (value == null) {
            fail(message, "Expected non-null value but got null");
        }
    }

    // -------------------------------------------------------------------------
    // Boolean
    // -------------------------------------------------------------------------

    /** Asserts that condition is true. */
    public static void assertTrue(boolean condition) {
        assertTrue(condition, null);
    }

    /** Asserts that condition is true, with a custom message. */
    public static void assertTrue(boolean condition, String message) {
        if (!condition) {
            fail(message, "Expected condition to be true");
        }
    }

    /** Asserts that condition is false. */
    public static void assertFalse(boolean condition) {
        assertFalse(condition, null);
    }

    /** Asserts that condition is false, with a custom message. */
    public static void assertFalse(boolean condition, String message) {
        if (condition) {
            fail(message, "Expected condition to be false");
        }
    }

    // -------------------------------------------------------------------------
    // Reference equality
    // -------------------------------------------------------------------------

    /** Asserts that expected and actual are the same object reference. */
    public static void assertSame(Object expected, Object actual) {
        assertSame(expected, actual, null);
    }

    /** Asserts that expected and actual are the same object reference, with a custom message. */
    public static void assertSame(Object expected, Object actual, String message) {
        if (expected != actual) {
            fail(message, "Expected same instance but got <%s> vs <%s>", expected, actual);
        }
    }

    /** Asserts that expected and actual are NOT the same object reference. */
    public static void assertNotSame(Object unexpected, Object actual) {
        assertNotSame(unexpected, actual, null);
    }

    /** Asserts that expected and actual are NOT the same object reference, with a custom message. */
    public static void assertNotSame(Object unexpected, Object actual, String message) {
        if (unexpected == actual) {
            fail(message, "Expected different instances but got the same reference <%s>", actual);
        }
    }

    // -------------------------------------------------------------------------
    // Numeric ranges
    // -------------------------------------------------------------------------

    /** Asserts that value is greater than min (exclusive). */
    public static void assertGreaterThan(double min, double value) {
        assertGreaterThan(min, value, null);
    }

    /** Asserts that value is greater than min (exclusive), with a custom message. */
    public static void assertGreaterThan(double min, double value, String message) {
        if (value <= min) {
            fail(message, "Expected value > %s but was %s", min, value);
        }
    }

    /** Asserts that value is less than max (exclusive). */
    public static void assertLessThan(double max, double value) {
        assertLessThan(max, value, null);
    }

    /** Asserts that value is less than max (exclusive), with a custom message. */
    public static void assertLessThan(double max, double value, String message) {
        if (value >= max) {
            fail(message, "Expected value < %s but was %s", max, value);
        }
    }

    /** Asserts that value is within [min, max] inclusive. */
    public static void assertInRange(double min, double max, double value) {
        assertInRange(min, max, value, null);
    }

    /** Asserts that value is within [min, max] inclusive, with a custom message. */
    public static void assertInRange(double min, double max, double value, String message) {
        if (value < min || value > max) {
            fail(message, "Expected value in [%s, %s] but was %s", min, max, value);
        }
    }

    /** Asserts that two doubles are equal within a given delta tolerance. */
    public static void assertEquals(double expected, double actual, double delta) {
        assertEquals(expected, actual, delta, null);
    }

    /** Asserts that two doubles are equal within a given delta tolerance, with a custom message. */
    public static void assertEquals(double expected, double actual, double delta, String message) {
        if (Math.abs(expected - actual) > delta) {
            fail(message, "Expected <%s> within delta <%s> but was <%s>", expected, delta, actual);
        }
    }

    // -------------------------------------------------------------------------
    // Strings
    // -------------------------------------------------------------------------

    /** Asserts that the string is not null and not empty. */
    public static void assertNotEmpty(String value) {
        assertNotEmpty(value, null);
    }

    /** Asserts that the string is not null and not empty, with a custom message. */
    public static void assertNotEmpty(String value, String message) {
        if (value == null || value.isEmpty()) {
            fail(message, "Expected non-empty string but was <%s>", value);
        }
    }

    /** Asserts that the string contains the given substring. */
    public static void assertContains(String substring, String actual) {
        assertContains(substring, actual, null);
    }

    /** Asserts that the string contains the given substring, with a custom message. */
    public static void assertContains(String substring, String actual, String message) {
        assertNotNull(actual, "Actual string must not be null");
        if (!actual.contains(substring)) {
            fail(message, "Expected <%s> to contain <%s>", actual, substring);
        }
    }

    /** Asserts that the string starts with the given prefix. */
    public static void assertStartsWith(String prefix, String actual) {
        assertStartsWith(prefix, actual, null);
    }

    /** Asserts that the string starts with the given prefix, with a custom message. */
    public static void assertStartsWith(String prefix, String actual, String message) {
        assertNotNull(actual, "Actual string must not be null");
        if (!actual.startsWith(prefix)) {
            fail(message, "Expected <%s> to start with <%s>", actual, prefix);
        }
    }

    /** Asserts that the string ends with the given suffix. */
    public static void assertEndsWith(String suffix, String actual) {
        assertEndsWith(suffix, actual, null);
    }

    /** Asserts that the string ends with the given suffix, with a custom message. */
    public static void assertEndsWith(String suffix, String actual, String message) {
        assertNotNull(actual, "Actual string must not be null");
        if (!actual.endsWith(suffix)) {
            fail(message, "Expected <%s> to end with <%s>", actual, suffix);
        }
    }

    // -------------------------------------------------------------------------
    // Collections
    // -------------------------------------------------------------------------

    /** Asserts that the collection is not null and not empty. */
    public static void assertNotEmpty(Collection<?> collection) {
        assertNotEmpty(collection, null);
    }

    /** Asserts that the collection is not null and not empty, with a custom message. */
    public static void assertNotEmpty(Collection<?> collection, String message) {
        if (collection == null || collection.isEmpty()) {
            fail(message, "Expected non-empty collection");
        }
    }

    /** Asserts that the collection has exactly the expected size. */
    public static void assertSize(int expectedSize, Collection<?> collection) {
        assertSize(expectedSize, collection, null);
    }

    /** Asserts that the collection has exactly the expected size, with a custom message. */
    public static void assertSize(int expectedSize, Collection<?> collection, String message) {
        assertNotNull(collection, "Collection must not be null");
        if (collection.size() != expectedSize) {
            fail(message, "Expected collection of size <%d> but was <%d>", expectedSize, collection.size());
        }
    }

    /** Asserts that the collection contains the given element. */
    public static void assertContains(Object element, Collection<?> collection) {
        assertContains(element, collection, null);
    }

    /** Asserts that the collection contains the given element, with a custom message. */
    public static void assertContains(Object element, Collection<?> collection, String message) {
        assertNotNull(collection, "Collection must not be null");
        if (!collection.contains(element)) {
            fail(message, "Expected collection to contain <%s>", element);
        }
    }

    // -------------------------------------------------------------------------
    // Maps
    // -------------------------------------------------------------------------

    /** Asserts that the map contains the given key. */
    public static void assertContainsKey(Object key, Map<?, ?> map) {
        assertContainsKey(key, map, null);
    }

    /** Asserts that the map contains the given key, with a custom message. */
    public static void assertContainsKey(Object key, Map<?, ?> map, String message) {
        assertNotNull(map, "Map must not be null");
        if (!map.containsKey(key)) {
            fail(message, "Expected map to contain key <%s>", key);
        }
    }

    // -------------------------------------------------------------------------
    // Exception throwing
    // -------------------------------------------------------------------------

    /**
     * Asserts that the given {@link Runnable} throws an exception of the expected type.
     *
     * @return the caught exception for further inspection
     */
    public static <T extends Throwable> T assertThrows(Class<T> expectedType, Runnable runnable) {
        return assertThrows(expectedType, runnable, null);
    }

    /**
     * Asserts that the given {@link Runnable} throws an exception of the expected type,
     * with a custom message.
     *
     * @return the caught exception for further inspection
     */
    @SuppressWarnings("unchecked")
    public static <T extends Throwable> T assertThrows(Class<T> expectedType, Runnable runnable, String message) {
        try {
            runnable.run();
        } catch (Throwable t) {
            if (!expectedType.isInstance(t)) {
                fail(message, "Expected <%s> to be thrown but got <%s>",
                        expectedType.getSimpleName(), t.getClass().getSimpleName());
            }
            return (T) t;
        }
        fail(message, "Expected <%s> to be thrown but nothing was thrown", expectedType.getSimpleName());
        return null; // unreachable
    }

    // -------------------------------------------------------------------------
    // Unconditional failure
    // -------------------------------------------------------------------------

    /** Always fails with the given message. */
    public static void fail(String message) {
        throw new AssertionError(message != null ? message : "Assertion failed");
    }

    // -------------------------------------------------------------------------
    // Internal helpers
    // -------------------------------------------------------------------------

    private static void fail(String customMessage, String defaultFormat, Object... args) {
        String defaultMessage = String.format(defaultFormat, args);
        String fullMessage = customMessage != null
                ? customMessage + " — " + defaultMessage
                : defaultMessage;
        throw new AssertionError(fullMessage);
    }
}

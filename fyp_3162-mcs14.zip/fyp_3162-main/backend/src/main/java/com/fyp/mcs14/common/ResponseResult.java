package com.fyp.mcs14.common;

import com.fyp.mcs14.model.enums.ResponseStatusEnum;
import lombok.Data;

/**
 * Generic class to represent a standardised API response returned to the frontend
 */
@Data
public class ResponseResult<T> {

    /**
     * Status of the API response
     * e.g. SUCCESS, FAILURE
     */
    private ResponseStatusEnum responseStatus;

    /**
     * Body of the API response containing the returned data
     */
    private T responseBody;

    /**
     * Constructor to create a response result with a status and response body
     *
     * @param responseResultEnum the status of the response
     * @param responseBody the data to be returned in the response
     */
    public ResponseResult(ResponseStatusEnum responseResultEnum, T responseBody){
        this.responseStatus = responseResultEnum;
        this.responseBody = responseBody;
    }

    public static <T> ResponseResult<T> success(T t) {
        return new ResponseResult<>(ResponseStatusEnum.SUCCESS, t);
    }

    public static <T> ResponseResult<T> fail(T t) {
        return new ResponseResult<>(ResponseStatusEnum.FAIL, t);
    }
}

package com.fyp.mcs14.controller;

import com.fyp.mcs14.model.converter.DashboardConverter;
import com.fyp.mcs14.model.dto.dashboard.*;
import com.fyp.mcs14.model.dto.LecturerUnitsDTO;
import com.fyp.mcs14.model.model.dashboard.DashboardFilterRequest;
import com.fyp.mcs14.common.ResponseResult;
import com.fyp.mcs14.service.DashboardService;
import com.fyp.mcs14.service.UnitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;
import java.util.List;

@RestController
public class AcademicDashboardController {

    @Autowired
    private DashboardService dashboardService;

    @Autowired
    private UnitService unitService;

    @PostMapping("/dashboard/query_filter_data")
    public ResponseResult<DashboardUnitAttendanceSummaryResponseDTO> getDashboardData(@RequestBody DashboardFilterRequestDTO dto) {
        DashboardFilterRequest model = DashboardConverter.convertFilterRequestDTO2Model(dto);

        DashboardUnitAttendanceSummaryResponseDTO responseDTO = dashboardService.getFilteredData(model);

        return ResponseResult.success(responseDTO);
    }

    @GetMapping("/dashboard/query_available_units")
    public ResponseResult<LecturerUnitsDTO> getLecturerAvailableUnit(@RequestBody DashboardQueryAvailableUnitDTO dashboardQueryAvailableUnitDTO) {
        return ResponseResult.success(new LecturerUnitsDTO());
    }

    @GetMapping("/dashboard/query_all_unit_code")
    public ResponseResult<List<String>> getAllUnitCode(){
        return ResponseResult.success(unitService.getAllUnitCodes());

    }

    @PostMapping("/dashboard/student_report/get_students_by_unit")
    public ResponseResult<DashboardUnitSemesterStudentsResponseDTO> getAllStudentByUnitSemester(@RequestBody DashboardQueryUnitStudentRequestDTO request) {
        DashboardUnitSemesterStudentsResponseDTO responseDTO = dashboardService.getUnitSemesterStudents(DashboardConverter.convertQueryStudentRequestDTO2Model(request));

        return ResponseResult.success(responseDTO);
    }

//    @PostMapping("/api/gemini")
//    public ResponseEntity<String> proxy(@RequestBody String body) {
//
//        String apiKey = System.getenv("GEMINI_API_KEY");
//
//        RestTemplate restTemplate = new RestTemplate();
//
//        HttpHeaders headers = new HttpHeaders();
//        headers.setContentType(MediaType.APPLICATION_JSON);
//
//        HttpEntity<String> request = new HttpEntity<>(body, headers);
//
//        String url =
//                "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key="
//                        + apiKey;
//
//        return restTemplate.postForEntity(
//                url,
//                request,
//                String.class
//        );
//    }
}

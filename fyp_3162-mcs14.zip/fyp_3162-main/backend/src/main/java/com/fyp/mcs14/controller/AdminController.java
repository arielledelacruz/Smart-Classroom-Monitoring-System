package com.fyp.mcs14.controller;

import com.fyp.mcs14.model.enums.ResponseStatusEnum;
import com.fyp.mcs14.common.ResponseResult;
import com.fyp.mcs14.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.concurrent.ExecutionException;

@RestController
public class AdminController {
    @Autowired
    private AdminService adminService;

    @PostMapping("/admin/upload_attendance_data_excel")
    public ResponseResult<String> uploadExcel(@RequestParam("file") MultipartFile file) throws IOException, ExecutionException, InterruptedException {
        if (file.isEmpty()) {
            return new ResponseResult<>(ResponseStatusEnum.FAIL, "File is empty");
        }

        adminService.uploadAttendanceRawRecordExcel(file);

        return ResponseResult.success("Excel uploaded successful");
    }

    /**
     * API to parse excel containing student id of a unit in a semester year
     * Expected filename: FIT3077-2025-S1-students.xlsx
     *
     * Expected file structure:
     * | studentId |
     */
    @PostMapping("/admin/upload_unit_semester_data")
    public ResponseResult<String> uploadUnitSemesterData(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return new ResponseResult<>(ResponseStatusEnum.FAIL, "File is empty");
        }

        adminService.uploadUnitSemesterDataExcel(file);

        return ResponseResult.success("Unit Semester Data Excel uploaded successful");
    }

    /**
     * API to upload student enrollment list for a specific unit/class.
     * Expected filename: FIT3077-2025-S1-students.xlsx
     *
     * Expected file structure:
     * | studentId |
     */
    @PostMapping("/admin/upload_unit_class_students")
    public ResponseResult<String> uploadUnitClassStudents(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return new ResponseResult<>(ResponseStatusEnum.FAIL, "File is empty");
        }

        // same parser as unit semester data: unit/year/semester inferred from file name
        adminService.uploadUnitSemesterDataExcel(file);

        return ResponseResult.success("Unit class student enrollment Excel uploaded successful");
    }

    /**
     * API to upload unit semester student mark data Excel file
     *
     * Expected filename: FIT3077-2025-S1-marks.xlsx
     *
     * Expected file structure:
     * | studentId | assignmentId | assignmentName | marks |
     */
    @PostMapping("/admin/upload_unit_semester_student_mark_data")
    public ResponseResult<String> uploadUnitSemesterStudentMarkData(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return new ResponseResult<>(ResponseStatusEnum.FAIL, "File is empty");
        }

        adminService.uploadUnitSemesterStudentMarkExcel(file);

        return ResponseResult.success("Unit Semester Student Mark Data Excel uploaded successful");
    }

    /**
     * Endpoint to upload student data Excel file
     *
     * Expected filename: students.xlsx
     *
     * Expected file structure:
     * | studentId | email | name | faculty | phone | enrolledYear |
     *
     * @param file the Excel file to upload
     * @return ResponseResult with success or fail status
     */
    @PostMapping("/admin/upload_student_data")
    public ResponseResult<String> uploadStudentData(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return new ResponseResult<>(ResponseStatusEnum.FAIL, "File is empty");
        }

        adminService.uploadStudentsExcel(file);

        return ResponseResult.success("Student data Excel uploaded successfully");
    }

    /**
     * Endpoint to upload student data Excel file
     *
     * Expected filename: lecturers.xlsx
     *
     * Expected file structure:
     * | id | name | email | phone | faculty | office | researchArea (comma-separated) |
     *
     * @param file the Excel file to upload
     * @return ResponseResult with success or fail status
     */
    @PostMapping("/admin/upload_lecturer_data")
    public ResponseResult<String> uploadLecturerData(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return new ResponseResult<>(ResponseStatusEnum.FAIL, "File is empty");
        }

        adminService.uploadLecturersExcel(file);

        return ResponseResult.success("Lecturer data Excel uploaded successfully");
    }
}

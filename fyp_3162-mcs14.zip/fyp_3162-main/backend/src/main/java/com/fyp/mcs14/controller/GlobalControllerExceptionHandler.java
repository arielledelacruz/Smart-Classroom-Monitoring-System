package com.fyp.mcs14.controller;

import com.fyp.mcs14.common.ResponseResult;
import com.fyp.mcs14.model.enums.ResponseStatusEnum;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.lang.reflect.Array;

@RestControllerAdvice
public class GlobalControllerExceptionHandler {

    /**
     * Handles all uncaught exceptions thrown by any controller
     *
     * @param e the exception thrown
     * @return a ResponseResult with FAIL status
     */
    @ExceptionHandler(Exception.class)
    public ResponseResult<String> handleException(Exception e) {
        return ResponseResult.fail(e.getMessage());
    }
}
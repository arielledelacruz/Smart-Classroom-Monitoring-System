package com.fyp.mcs14.controller;

import com.fyp.mcs14.model.dto.authentication.LoginRequestDTO;
import com.fyp.mcs14.common.ResponseResult;
import com.fyp.mcs14.model.dto.authentication.AuthUserDTO;
import com.fyp.mcs14.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LoginController {
    @Autowired
    AuthService authService;

    @PostMapping("/auth")
    public ResponseResult<AuthUserDTO> login(@RequestBody LoginRequestDTO user){
        return authService.validateLogin(user);
    }
}

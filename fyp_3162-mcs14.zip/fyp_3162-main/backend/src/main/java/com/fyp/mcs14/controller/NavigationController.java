package com.fyp.mcs14.controller;

import com.fyp.mcs14.common.ResponseResult;
import com.fyp.mcs14.service.LecturerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
public class NavigationController {

    @Autowired
    private LecturerService lecturerService;

    @PostMapping("/navigation/upload_profile_photo_lecturer")
    public ResponseResult<Void> uploadLecturerProfilePhoto(
            @RequestParam("lecturerId") String lecturerId,
            @RequestParam("file") MultipartFile file) {
        lecturerService.uploadProfilePhoto(lecturerId, file);
        return ResponseResult.success(null);
    }
}

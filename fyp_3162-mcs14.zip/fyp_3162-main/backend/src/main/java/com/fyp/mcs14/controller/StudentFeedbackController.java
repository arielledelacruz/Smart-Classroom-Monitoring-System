package com.fyp.mcs14.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fyp.mcs14.common.ResponseResult;
import com.fyp.mcs14.model.dto.StudentFeedbackDTO;
import com.fyp.mcs14.model.model.StudentFeedback;
import com.fyp.mcs14.service.StudentFeedbackService;

@RestController
@RequestMapping("/feedback")
public class StudentFeedbackController {

    @Autowired
    private StudentFeedbackService studentFeedbackService;

    /**
     * Save (create or update) personalised feedback for a student.
     * If feedbackId is present, the existing entry is overwritten.
     */
    @PostMapping("/save")
    public ResponseResult<String> saveFeedback(@RequestBody StudentFeedback feedback) {
        studentFeedbackService.saveFeedback(feedback);
        return ResponseResult.success("Feedback saved successfully");
    }

    /**
     * Get a single feedback entry by its ID.
     */
    @GetMapping("/{feedbackId}")
    public ResponseResult<StudentFeedbackDTO> getFeedbackById(@PathVariable String feedbackId) {
        return ResponseResult.success(studentFeedbackService.getFeedbackById(feedbackId));
    }

    /**
     * Get all feedback entries for a student in a specific unit.
     */
    @GetMapping("/student/{studentId}/{unitCode}")
    public ResponseResult<List<StudentFeedbackDTO>> getFeedbackByStudentAndUnit(
            @PathVariable String studentId,
            @PathVariable String unitCode) {
        return ResponseResult.success(studentFeedbackService.getFeedbackByStudentAndUnit(studentId, unitCode));
    }

    /**
     * Get all feedback entries for a student across all units.
     */
    @GetMapping("/student/{studentId}")
    public ResponseResult<List<StudentFeedbackDTO>> getFeedbackByStudent(@PathVariable String studentId) {
        return ResponseResult.success(studentFeedbackService.getFeedbackByStudent(studentId));
    }

    /**
     * Get all feedback entries for a unit.
     */
    @GetMapping("/unit/{unitCode}")
    public ResponseResult<List<StudentFeedbackDTO>> getFeedbackByUnit(@PathVariable String unitCode) {
        return ResponseResult.success(studentFeedbackService.getFeedbackByUnit(unitCode));
    }

    /**
     * Get all feedback written by a lecturer for a specific unit.
     */
    @GetMapping("/lecturer/{lecturerId}/{unitCode}")
    public ResponseResult<List<StudentFeedbackDTO>> getFeedbackByLecturerAndUnit(
            @PathVariable String lecturerId,
            @PathVariable String unitCode) {
        return ResponseResult.success(studentFeedbackService.getFeedbackByLecturerAndUnit(lecturerId, unitCode));
    }

    /**
     * Delete a feedback entry by its ID.
     */
    @DeleteMapping("/{feedbackId}")
    public ResponseResult<String> deleteFeedback(@PathVariable String feedbackId) {
        studentFeedbackService.deleteFeedback(feedbackId);
        return ResponseResult.success("Feedback deleted successfully");
    }
}

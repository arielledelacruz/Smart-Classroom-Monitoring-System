package com.fyp.mcs14.controller;

import com.fyp.mcs14.common.ResponseResult;
import com.fyp.mcs14.model.dto.StudentInterface.*;
import com.fyp.mcs14.model.enums.ResponseStatusEnum;
import com.fyp.mcs14.service.StudentInterfaceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentInterfaceController {
    @Autowired
    private StudentInterfaceService studentInterfaceService;

    /**
     * Endpoint to get all enrolled units of a student in a semester
     *
     * @param dto request containing studentId, year, semester
     * @return StudentEnrolledUnitsDTO
     */
    @PostMapping("/student/enrolled-units")
    public ResponseResult<StudentEnrolledUnitsDTO> getEnrolledUnits(
            @RequestBody StudentEnrolledUnitsRequestDTO dto) {
        return new ResponseResult<>(ResponseStatusEnum.SUCCESS,
                studentInterfaceService.getEnrolledUnits(
                        dto.getStudentId(),
                        dto.getYear(),
                        dto.getSemester()
                ));
    }

    @PostMapping("/student/sessions")
    public ResponseResult<StudentSessionHistoryDTO> getSessionHistory(@RequestBody StudentUnitRequestDTO dto) {
        String unitSemesterId = dto.getUnitCode() + "-" + dto.getYear() + "-" + dto.getSemester();
        return new ResponseResult<>(ResponseStatusEnum.SUCCESS,
                studentInterfaceService.getSessionHistory(
                        dto.getStudentId(),
                        unitSemesterId
                ));
    }

    /**
     * Endpoint to get analytics result of a student for a specific unit
     *
     * @param dto request containing studentId, unitSemesterId
     * @return StudentAnalyticsResultDTO
     */
    @PostMapping("/student/analytics")
    public ResponseResult<StudentAnalyticsResultDTO> getStudentAnalytics(
            @RequestBody StudentUnitRequestDTO dto) {
        String unitSemesterId = dto.getUnitCode() + "-" + dto.getYear() + "-" + dto.getSemester();
        return new ResponseResult<>(ResponseStatusEnum.SUCCESS,
                studentInterfaceService.getStudentAnalytics(
                        dto.getStudentId(),
                        unitSemesterId
                ));
    }

    /**
     * Endpoint to get detailed attendance data of a student for a specific unit
     *
     * @param dto request containing studentId, unitSemesterId
     * @return StudentUnitAttendanceDetailDTO
     */
    @PostMapping("/student/attendance/unit")
    public ResponseResult<StudentUnitAttendanceDetailDTO> getUnitAttendanceDetail(
            @RequestBody StudentUnitRequestDTO dto) {
        String unitSemesterId = dto.getUnitCode() + "-" + dto.getYear() + "-" + dto.getSemester();
        return new ResponseResult<>(ResponseStatusEnum.SUCCESS,
                studentInterfaceService.getUnitAttendanceDetail(
                        dto.getStudentId(),
                        unitSemesterId
                ));
    }

    /**
     * Endpoint to get overall attendance summary of a student across all enrolled units
     *
     * @param dto request containing studentId, year, semester
     * @return StudentOverallAttendanceSummaryDTO
     */
    @PostMapping("/student/attendance/summary")
    public ResponseResult<StudentOverallAttendanceSummaryDTO> getAttendanceSummary(
            @RequestBody StudentAttendanceSummaryRequestDTO dto) {
        return new ResponseResult<>(ResponseStatusEnum.SUCCESS,
                studentInterfaceService.getAttendanceSummary(
                        dto.getStudentId(),
                        dto.getYear(),
                        dto.getSemester()
                ));
    }
}

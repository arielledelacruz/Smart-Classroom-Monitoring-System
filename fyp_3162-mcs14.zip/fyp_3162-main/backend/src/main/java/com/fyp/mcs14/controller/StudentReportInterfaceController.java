package com.fyp.mcs14.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentReportInterfaceController {
}

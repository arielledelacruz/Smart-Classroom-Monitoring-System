package com.fyp.mcs14.model.converter;

import com.fyp.mcs14.model.dto.dashboard.DashboardFilterRequestDTO;
import com.fyp.mcs14.model.dto.dashboard.DashboardQueryUnitStudentRequestDTO;
import com.fyp.mcs14.model.enums.SemesterEnum;
import com.fyp.mcs14.model.enums.UnitCodeEnum;
import com.fyp.mcs14.model.enums.WeekEnum;
import com.fyp.mcs14.model.model.dashboard.DashboardFilterRequest;
import com.fyp.mcs14.model.model.dashboard.DashboardQueryUnitStudentRequest;

import java.util.List;
import java.util.stream.Collectors;

public class DashboardConverter {
    public static DashboardFilterRequest convertFilterRequestDTO2Model(DashboardFilterRequestDTO dto) {
        DashboardFilterRequest model = new DashboardFilterRequest();

        // convert List<String> → List<UnitCodeEnum>
        List<UnitCodeEnum> unitCodeEnumList = dto.getUnitCodeList()
                .stream()
                .map(UnitCodeEnum::valueOf)
                .collect(Collectors.toList());

        model.setUnitCodeList(unitCodeEnumList);
        model.setWeekStart(WeekEnum.getByCode(dto.getWeekStart()));
        model.setWeekEnd(WeekEnum.getByCode(dto.getWeekEnd()));
        model.setYear(dto.getYear());

        model.setSemester(SemesterEnum.valueOf(dto.getSemester()));

        return model;
    }

    public static DashboardQueryUnitStudentRequest convertQueryStudentRequestDTO2Model(DashboardQueryUnitStudentRequestDTO dto) {
        if (dto == null) return null;

        DashboardQueryUnitStudentRequest model = new DashboardQueryUnitStudentRequest();

        model.setUnitCode(UnitCodeEnum.valueOf(dto.getUnitCode()));
        model.setYear(dto.getYear());
        model.setSemester(SemesterEnum.valueOf(dto.getSemester()));

        return model;
    }
}

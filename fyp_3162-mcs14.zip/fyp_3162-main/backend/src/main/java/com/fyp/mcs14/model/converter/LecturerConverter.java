package com.fyp.mcs14.model.converter;

import com.fyp.mcs14.model.dataobject.LecturerDO;
import com.fyp.mcs14.model.enums.FacultyEnum;
import com.fyp.mcs14.model.model.Lecturer;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class LecturerConverter {

    public static LecturerDO convertModel2DO(Lecturer lecturer) {
        if (lecturer == null) return null;

        return new LecturerDO(
                lecturer.getId(),
                lecturer.getName(),
                lecturer.getEmail(),
                lecturer.getPhone(),
                lecturer.getFaculty().name(),
                lecturer.getProfilePhotoUrl(),
                lecturer.getOffice(),
                lecturer.getResearchArea()
        );
    }

    public static Lecturer convertDO2Model(LecturerDO lecturerDO) {
        if (lecturerDO == null) return null;

        return Lecturer.builder()
                .id(lecturerDO.getId())
                .name(lecturerDO.getName())
                .email(lecturerDO.getEmail())
                .phone(lecturerDO.getPhone())
                .faculty(FacultyEnum.valueOf(lecturerDO.getFaculty()))
                .profilePhotoUrl(lecturerDO.getProfilePhotoUrl())
                .office(lecturerDO.getOffice())
                .researchArea(lecturerDO.getResearchArea())
                .build();
    }

    public static List<Lecturer> convertDOList2ModelList(List<LecturerDO> lecturerDOList) {
        if (lecturerDOList == null) return new ArrayList<>();
        return lecturerDOList.stream()
                .map(LecturerConverter::convertDO2Model)
                .collect(Collectors.toList());
    }

    public static List<LecturerDO> convertModelList2DOList(List<Lecturer> lecturerList) {
        if (lecturerList == null) return new ArrayList<>();
        return lecturerList.stream()
                .map(LecturerConverter::convertModel2DO)
                .collect(Collectors.toList());
    }
}
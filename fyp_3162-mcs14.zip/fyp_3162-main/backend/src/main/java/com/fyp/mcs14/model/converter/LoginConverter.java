package com.fyp.mcs14.model.converter;

import com.fyp.mcs14.model.dto.authentication.AuthUserDTO;
import com.fyp.mcs14.model.dto.authentication.LecturerAuthUserDTO;
import com.fyp.mcs14.model.dto.authentication.LoginRequestDTO;
import com.fyp.mcs14.model.dto.authentication.StudentAuthUserDTO;
import com.fyp.mcs14.model.enums.UserRoleEnum;
import com.fyp.mcs14.model.model.authentication.AuthUser;
import com.fyp.mcs14.model.model.authentication.LecturerAuthUser;
import com.fyp.mcs14.model.model.authentication.LoginRequest;
import com.fyp.mcs14.model.model.authentication.StudentAuthUser;

public class LoginConverter {
    public static LoginRequest convertDTO2Model(LoginRequestDTO dto) {
        if (dto == null) return null;
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setEmail(dto.getEmail());
        loginRequest.setPassword(dto.getPassword());
        return loginRequest;
    }

    public static AuthUserDTO convertModel2DTO(AuthUser authUser) {
        if (authUser == null) return null;

        if (authUser.getUserRole().equals(UserRoleEnum.LECTURER)) {
            return convertLecturerModel2DTO((LecturerAuthUser) authUser);
        } else if (authUser.getUserRole().equals(UserRoleEnum.STUDENT)) {
            return convertStudentModel2DTO((StudentAuthUser) authUser);
        }

        return null;
    }

    public static LecturerAuthUserDTO convertLecturerModel2DTO(LecturerAuthUser lecturer) {
        if (lecturer == null) return null;

        LecturerAuthUserDTO lecturerDTO = new LecturerAuthUserDTO();
        lecturerDTO.setId(lecturer.getId());
        lecturerDTO.setEmail(lecturer.getEmail());
        lecturerDTO.setPhone(lecturer.getPhone());
        lecturerDTO.setUserRole(lecturer.getUserRole().name());
        lecturerDTO.setName(lecturer.getName());
        lecturerDTO.setProfilePhotoUrl(lecturer.getProfilePhotoUrl());
        lecturerDTO.setFaculty(lecturer.getFaculty() != null ? lecturer.getFaculty().name() : null);
        lecturerDTO.setOffice(lecturer.getOffice());
        lecturerDTO.setResearchArea(lecturer.getResearchArea());
        return lecturerDTO;
    }

    // TODO: add logic
    public static StudentAuthUserDTO convertStudentModel2DTO(StudentAuthUser student) {
        if (student == null) return null;

        StudentAuthUserDTO studentDTO = new StudentAuthUserDTO();
        studentDTO.setId(student.getId());
        studentDTO.setEmail(student.getEmail());
        studentDTO.setPhone(student.getPhone());
        studentDTO.setUserRole(student.getUserRole().name());
        studentDTO.setName(student.getName());
        studentDTO.setProfilePhotoUrl(student.getProfilePhotoUrl());
        studentDTO.setFaculty(student.getFaculty() != null ? student.getFaculty().name() : null);
        return studentDTO;
    }
}

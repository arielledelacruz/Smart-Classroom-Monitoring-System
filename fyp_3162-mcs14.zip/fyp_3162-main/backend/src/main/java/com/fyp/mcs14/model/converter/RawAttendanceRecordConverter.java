package com.fyp.mcs14.model.converter;

import com.fyp.mcs14.model.dataobject.MotionRecordDO;
import com.fyp.mcs14.model.dataobject.RawAttendanceRecordDO;
import com.fyp.mcs14.model.model.excel.MotionRecord;
import com.fyp.mcs14.model.model.excel.RawAttendanceRecord;

public class RawAttendanceRecordConverter {
    public static RawAttendanceRecordDO convertModel2DO(RawAttendanceRecord record){
        return RawAttendanceRecordDO.builder()
                .studentId(record.getStudentId())
                .sessionId(record.getSessionId().getUniqueId())
                .records(record.getRecords().stream().map(RawAttendanceRecordConverter::convertMotionModel2DO).toList())
                .build();
    }

    private static MotionRecordDO convertMotionModel2DO(MotionRecord motionRecord){
        return MotionRecordDO.builder()
                .time(motionRecord.getTime())
                .numberOfMotion(motionRecord.getNumberOfMotion())
                .motion(motionRecord.getMotionType().name())
                .build();
    }
}

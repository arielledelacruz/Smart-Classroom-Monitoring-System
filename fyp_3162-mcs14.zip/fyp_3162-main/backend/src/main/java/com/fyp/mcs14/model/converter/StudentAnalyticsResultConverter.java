package com.fyp.mcs14.model.converter;

import com.fyp.mcs14.model.dataobject.StudentAnalyticsResultDO;
import com.fyp.mcs14.model.model.StudentAnalyticsResult;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Converter class to convert between StudentAnalyticsResult and StudentAnalyticsResultDO
 */
public class StudentAnalyticsResultConverter {

    /**
     * Converts a StudentAnalyticsResult domain object to a StudentAnalyticsResultDO data object
     *
     * @param result         the StudentAnalyticsResult domain object
     * @param unitSemesterId the unit semester id
     * @return the converted StudentAnalyticsResultDO data object
     */
    public static StudentAnalyticsResultDO toDO(StudentAnalyticsResult result, String unitSemesterId) {
        return StudentAnalyticsResultDO.builder()
                .studentId(result.getStudentId())
                .unitSemesterId(unitSemesterId)
                .attendanceRate(result.getAttendanceRate())
                .engagementScore(result.getEngagementScore())
                .effectivePresence(result.getEffectivePresence())
                .trendSlope(result.getTrendSlope())
                .consecutiveAbsences(result.getConsecutiveAbsences())
                .riskScore(result.getRiskScore())
                .clusterLabel(result.getClusterLabel())
                .insights(result.getInsights())
                .riskBreakdown(result.getRiskBreakdown())
                .explanations(result.getExplanations())
                .build();
    }

    /**
     * Converts a StudentAnalyticsResultDO data object to a StudentAnalyticsResult domain object
     *
     * @param resultDO the StudentAnalyticsResultDO data object
     * @return the converted StudentAnalyticsResult domain object
     */
    public static StudentAnalyticsResult toModel(StudentAnalyticsResultDO resultDO) {
        return StudentAnalyticsResult.builder()
                .studentId(resultDO.getStudentId())
                .attendanceRate(resultDO.getAttendanceRate())
                .engagementScore(resultDO.getEngagementScore())
                .effectivePresence(resultDO.getEffectivePresence())
                .trendSlope(resultDO.getTrendSlope())
                .consecutiveAbsences(resultDO.getConsecutiveAbsences())
                .riskScore(resultDO.getRiskScore())
                .clusterLabel(resultDO.getClusterLabel())
                .insights(resultDO.getInsights())
                .riskBreakdown(resultDO.getRiskBreakdown())
                .explanations(resultDO.getExplanations())
                .build();
    }

    /**
     * Converts a list of StudentAnalyticsResultDO to a list of StudentAnalyticsResult domain objects
     *
     * @param resultDOs the list of StudentAnalyticsResultDO data objects
     * @return the converted list of StudentAnalyticsResult domain objects
     */
    public static List<StudentAnalyticsResult> toModelList(List<StudentAnalyticsResultDO> resultDOs) {
        if (resultDOs == null) return new ArrayList<>();
        return resultDOs.stream()
                .map(StudentAnalyticsResultConverter::toModel)
                .collect(Collectors.toList());
    }

    /**
     * Converts a list of StudentAnalyticsResult to a list of StudentAnalyticsResultDO data objects
     *
     * @param results        the list of StudentAnalyticsResult domain objects
     * @param unitSemesterId the unit semester id
     * @return the converted list of StudentAnalyticsResultDO data objects
     */
    public static List<StudentAnalyticsResultDO> toDOList(List<StudentAnalyticsResult> results,
                                                          String unitSemesterId) {
        if (results == null) return new ArrayList<>();
        return results.stream()
                .map(r -> StudentAnalyticsResultConverter.toDO(r, unitSemesterId))
                .collect(Collectors.toList());
    }
}

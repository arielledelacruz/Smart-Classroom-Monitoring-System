package com.fyp.mcs14.model.converter;

import com.fyp.mcs14.model.dataobject.StudentDO;
import com.fyp.mcs14.model.dto.dashboard.StudentListViewDTO;
import com.fyp.mcs14.model.enums.FacultyEnum;
import com.fyp.mcs14.model.enums.UserRoleEnum;
import com.fyp.mcs14.model.model.Student;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class StudentConverter {

    /**
     * Converts a Student domain object to a StudentDO data object
     *
     * @param student the Student domain object to convert
     * @return the converted StudentDO data object, or null if input is null
     */
    public static StudentDO convertModel2DO(Student student) {
        if (student == null) return null;

        return StudentDO.builder()
                .studentId(student.getStudentId())
                .email(student.getEmail())
                .userRole(student.getUserRole().name())
                .name(student.getName())
                .profilePhotoUrl(student.getProfilePhotoUrl())
                .faculty(student.getFaculty().name())
                .phone(student.getPhone())
                .enrolledYear(student.getEnrolledYear())
                .enrolledUnitSemesterCode(student.getEnrolledUnitSemesterCode())
                .build();
    }

    /**
     * Converts a StudentDO data object to a Student domain object
     *
     * @param studentDO the StudentDO data object to convert
     * @return the converted Student domain object, or null if input is null
     */
    public static Student convertDO2Model(StudentDO studentDO) {
        if (studentDO == null) return null;

        return Student.builder()
                .studentId(studentDO.getStudentId())
                .email(studentDO.getEmail())
                .userRole(UserRoleEnum.valueOf(studentDO.getUserRole()))
                .name(studentDO.getName())
                .profilePhotoUrl(studentDO.getProfilePhotoUrl())
                .faculty(FacultyEnum.valueOf(studentDO.getFaculty()))
                .phone(studentDO.getPhone())
                .enrolledYear(studentDO.getEnrolledYear())
                .enrolledUnitSemesterCode(studentDO.getEnrolledUnitSemesterCode())
                .build();
    }

    /**
     * Converts a list of StudentDO data objects to a list of Student domain objects
     *
     * @param studentDOList the list of StudentDO data objects to convert
     * @return the converted list of Student domain objects
     */
    public static List<Student> convertDOList2ModelList(List<StudentDO> studentDOList) {
        if (studentDOList == null) return new ArrayList<>();
        return studentDOList.stream()
                .map(StudentConverter::convertDO2Model)
                .collect(Collectors.toList());
    }

    /**
     * Converts a list of Student domain objects to a list of StudentDO data objects
     *
     * @param studentList the list of Student domain objects to convert
     * @return the converted list of StudentDO data objects
     */
    public static List<StudentDO> convertModelList2DOList(List<Student> studentList) {
        if (studentList == null) return new ArrayList<>();
        return studentList.stream()
                .map(StudentConverter::convertModel2DO)
                .collect(Collectors.toList());
    }

    public static StudentListViewDTO convertModel2ListViewDTO(Student student) {
        if (student == null) return null;

        StudentListViewDTO dto = new StudentListViewDTO();
        dto.setId(student.getStudentId());
        dto.setName(student.getName());
        dto.setProfilePhotoUrl(student.getProfilePhotoUrl());

        return dto;
    }
}
package com.fyp.mcs14.model.converter;

import com.fyp.mcs14.model.dataobject.StudentSessionSummaryDO;
import com.fyp.mcs14.model.model.StudentSessionSummary;
import com.fyp.mcs14.model.model.attendance.SessionId;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Converter class to convert between StudentSessionSummary and StudentSessionSummaryDO objects
 */
public class StudentSessionSummaryConverter {

    /**
     * Converts a StudentSessionSummary domain object to a StudentSessionSummaryDO data object
     *
     * @param summary the StudentSessionSummary domain object to convert
     * @return the converted StudentSessionSummaryDO data object
     */
    public static StudentSessionSummaryDO toDO(StudentSessionSummary summary) {
        return StudentSessionSummaryDO.builder()
                .studentId(summary.getStudentId())
                .sessionId(summary.getSessionId().getUniqueId()
                        .replace(summary.getStudentId() + "-", "")) // strip studentId prefix
                .present(summary.isPresent())
                .lateArrival(summary.isLateArrival())
                .earlyDeparture(summary.isEarlyDeparture())
                .engagementScore(summary.getEngagementScore())
                .presenceQuality(summary.getPresenceQuality())
                .build();
    }

    /**
     * Converts a StudentSessionSummaryDO data object to a StudentSessionSummary domain object
     *
     * @param summaryDO the StudentSessionSummaryDO data object to convert
     * @return the converted StudentSessionSummary domain object
     */
    public static StudentSessionSummary toModel(StudentSessionSummaryDO summaryDO) {
        // reconstruct full session unique id by prepending studentId
        String fullSessionId = summaryDO.getStudentId() + "-" + summaryDO.getSessionId();
        SessionId sessionId = SessionId.getByUniqueId(fullSessionId);

        return StudentSessionSummary.builder()
                .studentId(summaryDO.getStudentId())
                .sessionId(sessionId)
                .present(summaryDO.isPresent())
                .lateArrival(summaryDO.isLateArrival())
                .earlyDeparture(summaryDO.isEarlyDeparture())
                .engagementScore(summaryDO.getEngagementScore())
                .presenceQuality(summaryDO.getPresenceQuality())
                .build();
    }

    /**
     * Converts a list of StudentSessionSummaryDO to a list of StudentSessionSummary domain objects
     *
     * @param summaryDOs the list of StudentSessionSummaryDO to convert
     * @return the converted list of StudentSessionSummary domain objects
     */
    public static List<StudentSessionSummary> toModelList(List<StudentSessionSummaryDO> summaryDOs) {
        if (summaryDOs == null) return new ArrayList<>();
        return summaryDOs.stream()
                .map(StudentSessionSummaryConverter::toModel)
                .collect(Collectors.toList());
    }

    /**
     * Converts a list of StudentSessionSummary to a list of StudentSessionSummaryDO data objects
     *
     * @param summaries the list of StudentSessionSummary to convert
     * @return the converted list of StudentSessionSummaryDO data objects
     */
    public static List<StudentSessionSummaryDO> toDOList(List<StudentSessionSummary> summaries) {
        if (summaries == null) return new ArrayList<>();
        return summaries.stream()
                .map(StudentSessionSummaryConverter::toDO)
                .collect(Collectors.toList());
    }
}

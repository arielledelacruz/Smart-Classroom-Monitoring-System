package com.fyp.mcs14.model.converter;

import com.fyp.mcs14.model.dataobject.StudentUnitSummaryDO;
import com.fyp.mcs14.model.model.StudentSessionSummary;
import com.fyp.mcs14.model.model.StudentUnitSummary;
import com.fyp.mcs14.model.model.attendance.UnitYearSemesterId;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class StudentUnitSummaryConverter {

    /**
     * Converts a StudentUnitSummary domain object to a StudentUnitSummaryDO data object
     *
     * @param summary the StudentUnitSummary domain object to convert
     * @return the converted StudentUnitSummaryDO data object
     */
    public static StudentUnitSummaryDO toDO(StudentUnitSummary summary) {
        return StudentUnitSummaryDO.builder()
                .studentId(summary.getStudentId())
                .unitSemesterId(summary.getUnitYearSemesterId().generateUniqueId())
                .totalSessions(summary.getTotalSessions())
                .totalPresent(summary.getTotalPresent())
                .totalLateArrival(summary.getTotalLateArrival())
                .totalEarlyDeparture(summary.getTotalEarlyDeparture())
                .attendanceRate(summary.getAttendanceRate())
                .avgEngagementScore(summary.getAvgEngagementScore())
                .avgPresenceQuality(summary.getAvgPresenceQuality())
                .build();
    }

    /**
     * Converts a StudentUnitSummaryDO data object to a StudentUnitSummary domain object
     *
     * @param summaryDO the StudentUnitSummaryDO data object to convert
     * @return the converted StudentUnitSummary domain object
     */
    public static StudentUnitSummary toModel(StudentUnitSummaryDO summaryDO) {
        return StudentUnitSummary.builder()
                .studentId(summaryDO.getStudentId())
                .unitYearSemesterId(UnitYearSemesterId.fromUniqueId(summaryDO.getUnitSemesterId()))
                .totalSessions(summaryDO.getTotalSessions())
                .totalPresent(summaryDO.getTotalPresent())
                .totalLateArrival(summaryDO.getTotalLateArrival())
                .totalEarlyDeparture(summaryDO.getTotalEarlyDeparture())
                .attendanceRate(summaryDO.getAttendanceRate())
                .avgEngagementScore(summaryDO.getAvgEngagementScore())
                .avgPresenceQuality(summaryDO.getAvgPresenceQuality())
                .build();
    }

    /**
     * Builds a StudentUnitSummary domain object from a list of StudentSessionSummary
     *
     * @param studentId          the student id
     * @param unitYearSemesterId the unit year semester id
     * @param sessions           ordered list of session summaries
     * @return the built StudentUnitSummary domain object
     */
    public static StudentUnitSummary fromSessions(String studentId,
                                                  UnitYearSemesterId unitYearSemesterId,
                                                  List<StudentSessionSummary> sessions) {
        int totalSessions    = sessions.size();
        int totalPresent     = (int) sessions.stream().filter(StudentSessionSummary::isPresent).count();
        int totalLateArrival = (int) sessions.stream().filter(StudentSessionSummary::isLateArrival).count();
        int totalEarlyDep    = (int) sessions.stream().filter(StudentSessionSummary::isEarlyDeparture).count();

        double attendanceRate = totalSessions == 0 ? 0 : (double) totalPresent / totalSessions;

        double avgEngagement = sessions.stream()
                .filter(StudentSessionSummary::isPresent)
                .mapToDouble(StudentSessionSummary::getEngagementScore)
                .average().orElse(0);

        double avgPresence = sessions.stream()
                .filter(StudentSessionSummary::isPresent)
                .mapToDouble(StudentSessionSummary::getPresenceQuality)
                .average().orElse(0);

        return StudentUnitSummary.builder()
                .studentId(studentId)
                .unitYearSemesterId(unitYearSemesterId)
                .sessions(sessions)
                .totalSessions(totalSessions)
                .totalPresent(totalPresent)
                .totalLateArrival(totalLateArrival)
                .totalEarlyDeparture(totalEarlyDep)
                .attendanceRate(attendanceRate)
                .avgEngagementScore(avgEngagement)
                .avgPresenceQuality(avgPresence)
                .build();
    }

    /**
     * Converts a list of StudentUnitSummaryDO to a list of StudentUnitSummary domain objects
     *
     * @param summaryDOs the list of StudentUnitSummaryDO to convert
     * @return the converted list of StudentUnitSummary domain objects
     */
    public static List<StudentUnitSummary> toModelList(List<StudentUnitSummaryDO> summaryDOs) {
        if (summaryDOs == null) return new ArrayList<>();
        return summaryDOs.stream()
                .map(StudentUnitSummaryConverter::toModel)
                .collect(Collectors.toList());
    }
}
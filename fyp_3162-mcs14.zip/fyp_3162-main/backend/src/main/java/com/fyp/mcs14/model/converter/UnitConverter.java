package com.fyp.mcs14.model.converter;

import com.fyp.mcs14.model.dataobject.UnitDO;
import com.fyp.mcs14.model.enums.UnitCodeEnum;
import com.fyp.mcs14.model.model.Unit;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Converter class to convert between Unit and UnitDO objects
 */
public class UnitConverter {

    /**
     * Converts a UnitDO data object to a Unit domain object
     *
     * @param unitDO the UnitDO object to convert
     * @return the converted Unit domain object
     */
    public static Unit convertDO2Model(UnitDO unitDO) {
        Unit unit = new Unit();
        unit.setUnitCode(UnitCodeEnum.valueOf(unitDO.getUnitCode()));
        unit.setUnitName(unitDO.getUnitName());
        unit.setFaculty(unitDO.getFaculty());
        unit.setCreditPoints(unitDO.getCreditPoints());
        return unit;
    }

    /**
     * Converts a Unit domain object to a UnitDO data object
     *
     * @param unit the Unit object to convert
     * @return the converted UnitDO data object
     */
    public static UnitDO convertModel2DO(Unit unit) {
        return UnitDO.builder()
                .unitCode(unit.getUnitCode().name())
                .unitName(unit.getUnitName())
                .faculty(unit.getFaculty())
                .creditPoints(unit.getCreditPoints())
                .build();
    }

    /**
     * Converts a list of UnitDO data objects to a list of Unit domain objects
     *
     * @param unitDOList the list of UnitDO objects to convert
     * @return the converted list of Unit domain objects
     */
    public static List<Unit> convertDOList2ModelList(List<UnitDO> unitDOList) {
        return unitDOList.stream()
                .map(UnitConverter::convertDO2Model)
                .collect(Collectors.toList());
    }
}
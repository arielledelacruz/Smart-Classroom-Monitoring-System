package com.fyp.mcs14.model.converter;

import com.fyp.mcs14.model.dataobject.UnitSemesterAssignmentDO;
import com.fyp.mcs14.model.model.UnitSemesterAssignment;
import com.fyp.mcs14.model.model.attendance.UnitYearSemesterId;

public class UnitSemesterAssignmentConverter {

    public static UnitSemesterAssignmentDO toDO(UnitSemesterAssignment assignment) {
        return UnitSemesterAssignmentDO.builder()
                .id(assignment.generateUniqueId())
                .assignmentId(assignment.getAssignmentId())
                .assignmentName(assignment.getAssignmentName())
                .build();
    }

    public static UnitSemesterAssignment toModel(UnitSemesterAssignmentDO assignmentDO) {
        UnitYearSemesterId unitYearSemesterId = UnitYearSemesterId.fromUniqueId(
                assignmentDO.getId().substring(0, assignmentDO.getId().lastIndexOf("-"))
        );
        return UnitSemesterAssignment.builder()
                .unitYearSemesterId(unitYearSemesterId)
                .assignmentId(assignmentDO.getAssignmentId())
                .assignmentName(assignmentDO.getAssignmentName())
                .build();
    }
}
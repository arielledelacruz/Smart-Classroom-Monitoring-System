package com.fyp.mcs14.model.converter;

import com.fyp.mcs14.model.dataobject.UnitSemesterDataDO;
import com.fyp.mcs14.model.model.UnitSemesterData;
import com.fyp.mcs14.model.model.attendance.UnitYearSemesterId;

public class UnitSemesterDataConverter {
    public static UnitSemesterData convertDO2Model(UnitSemesterDataDO dataDO) {
        if (dataDO == null) return null;

        UnitSemesterData unitSemesterData = new UnitSemesterData();

        unitSemesterData.setId(UnitYearSemesterId.fromUniqueId(dataDO.getId()));
        unitSemesterData.setTotalStudents(dataDO.getTotalStudents());
        unitSemesterData.setStudentIdList(dataDO.getStudentIdList());

        return unitSemesterData;
    }

    public static UnitSemesterDataDO convertModel2DO(UnitSemesterData data) {
        if (data == null) return null;

        UnitSemesterDataDO dataDO = new UnitSemesterDataDO();

        dataDO.setId(data.getId().generateUniqueId());
        dataDO.setTotalStudents(data.getTotalStudents());
        dataDO.setStudentIdList(data.getStudentIdList());

        return dataDO;
    }
}

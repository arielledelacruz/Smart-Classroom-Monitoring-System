package com.fyp.mcs14.model.converter;

import com.fyp.mcs14.model.dataobject.UnitSemesterStudentMarkDO;
import com.fyp.mcs14.model.enums.SemesterEnum;
import com.fyp.mcs14.model.enums.UnitCodeEnum;
import com.fyp.mcs14.model.model.UnitSemesterStudentMark;
import com.fyp.mcs14.model.model.attendance.UnitYearSemesterId;

public class UnitSemesterStudentMarkConverter {

    public static UnitSemesterStudentMarkDO toDO(UnitSemesterStudentMark mark) {
        return UnitSemesterStudentMarkDO.builder()
                .id(mark.generateUniqueId())
                .marks(mark.getMarks())
                .build();
    }

    public static UnitSemesterStudentMark toModel(UnitSemesterStudentMarkDO markDO) {
        // e.g. FIT3077-2025-S1-A1-12345678
        String[] parts = markDO.getId().split("-");
        UnitYearSemesterId unitYearSemesterId = UnitYearSemesterId.builder()
                .unitCode(UnitCodeEnum.valueOf(parts[0]))
                .year(Integer.parseInt(parts[1]))
                .semester(SemesterEnum.valueOf(parts[2]))
                .build();

        return UnitSemesterStudentMark.builder()
                .unitYearSemesterId(unitYearSemesterId)
                .assignmentId(parts[3])
                .studentId(parts[4])
                .marks(markDO.getMarks())
                .build();
    }
}

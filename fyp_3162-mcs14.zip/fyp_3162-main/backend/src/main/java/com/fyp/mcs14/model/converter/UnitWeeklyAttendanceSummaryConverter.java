package com.fyp.mcs14.model.converter;

import com.fyp.mcs14.model.dataobject.UnitWeeklyAttendanceSummaryDO;
import com.fyp.mcs14.model.enums.SemesterEnum;
import com.fyp.mcs14.model.enums.UnitCodeEnum;
import com.fyp.mcs14.model.enums.WeekEnum;
import com.fyp.mcs14.model.model.attendance.UnitWeeklyAttendanceSummary;
import com.fyp.mcs14.model.model.attendance.UnitYearSemesterWeekId;

/**
 * Converter class to convert between UnitWeeklyAttendanceSummary and UnitWeeklyAttendanceSummaryDO objects
 */
public class UnitWeeklyAttendanceSummaryConverter {

    /**
     * Converts a UnitWeeklyAttendanceSummary domain object to a UnitWeeklyAttendanceSummaryDO data object
     *
     * @param summary the UnitWeeklyAttendanceSummary object to convert
     * @return the converted UnitWeeklyAttendanceSummaryDO data object
     */
    public static UnitWeeklyAttendanceSummaryDO convertModel2DO(UnitWeeklyAttendanceSummary summary) {
        if (summary == null) {return null;}
        String id = summary.getId().getUnitCode().name() + "-"
                + summary.getId().getYear() + "-"
                + summary.getId().getSemester().name() + "-"
                + summary.getId().getWeek().getWeekCodeString();

        return UnitWeeklyAttendanceSummaryDO.builder()
                .id(id)
                .totalAttendance(summary.getTotalAttendance())
                .totalAbsence(summary.getTotalAbsence())
                .totalEarlyDeparture(summary.getTotalEarlyDeparture())
                .totalLateArrival(summary.getTotalLateArrival())
                .build();
    }

    /**
     * Converts a UnitWeeklyAttendanceSummaryDO data object to a UnitWeeklyAttendanceSummary domain object
     *
     * @param summaryDO the UnitWeeklyAttendanceSummaryDO object to convert
     * @return the converted UnitWeeklyAttendanceSummary domain object
     */
    public static UnitWeeklyAttendanceSummary convertDO2Model(UnitWeeklyAttendanceSummaryDO summaryDO) {
        if (summaryDO == null) { return null; }
        String[] parts = summaryDO.getId().split("-");

        UnitYearSemesterWeekId id = UnitYearSemesterWeekId.builder()
                .unitCode(UnitCodeEnum.valueOf(parts[0]))
                .year(Integer.parseInt(parts[1]))
                .semester(SemesterEnum.valueOf(parts[2]))
                .week(WeekEnum.getByString(parts[3]))
                .build();

        return UnitWeeklyAttendanceSummary.builder()
                .id(id)
                .week(id.getWeek())
                .totalAttendance(summaryDO.getTotalAttendance())
                .totalAbsence(summaryDO.getTotalAbsence())
                .totalEarlyDeparture(summaryDO.getTotalEarlyDeparture())
                .totalLateArrival(summaryDO.getTotalLateArrival())
                .build();
    }
}

package com.fyp.mcs14.model.dataobject;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LecturerDO {

    /**
     * Unique identifier of the lecturer
     * Maps to Firestore document ID
     * e.g. "L001"
     */
    private String id;

    /**
     * Full name of the lecturer
     * e.g. "Dr. John Smith"
     */
    private String name;

    /**
     * Email address of the lecturer
     * e.g. "john.smith@monash.edu"
     */
    private String email;

    /**
     * Phone number of lecturer
     */
    private String phone;

    /**
     * Faculty the lecturer belongs to
     * e.g. FacultyEnum.FACULTY_OF_IT
     */
    private String faculty;

    /**
     * URL of the lecturer's profile photo stored in Firebase Cloud Storage
     * e.g. "https://storage.googleapis.com/bucket/profile-photos/lecturers/L001.jpg"
     * Null if no photo has been uploaded
     */
    private String profilePhotoUrl;

    /**
     * Lecturer office
     */
    private String office;

    /**
     * Lecturer research area (in list)
     */
    private List<String> researchArea;
}

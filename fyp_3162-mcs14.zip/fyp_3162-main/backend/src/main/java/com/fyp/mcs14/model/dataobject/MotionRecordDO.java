package com.fyp.mcs14.model.dataobject;

import lombok.Builder;
import lombok.Data;

/**
 * Data object class to represent a motion record stored in the database
 */
@Data
@Builder
public class MotionRecordDO {

    /**
     * Type of motion detected
     * e.g. HEAD, HAND
     */
    private String motion;

    /**
     * Time when the motion was recorded
     * e.g. 09:00
     */
    private String time;

    /**
     * Number of same motion type detected at the same time
     * e.g. 5
     */
    private int numberOfMotion;
}

package com.fyp.mcs14.model.dataobject;

import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * Data object class to represent a raw attendance record stored in the database
 */
@Data
@Builder
public class RawAttendanceRecordDO {

    /**
     * Unique identifier of the student
     * e.g. 12345678
     */
    private String studentId;

    /**
     * Unique session identifier string of the class session
     * e.g. 12345678-FIT3077-2025S1-W1-LEC
     */
    private String sessionId;

    /**
     * List of motion records captured during the session
     */
    private List<MotionRecordDO> records;
}

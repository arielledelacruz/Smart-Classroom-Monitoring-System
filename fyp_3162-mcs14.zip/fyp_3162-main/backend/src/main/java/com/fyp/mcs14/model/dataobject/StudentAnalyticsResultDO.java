package com.fyp.mcs14.model.dataobject;

import com.fyp.mcs14.model.dto.AnalyticsExplanationDTO;
import com.fyp.mcs14.model.dto.RiskBreakdownDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Data object class to represent a student analytics result stored in the database
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StudentAnalyticsResultDO {

    /**
     * Unique identifier of the student
     * e.g. 12345678
     */
    private String studentId;

    /**
     * Unique identifier of the unit semester
     * e.g. FIT3077-2025-S1
     */
    private String unitSemesterId;

    /**
     * Overall attendance rate (0.0 - 1.0)
     * e.g. 0.83
     */
    private double attendanceRate;

    /**
     * Average engagement score across all present sessions (0.0 - 1.0)
     * e.g. 0.65
     */
    private double engagementScore;

    /**
     * Effective presence quality across all present sessions (0.0 - 1.0)
     * e.g. 0.75
     */
    private double effectivePresence;

    /**
     * Trend slope of attendance over sessions
     * Positive = improving, Negative = declining
     * e.g. -0.05
     */
    private double trendSlope;

    /**
     * Maximum consecutive absences recorded
     * e.g. 3
     */
    private int consecutiveAbsences;

    /**
     * Overall risk score (0.0 - 1.0)
     * e.g. 0.72
     */
    private double riskScore;

    /**
     * Cluster label assigned by clustering algorithm
     * e.g. Engaged, Passive, Independent, At Risk
     */
    private String clusterLabel;

    /**
     * List of generated insights for this student
     * e.g. ["Low attendance across sessions", "High risk student - intervention recommended"]
     */
    private List<String> insights;

    private RiskBreakdownDTO riskBreakdown;

    private List<AnalyticsExplanationDTO> explanations;

    /**
     * Generates the document ID by concatenating studentId and unitSemesterId
     * e.g. 12345678-FIT3077-2025-S1
     *
     * @return the document ID string
     */
    public String generateDocumentId() {
        return studentId + "-" + unitSemesterId;
    }
}

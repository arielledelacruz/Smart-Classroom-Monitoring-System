package com.fyp.mcs14.model.dataobject;

import com.fyp.mcs14.model.enums.FacultyEnum;
import com.fyp.mcs14.model.enums.UserRoleEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class StudentDO {
    /**
     * Monash student id
     */
    private String studentId;

    /**
     * Monash email
     */
    private String email;

    /**
     * Role of the user in the system
     * e.g. STUDENT, LECTURER
     */
    private String userRole;

    /**
     * Full name of the user
     * e.g. "Dr. John Smith"
     */
    private String name;

    /**
     * URL of the user's profile photo stored in Firebase Cloud Storage
     * e.g. "https://storage.googleapis.com/bucket/profile-photos/lecturers/L001.jpg"
     * Null if no photo has been uploaded
     */
    private String profilePhotoUrl;

    /**
     * Faculty the user belongs to
     */
    private String faculty;

    /**
     * Phone number for user
     */
    private String phone;

    /**
     * Enrolment year of the student
     */
    private int enrolledYear;

    private List<String> enrolledUnitSemesterCode;
}

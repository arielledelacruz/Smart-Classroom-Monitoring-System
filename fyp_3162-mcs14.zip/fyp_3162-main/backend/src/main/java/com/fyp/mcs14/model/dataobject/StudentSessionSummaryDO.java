package com.fyp.mcs14.model.dataobject;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class StudentSessionSummaryDO {
    /**
     * Unique student ID
     * e.g. 12345678
     */
    private String studentId;

    /**
     * Unique Session ID
     * e.g. FIT3077-2025-S1-W1-LEC
     */
    private String sessionId;

    /**
     * Whether the student was present in the session
     */
    private boolean present;

    /**
     * Whether the student arrived late
     */
    private boolean lateArrival;

    /**
     * Whether the student departed early
     */
    private boolean earlyDeparture;

    /**
     * Engagement score for this session (0.0 - 1.0)
     */
    private double engagementScore;

    /**
     * Presence quality score for this session (0.0 - 1.0)
     */
    private double presenceQuality;

    private String unitSemesterId;

    /**
     * Generates the document ID by concatenating studentId and sessionId
     * e.g. 12345678-FIT3077-2025S1-W1-LEC
     *
     * @return the document ID string
     */
    public String generateDocumentId() {
        return studentId + "-" + sessionId;
    }
}

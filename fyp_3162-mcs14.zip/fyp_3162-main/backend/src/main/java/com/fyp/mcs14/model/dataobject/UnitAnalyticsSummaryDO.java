package com.fyp.mcs14.model.dataobject;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;
/**
 * Data object class to represent unit-level analytics stored in the database
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UnitAnalyticsSummaryDO {

    /**
     * Unique identifier of the unit semester, used as document ID
     * e.g. FIT3077-2025-S1
     */
    private String unitSemesterId;

    /**
     * Total number of students in the unit
     * e.g. 120
     */
    private int totalStudents;

    /**
     * Average attendance rate across all students (0.0 - 1.0)
     * e.g. 0.83
     */
    private double avgAttendanceRate;

    /**
     * Average engagement score across all students (0.0 - 1.0)
     * e.g. 0.65
     */
    private double avgEngagementScore;

    /**
     * Average presence quality across all students (0.0 - 1.0)
     * e.g. 0.75
     */
    private double avgPresenceQuality;

    /**
     * Average risk score across all students (0.0 - 1.0)
     * e.g. 0.45
     */
    private double avgRiskScore;

    /**
     * Average trend slope across all students
     * Positive = improving, Negative = declining
     * e.g. -0.03
     */
    private double avgTrendSlope;

    /**
     * Total number of late arrivals across all students
     * e.g. 25
     */
    private int totalLateArrival;

    /**
     * Total number of early departures across all students
     * e.g. 15
     */
    private int totalEarlyDeparture;

    /**
     * Number of high risk students (riskScore >= 0.7)
     * e.g. 12
     */
    private int highRiskCount;

    /**
     * Number of medium risk students (0.4 <= riskScore < 0.7)
     * e.g. 30
     */
    private int mediumRiskCount;

    /**
     * Number of low risk students (riskScore < 0.4)
     * e.g. 78
     */
    private int lowRiskCount;

    /**
     * Number of students per cluster label
     * e.g. {Engaged: 10, Passive: 5, Independent: 3, At Risk: 2}
     */
    private Map<String, Integer> clusterDistribution;
}
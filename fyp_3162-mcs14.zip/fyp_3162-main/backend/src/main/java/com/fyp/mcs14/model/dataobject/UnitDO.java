package com.fyp.mcs14.model.dataobject;

import com.google.firebase.database.PropertyName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class to represent a unit stored in the database
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UnitDO {

    /**
     * Unique unit code, used as primary key
     * e.g. FIT3077
     */
    private String unitCode;

    /**
     * Full name of the unit
     * e.g. Software Architecture
     */
    @PropertyName("unit_name")
    private String unitName;

    /**
     * Faculty the unit belongs to
     * e.g. Faculty of IT
     */
    @PropertyName("faculty")
    private String faculty;

    /**
     * Credit points awarded for completing the unit
     * e.g. 6
     */
    @PropertyName("credit_points")
    private int creditPoints;
}
package com.fyp.mcs14.model.dataobject;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data object class to represent an assignment of a unit semester stored in the database
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UnitSemesterAssignmentDO {
    /**
     * Unique document ID
     * e.g. FIT3077-2025-S1-A1
     */
    private String id;

    /**
     * Assignment id
     * e.g. A1
     */
    private String assignmentId;

    /**
     * Assignment name
     * e.g. Assignment 1
     */
    private String assignmentName;
}
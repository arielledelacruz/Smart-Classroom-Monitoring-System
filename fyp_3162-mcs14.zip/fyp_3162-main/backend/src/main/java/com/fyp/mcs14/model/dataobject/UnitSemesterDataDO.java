package com.fyp.mcs14.model.dataobject;

import lombok.Data;

import java.util.List;

@Data
public class UnitSemesterDataDO {
    private String id;

    private int totalStudents;

    private List<String> studentIdList;
}

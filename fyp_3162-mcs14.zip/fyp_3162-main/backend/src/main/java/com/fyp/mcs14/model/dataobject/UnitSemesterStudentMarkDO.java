package com.fyp.mcs14.model.dataobject;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data object class to represent a student assignment mark stored in the database
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UnitSemesterStudentMarkDO {

    /**
     * Unique document ID
     * e.g. FIT3077-2025-S1-A1-12345678
     */
    private String id;

    /**
     * Marks obtained by the student
     * e.g. 85
     */
    private double marks;
}
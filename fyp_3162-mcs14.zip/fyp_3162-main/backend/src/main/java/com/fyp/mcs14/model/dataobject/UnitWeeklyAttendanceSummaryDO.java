package com.fyp.mcs14.model.dataobject;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Data object class to represent a unit weekly attendance summary stored in the database
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class UnitWeeklyAttendanceSummaryDO {

    /**
     * Unique id to store in db, used as document ID
     * e.g. FIT3077-2025-S2-W1
     */
    private String id;

    /**
     * Total number of attendances recorded in the week
     */
    private int totalAttendance;

    /**
     * Total number of absences recorded in the week
     */
    private int totalAbsence;

    /**
     * Total number of early departures recorded in the week
     */
    private int totalEarlyDeparture;

    /**
     * Total number of late arrivals recorded in the week
     */
    private int totalLateArrival;
}
package com.fyp.mcs14.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AnalyticsExplanationDTO {
    private String metricName;
    private double value;
    private String status;
    private String meaning;
    private String contributingFactor;
    private String recommendationForStudent;
    private String recommendationForLecturer;
}

package com.fyp.mcs14.model.dto;

import com.fyp.mcs14.model.enums.InsightCategory;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CategorizedInsightDTO {
    private InsightCategory category;
    private String message;
}

package com.fyp.mcs14.model.dto;

import java.util.List;

/**
 * DTO class to represent a lecturer and their associated units
 */
public class LecturerUnitsDTO {

    /**
     * Unique identifier of the lecturer
     * e.g. 12345678
     */
    private String lecturerId;

    /**
     * List of unit codes assigned to the lecturer
     * e.g. [FIT3077, FIT2099]
     */
    private List<String> lecturerUnitList;
}

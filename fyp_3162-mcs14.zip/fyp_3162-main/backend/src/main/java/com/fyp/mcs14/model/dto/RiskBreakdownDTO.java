package com.fyp.mcs14.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RiskBreakdownDTO {
    private double attendanceRisk;
    private double absenceRisk;
    private double trendRisk;
    private double presenceRisk;
    private double engagementRisk;
    private double finalRiskScore;
}

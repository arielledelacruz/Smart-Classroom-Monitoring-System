package com.fyp.mcs14.model.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class StudentFeedbackDTO {
    private String feedbackId;
    
    private String studentId;
    
    private String lecturerId;
    
    private String unitCode;
    
    private String feedbackContent;
    
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime createdAt;
    
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime updatedAt;
    
    private String feedbackType;
    
    private String studentName;
}

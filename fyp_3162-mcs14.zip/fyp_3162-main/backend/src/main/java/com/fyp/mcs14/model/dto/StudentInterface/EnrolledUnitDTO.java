package com.fyp.mcs14.model.dto.StudentInterface;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO class to represent an enrolled unit
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EnrolledUnitDTO {

    /**
     * Unique identifier of the unit semester
     * e.g. FIT3077-2025-S1
     */
    private String unitSemesterId;

    /**
     * Unit code
     * e.g. FIT3077
     */
    private String unitCode;

    /**
     * Full name of the unit
     * e.g. Software Architecture
     */
    private String unitName;
}

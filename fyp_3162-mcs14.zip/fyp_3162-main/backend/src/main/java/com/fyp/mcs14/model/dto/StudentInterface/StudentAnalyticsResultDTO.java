package com.fyp.mcs14.model.dto.StudentInterface;

import com.fyp.mcs14.model.dto.AnalyticsExplanationDTO;
import com.fyp.mcs14.model.dto.RiskBreakdownDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * DTO class to represent a student's analytics result for a specific unit
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StudentAnalyticsResultDTO {

    /**
     * Unique identifier of the student
     * e.g. 12345678
     */
    private String studentId;

    /**
     * Unique identifier of the unit semester
     * e.g. FIT3077-2025-S1
     */
    private String unitSemesterId;

    /**
     * Attendance rate (0.0 - 1.0)
     * e.g. 0.83
     */
    private double attendanceRate;

    /**
     * Engagement score (0.0 - 1.0)
     * e.g. 0.65
     */
    private double engagementScore;

    /**
     * Effective presence quality (0.0 - 1.0)
     * e.g. 0.75
     */
    private double effectivePresence;

    /**
     * Trend slope of attendance
     * Positive = improving, Negative = declining
     * e.g. -0.05
     */
    private double trendSlope;

    /**
     * Maximum consecutive absences
     * e.g. 3
     */
    private int consecutiveAbsences;

    /**
     * Risk score (0.0 - 1.0)
     * e.g. 0.72
     */
    private double riskScore;

    /**
     * Cluster label
     * e.g. Engaged, Passive, Independent, At Risk
     */
    private String clusterLabel;

    /**
     * Student-friendly insights
     * e.g. ["Your attendance has been declining over recent weeks"]
     */
    private List<String> insights;

    private RiskBreakdownDTO riskBreakdown;

    private List<AnalyticsExplanationDTO> explanations;
}

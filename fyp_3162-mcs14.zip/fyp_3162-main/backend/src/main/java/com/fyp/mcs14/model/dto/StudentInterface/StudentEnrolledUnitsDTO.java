package com.fyp.mcs14.model.dto.StudentInterface;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * DTO class to represent a student's enrolled units response
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StudentEnrolledUnitsDTO {

    /**
     * Unique identifier of the student
     * e.g. 12345678
     */
    private String studentId;

    /**
     * Academic year
     * e.g. 2025
     */
    private String year;

    /**
     * Semester
     * e.g. S1
     */
    private String semester;

    /**
     * Total number of enrolled units
     * e.g. 4
     */
    private int totalUnits;

    /**
     * List of enrolled unit details
     */
    private List<EnrolledUnitDTO> enrolledUnits;
}

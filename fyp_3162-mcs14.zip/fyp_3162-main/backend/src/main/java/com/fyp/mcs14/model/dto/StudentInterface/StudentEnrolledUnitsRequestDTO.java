package com.fyp.mcs14.model.dto.StudentInterface;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO class to represent a request to get all enrolled units of a student
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class StudentEnrolledUnitsRequestDTO {

    /**
     * Unique identifier of the student
     * e.g. 12345678
     */
    private String studentId;

    /**
     * Academic year to filter by
     * e.g. 2025
     */
    private String year;

    /**
     * Semester to filter by
     * e.g. S1
     */
    private String semester;
}

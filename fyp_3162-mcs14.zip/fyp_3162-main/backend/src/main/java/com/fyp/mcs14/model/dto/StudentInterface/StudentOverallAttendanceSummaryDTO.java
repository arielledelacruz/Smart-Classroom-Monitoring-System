package com.fyp.mcs14.model.dto.StudentInterface;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * DTO class to represent a student's overall attendance summary across all enrolled units
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StudentOverallAttendanceSummaryDTO {

    /**
     * Unique identifier of the student
     * e.g. 12345678
     */
    private String studentId;

    /**
     * Academic year
     * e.g. 2025
     */
    private String year;

    /**
     * Semester
     * e.g. S1
     */
    private String semester;

    /**
     * Overall attendance rate across all units (0.0 - 1.0)
     * e.g. 0.83
     */
    private double overallAttendanceRate;

    /**
     * Overall engagement score across all units (0.0 - 1.0)
     * e.g. 0.65
     */
    private double overallEngagementScore;

    /**
     * Overall risk score across all units (0.0 - 1.0)
     * e.g. 0.45
     */
    private double overallRiskScore;

    /**
     * List of unit attendance summaries per enrolled unit
     */
    private List<StudentUnitSummaryCardDTO> unitSummaryList;
}
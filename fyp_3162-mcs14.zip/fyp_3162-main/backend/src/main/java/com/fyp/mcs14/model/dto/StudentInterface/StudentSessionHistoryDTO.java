package com.fyp.mcs14.model.dto.StudentInterface;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * DTO class to represent a student's session history for a specific unit
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StudentSessionHistoryDTO {

    /**
     * Unique identifier of the student
     * e.g. 12345678
     */
    private String studentId;

    /**
     * Unique identifier of the unit semester
     * e.g. FIT3077-2025-S1
     */
    private String unitSemesterId;

    /**
     * Total number of sessions
     * e.g. 12
     */
    private int totalSessions;

    /**
     * Total number of sessions attended
     * e.g. 10
     */
    private int totalPresent;

    /**
     * List of individual session records
     */
    private List<StudentSessionRecordDTO> sessions;
}

package com.fyp.mcs14.model.dto.StudentInterface;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO class to represent a single session record for a student
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StudentSessionRecordDTO {

    /**
     * Session identifier
     * e.g. FIT3077-2025S1-W1-LEC
     */
    private String sessionId;

    /**
     * Week of the session
     * e.g. W1
     */
    private String week;

    /**
     * Class type
     * e.g. LEC, TUT
     */
    private String classType;

    /**
     * Whether the student was present
     */
    private boolean present;

    /**
     * Whether the student arrived late
     */
    private boolean lateArrival;

    /**
     * Whether the student departed early
     */
    private boolean earlyDeparture;

    /**
     * Engagement score for this session (0.0 - 1.0)
     * e.g. 0.65
     */
    private double engagementScore;

    /**
     * Presence quality for this session (0.0 - 1.0)
     * e.g. 0.75
     */
    private double presenceQuality;
}

package com.fyp.mcs14.model.dto.StudentInterface;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * DTO class to represent a student's detailed attendance data for a specific unit
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StudentUnitAttendanceDetailDTO {

    /**
     * Unique identifier of the student
     * e.g. 12345678
     */
    private String studentId;

    /**
     * Unique identifier of the unit semester
     * e.g. FIT3077-2025-S1
     */
    private String unitSemesterId;

    /**
     * Unit code
     * e.g. FIT3077
     */
    private String unitCode;

    /**
     * Attendance rate (0.0 - 1.0)
     * e.g. 0.83
     */
    private double attendanceRate;

    /**
     * Engagement score (0.0 - 1.0)
     * e.g. 0.65
     */
    private double engagementScore;

    /**
     * Risk score (0.0 - 1.0)
     * e.g. 0.45
     */
    private double riskScore;

    /**
     * Cluster label
     * e.g. Engaged, Passive, Independent, At Risk
     */
    private String clusterLabel;

    /**
     * Maximum consecutive absences
     * e.g. 3
     */
    private int consecutiveAbsences;

    /**
     * Total number of late arrivals
     * e.g. 2
     */
    private int totalLateArrival;

    /**
     * Total number of early departures
     * e.g. 1
     */
    private int totalEarlyDeparture;

    /**
     * Attendance trend
     * e.g. IMPROVING, STABLE, DECLINING
     */
    private String trend;

    /**
     * Weekly attendance breakdown for charts
     */
    private List<StudentWeeklyAttendanceDTO> weeklyBreakdown;
}

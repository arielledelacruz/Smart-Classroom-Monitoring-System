package com.fyp.mcs14.model.dto.StudentInterface;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO class to represent a request scoped to a student and a specific unit semester
 * Used for: unit attendance detail, analytics, session history
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class StudentUnitRequestDTO {

    /**
     * Unique identifier of the student
     * e.g. 12345678
     */
    private String studentId;

    /**
     * Unique identifier of the unit semester
     * e.g. FIT3077-2025-S1
     */
    private String unitCode;

    private String year;

    private String semester;
}

package com.fyp.mcs14.model.dto.StudentInterface;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO class to represent a student's attendance summary card for a unit
 * Used in the overall summary page as a card per unit
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StudentUnitSummaryCardDTO {

    /**
     * Unique identifier of the unit semester
     * e.g. FIT3077-2025-S1
     */
    private String unitSemesterId;

    /**
     * Unit code
     * e.g. FIT3077
     */
    private String unitCode;

    /**
     * Attendance rate for this unit (0.0 - 1.0)
     * e.g. 0.83
     */
    private double attendanceRate;

    /**
     * Engagement score for this unit (0.0 - 1.0)
     * e.g. 0.65
     */
    private double engagementScore;

    /**
     * Risk score for this unit (0.0 - 1.0)
     * e.g. 0.45
     */
    private double riskScore;

    /**
     * Cluster label assigned by clustering algorithm
     * e.g. Engaged, Passive, Independent, At Risk
     */
    private String clusterLabel;

    /**
     * Total number of late arrivals
     * e.g. 2
     */
    private int totalLateArrival;

    /**
     * Total number of early departures
     * e.g. 1
     */
    private int totalEarlyDeparture;

    /**
     * Maximum consecutive absences
     * e.g. 3
     */
    private int consecutiveAbsences;

    /**
     * Attendance trend
     * e.g. IMPROVING, STABLE, DECLINING
     */
    private String trend;
}
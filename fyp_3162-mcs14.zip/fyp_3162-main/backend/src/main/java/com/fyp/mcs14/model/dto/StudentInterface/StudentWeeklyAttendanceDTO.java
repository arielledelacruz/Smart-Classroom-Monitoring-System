package com.fyp.mcs14.model.dto.StudentInterface;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO class to represent a student's attendance data for a specific week
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StudentWeeklyAttendanceDTO {

    /**
     * Week label
     * e.g. W1
     */
    private String week;

    /**
     * Whether the student was present
     */
    private boolean present;

    /**
     * Whether the student arrived late
     */
    private boolean lateArrival;

    /**
     * Whether the student departed early
     */
    private boolean earlyDeparture;

    /**
     * Engagement score for this week (0.0 - 1.0)
     * e.g. 0.65
     */
    private double engagementScore;

    /**
     * Presence quality for this week (0.0 - 1.0)
     * e.g. 0.75
     */
    private double presenceQuality;
}

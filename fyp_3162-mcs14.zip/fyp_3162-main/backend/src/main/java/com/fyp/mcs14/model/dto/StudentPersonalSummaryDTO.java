package com.fyp.mcs14.model.dto;

import lombok.Data;

@Data
public class StudentPersonalSummaryDTO {
}

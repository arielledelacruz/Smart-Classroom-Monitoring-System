package com.fyp.mcs14.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO class to represent KPI summary cards for a unit
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UnitKpiDTO {

    /**
     * Total number of students enrolled
     * e.g. 120
     */
    private int totalStudents;

    /**
     * Overall attendance rate (0.0 - 1.0)
     * e.g. 0.83
     */
    private double avgAttendanceRate;

    /**
     * Overall engagement score (0.0 - 1.0)
     * e.g. 0.65
     */
    private double avgEngagementScore;

    /**
     * Overall risk score (0.0 - 1.0)
     * e.g. 0.45
     */
    private double avgRiskScore;

    /**
     * Number of high risk students
     * e.g. 12
     */
    private int highRiskCount;

    /**
     * Total late arrivals across all students
     * e.g. 25
     */
    private int totalLateArrival;

    /**
     * Total early departures across all students
     * e.g. 15
     */
    private int totalEarlyDeparture;
}
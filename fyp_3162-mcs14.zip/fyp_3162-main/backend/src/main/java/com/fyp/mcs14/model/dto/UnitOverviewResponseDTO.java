package com.fyp.mcs14.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

/**
 * DTO class to represent a unit overview response for a lecturer
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UnitOverviewResponseDTO {

    /**
     * Unit semester identifier
     * e.g. FIT3077-2025-S1
     */
    private String unitSemesterId;

    /**
     * Unit code
     * e.g. FIT3077
     */
    private String unitCode;

    /**
     * Academic year
     * e.g. 2025
     */
    private String year;

    /**
     * Semester
     * e.g. S1
     */
    private String semester;

    /**
     * KPI summary cards shown at the top of the page
     */
    private UnitKpiDTO kpi;

    /**
     * Weekly breakdown data for charts
     */
    private List<UnitWeeklyDataDTO> weeklyData;

    /**
     * Cluster distribution for pie/donut chart
     * e.g. {Engaged: 10, Passive: 5, Independent: 3, At Risk: 2}
     */
    private Map<String, Integer> clusterDistribution;

    /**
     * Risk distribution breakdown
     */
    private UnitRiskDistributionDTO riskDistribution;


    private List<CategorizedInsightDTO> analyticalExplanations;
    private List<CategorizedInsightDTO> recommendations;
}

package com.fyp.mcs14.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO class to represent risk distribution of students in a unit
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UnitRiskDistributionDTO {

    /**
     * Number of low risk students (riskScore < 0.4)
     */
    private int lowRiskCount;

    /**
     * Number of medium risk students (0.4 <= riskScore < 0.7)
     */
    private int mediumRiskCount;

    /**
     * Number of high risk students (riskScore >= 0.7)
     */
    private int highRiskCount;

    /**
     * Percentage of low risk students (0.0 - 1.0)
     */
    private double lowRiskRate;

    /**
     * Percentage of medium risk students (0.0 - 1.0)
     */
    private double mediumRiskRate;

    /**
     * Percentage of high risk students (0.0 - 1.0)
     */
    private double highRiskRate;
}
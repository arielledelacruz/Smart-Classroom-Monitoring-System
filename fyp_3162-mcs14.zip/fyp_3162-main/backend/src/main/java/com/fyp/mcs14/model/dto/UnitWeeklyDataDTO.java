package com.fyp.mcs14.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO class to represent weekly attendance and engagement breakdown for charts
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UnitWeeklyDataDTO {

    /**
     * Week label
     * e.g. W1
     */
    private String week;

    /**
     * Total number of students present
     * e.g. 95
     */
    private int totalAttendance;

    /**
     * Total number of students absent
     * e.g. 5
     */
    private int totalAbsence;

    /**
     * Total number of late arrivals
     * e.g. 3
     */
    private int totalLateArrival;

    /**
     * Total number of early departures
     * e.g. 2
     */
    private int totalEarlyDeparture;

    /**
     * Attendance rate for the week (0.0 - 1.0)
     * e.g. 0.95
     */
    private double attendanceRate;

    /**
     * Average engagement score for the week (0.0 - 1.0)
     * e.g. 0.65
     */
    private double avgEngagementScore;

    private double avgRiskScore;
}

package com.fyp.mcs14.model.dto.authentication;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO class to represent authenticated user data returned to frontend after successful login
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AuthUserDTO {
    /**
     * Unique identifier of the user
     */
    private String id;

    /**
     * Email address of the authenticated user
     * e.g. john.doe@example.com
     */
    private String email;

    /**
     * Phone number of authenticated user
     */
    private String phone;

    /**
     * Role of the authenticated user in the system
     * e.g. STUDENT, LECTURER
     */
    private String userRole;

    /**
     * Full name of the authenticated user
     * e.g. John Doe
     */
    private String name;

    /**
     * URL of the user's profile photo stored in Firebase Cloud Storage
     * e.g. "https://storage.googleapis.com/bucket/profile-photos/lecturers/L001.jpg"
     * Null if no photo has been uploaded
     */
    private String profilePhotoUrl;

    /**
     * Faculty the user belongs to
     * e.g. "Faculty of IT"
     */
    private String faculty;
}
package com.fyp.mcs14.model.dto.authentication;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LecturerAuthUserDTO extends AuthUserDTO {
    private String office;

    private List<String> researchArea;
}

package com.fyp.mcs14.model.dto.authentication;

import lombok.Data;

/**
 * DTO class to represent a login request sent from the frontend
 */
@Data
public class LoginRequestDTO {

    /**
     * Email address of the user attempting to login
     * e.g. john.doe@example.com
     */
    String email;

    /**
     * Password of the user account
     * e.g. P@ssw0rd
     */
    String password;
}

package com.fyp.mcs14.model.dto.authentication;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class StudentAuthUserDTO extends AuthUserDTO {
    private int enrolledYear;
}

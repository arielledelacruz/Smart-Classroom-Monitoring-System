package com.fyp.mcs14.model.dto.dashboard;

import lombok.Data;

import java.util.List;

/**
 * DTO class to represent a dashboard filter request sent from the frontend
 */
@Data
public class DashboardFilterRequestDTO {

    /**
     * List of unit codes to filter by
     * e.g. [FIT3077, FIT2099]
     */
    private List<String> unitCodeList;

    /**
     * Start week number of the filter range
     * e.g. 1
     */
    private int weekStart;

    /**
     * End week number of the filter range
     * e.g. 12
     */
    private int weekEnd;

    /**
     * Academic year to filter by
     * e.g. 2025
     */
    private String year;

    /**
     * Semester to filter by
     * e.g. S1, S2
     */
    private String semester;
}

package com.fyp.mcs14.model.dto.dashboard;

public class DashboardQueryAvailableUnitDTO {
}

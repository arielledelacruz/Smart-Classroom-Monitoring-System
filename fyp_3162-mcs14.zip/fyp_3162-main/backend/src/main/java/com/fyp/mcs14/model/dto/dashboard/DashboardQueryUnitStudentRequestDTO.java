package com.fyp.mcs14.model.dto.dashboard;

import lombok.Data;

@Data
public class DashboardQueryUnitStudentRequestDTO {
    String unitCode;

    int year;

    String semester;
}

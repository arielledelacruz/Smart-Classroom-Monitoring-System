package com.fyp.mcs14.model.dto.dashboard;

import com.fyp.mcs14.model.dto.UnitOverviewResponseDTO;
import com.fyp.mcs14.model.model.attendance.UnitAttendanceSummary;
import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * DTO class to represent a dashboard filter response returned to the frontend
 */
@Builder
@Data
public class DashboardUnitAttendanceSummaryResponseDTO {

    /**
     * List of unit attendance summaries matching the applied filter
     */
    private List<UnitOverviewResponseDTO> unitOverviewList;
}
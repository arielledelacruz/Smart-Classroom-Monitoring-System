package com.fyp.mcs14.model.dto.dashboard;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DashboardUnitSemesterStudentsResponseDTO {

    /**
     * Unique identifier of the unit semester
     * e.g. FIT3077-2025-S1
     */
    private String unitSemesterId;

    /**
     * Total number of students enrolled in the unit semester
     * e.g. 120
     */
    private int totalStudents;

    /**
     * List of student data enrolled in the unit semester
     */
    private List<StudentListViewDTO> students;
}

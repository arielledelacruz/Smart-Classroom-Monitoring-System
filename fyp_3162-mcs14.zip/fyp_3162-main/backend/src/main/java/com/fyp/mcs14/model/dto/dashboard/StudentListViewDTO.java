package com.fyp.mcs14.model.dto.dashboard;

import lombok.Data;

@Data
public class StudentListViewDTO {
    private String id;

    private String name;

    private String profilePhotoUrl;

    private double engagementScore;

    private double attendanceRate;
}

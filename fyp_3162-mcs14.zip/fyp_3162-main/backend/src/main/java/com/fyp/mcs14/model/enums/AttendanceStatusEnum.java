package com.fyp.mcs14.model.enums;

public enum AttendanceStatusEnum {
    PRESENT,
    ABSENT,
    LATE_ARRIVAL,
    EARLY_DEPARTURE
}

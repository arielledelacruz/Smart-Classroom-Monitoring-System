package com.fyp.mcs14.model.enums;

import lombok.Getter;

import java.util.Objects;

@Getter
public enum ClassTypeEnum {
    TUTORIAL("T"),
    APPLIED("A");

    private final String code;

    ClassTypeEnum(String code) {
        this.code = code;
    }

    public static ClassTypeEnum getByCode(String code){
        for (ClassTypeEnum classTypeEnum : ClassTypeEnum.values()) {
            if (Objects.equals(classTypeEnum.code, code)) {
                return classTypeEnum;
            }
        }
        throw new IllegalArgumentException("Invalid class type code: " + code);
    }
}

package com.fyp.mcs14.model.enums;

public enum FacultyEnum {
    SCHOOL_OF_INFORMATION_TECHNOLOGY
}

package com.fyp.mcs14.model.enums;

public enum InsightCategory {
    ATTENDANCE,
    ENGAGEMENT,
    RISK,
    ATTENDANCE_QUALITY
}

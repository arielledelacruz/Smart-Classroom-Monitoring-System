package com.fyp.mcs14.model.enums;

public enum MotionTypeEnum {
    RAISING_HAND,
    SITTING,
    STANDING;

    public static MotionTypeEnum getByString(String s) {
        if ("Sitting Full Body".equals(s) || "Sitting Partial Body".equals(s)) {
            return SITTING;
        }
        else if ("Standing Full Body".equals(s)) {
            return STANDING;
        }
        return RAISING_HAND;
    }
}

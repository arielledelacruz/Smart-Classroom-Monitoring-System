package com.fyp.mcs14.model.enums;

public enum ResponseStatusEnum {
    SUCCESS,
    FAIL;
}

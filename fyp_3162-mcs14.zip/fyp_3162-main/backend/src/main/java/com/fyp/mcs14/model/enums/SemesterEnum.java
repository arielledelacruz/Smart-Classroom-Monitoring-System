package com.fyp.mcs14.model.enums;

public enum SemesterEnum {
    S1,
    S2
}

package com.fyp.mcs14.model.enums;

public enum UnitCodeEnum {
    FIT2099,

    FIT3077
}

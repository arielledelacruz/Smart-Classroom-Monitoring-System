package com.fyp.mcs14.model.enums;

public enum UserRoleEnum {
    STUDENT,
    LECTURER
}

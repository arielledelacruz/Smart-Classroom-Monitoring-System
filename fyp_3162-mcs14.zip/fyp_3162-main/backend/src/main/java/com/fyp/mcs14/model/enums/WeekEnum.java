package com.fyp.mcs14.model.enums;

public enum WeekEnum {
    WEEK_1(1),
    WEEK_2(2),
    WEEK_3(3),
    WEEK_4(4),
    WEEK_5(5),
    WEEK_6(6),
    WEEK_7(7),
    WEEK_8(8),
    WEEK_9(9),
    WEEK_10(10);

    private final int weekCode;

    WeekEnum(int weekCode) {
        this.weekCode = weekCode;
    }

    public int getWeekCode() {
        return this.weekCode;
    }

    public static WeekEnum getByCode(int weekCode) {
        for (WeekEnum week : WeekEnum.values()) {
            if (week.weekCode == weekCode) {
                return week;
            }
        }
        throw new IllegalArgumentException("Invalid week code: " + weekCode);
    }

    public static WeekEnum getByString(String value) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("Week value cannot be null or empty");
        }

        // handle "W7" format
        try {
            int code = Integer.parseInt(value.trim().substring(1));  // "W7" → 7
            return getByCode(code);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid excel week format: " + value);
        }
    }

    public static WeekEnum fromCode(String value) {
        if (value == null || value.isBlank()) return null;
        try {
            // handle "W1", "W2" etc
            if (value.toUpperCase().startsWith("W")) {
                int code = Integer.parseInt(value.trim().substring(1));
                for (WeekEnum week : WeekEnum.values()) {
                    if (week.weekCode == code) return week;
                }
            }
            return null;  // not a week string, return null instead of throwing
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public String getWeekCodeString(){
        return "W" + this.getWeekCode();
    }
}

package com.fyp.mcs14.model.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ClusterPoint {
    private String studentId;
    private double[] features;

    private int cluster;
}

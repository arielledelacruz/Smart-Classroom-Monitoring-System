package com.fyp.mcs14.model.model;

import com.fyp.mcs14.model.enums.FacultyEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Lecturer {
    private String id;
    private String name;
    private String email;
    private String phone;
    private FacultyEnum faculty;
    private String profilePhotoUrl;
    private String office;
    private List<String> researchArea;
}
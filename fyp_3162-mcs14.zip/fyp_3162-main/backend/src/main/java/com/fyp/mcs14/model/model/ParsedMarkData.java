package com.fyp.mcs14.model.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Class to represent parsed mark data from an Excel file
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ParsedMarkData {

    /**
     * List of assignments parsed from the Excel file
     */
    private List<UnitSemesterAssignment> assignments;

    /**
     * List of student marks parsed from the Excel file
     */
    private List<UnitSemesterStudentMark> studentMarks;
}
package com.fyp.mcs14.model.model;

import com.fyp.mcs14.analytics.PresenceQualityCalculator;
import com.fyp.mcs14.analytics.insights.EngagementCalculator;
import com.fyp.mcs14.model.model.attendance.SessionId;
import com.fyp.mcs14.model.model.attendance.UnitYearSemesterId;
import com.fyp.mcs14.model.model.excel.RawAttendanceRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Component to build a StudentSessionSummary from a RawAttendanceRecord
 */
@Component
public class SessionSummaryBuilder {

    @Autowired
    private EngagementCalculator engagementCalculator;

    @Autowired
    private PresenceQualityCalculator presenceQualityCalculator;

    private static final int DEFAULT_START = 9 * 60;  // 09:00
    private static final int DEFAULT_END   = 11 * 60; // 11:00

    private static final int LATE_THRESHOLD_MINUTES = 15;
    private static final int EARLY_THRESHOLD_MINUTES = 15;

    /**
     * Builds a StudentSessionSummary from a RawAttendanceRecord
     *
     * @param record the raw attendance record
     * @return the computed StudentSessionSummary
     */
    public StudentSessionSummary build(RawAttendanceRecord record) {
        boolean present = record.getRecords() != null && !record.getRecords().isEmpty();

        double engagement    = present ? engagementCalculator.compute(record) : 0;
        double presenceQual  = present ? presenceQualityCalculator.compute(record, DEFAULT_START, DEFAULT_END) : 0;
        boolean lateArrival  = present && isLateArrival(record);
        boolean earlyDep     = present && isEarlyDeparture(record);

        return StudentSessionSummary.builder()
                .studentId(record.getStudentId())
                .sessionId(record.getSessionId())
                .present(present)
                .lateArrival(lateArrival)
                .earlyDeparture(earlyDep)
                .engagementScore(engagement)
                .presenceQuality(presenceQual)
                .build();
    }

    // In SessionSummaryBuilder or a new AbsentSessionFactory
    public StudentSessionSummary buildAbsent(String studentId, SessionId sessionId) {
        return StudentSessionSummary.builder()
                .studentId(studentId)
                .sessionId(SessionId.builder()
                        .studentId(studentId)
                        .unitCode(sessionId.getUnitCode())
                        .year(sessionId.getYear())
                        .semester(sessionId.getSemester())
                        .week(sessionId.getWeek())
                        .classType(sessionId.getClassType())
                        .build())
                .present(false)
                .lateArrival(false)
                .earlyDeparture(false)
                .engagementScore(0)
                .presenceQuality(0)
                .build();
    }

    /**
     * Builds a StudentUnitSummary from a list of RawAttendanceRecords for one student in one unit
     *
     * @param studentId   the student id
     * @param unitId      the unit year semester id
     * @param records     ordered list of raw attendance records
     * @return the computed StudentUnitSummary
     */
    public StudentUnitSummary buildUnitSummary(String studentId,
                                               UnitYearSemesterId unitId,
                                               List<RawAttendanceRecord> records) {
        List<StudentSessionSummary> sessions = records.stream()
                .map(this::build)
                .collect(Collectors.toList());

        int totalSessions    = sessions.size();
        int totalPresent     = (int) sessions.stream().filter(StudentSessionSummary::isPresent).count();
        int totalLateArrival = (int) sessions.stream().filter(StudentSessionSummary::isLateArrival).count();
        int totalEarlyDep    = (int) sessions.stream().filter(StudentSessionSummary::isEarlyDeparture).count();

        double attendanceRate = totalSessions == 0 ? 0 : (double) totalPresent / totalSessions;

        double avgEngagement = sessions.stream()
                .filter(StudentSessionSummary::isPresent)
                .mapToDouble(StudentSessionSummary::getEngagementScore)
                .average().orElse(0);

        double avgPresence = sessions.stream()
                .filter(StudentSessionSummary::isPresent)
                .mapToDouble(StudentSessionSummary::getPresenceQuality)
                .average().orElse(0);

        return StudentUnitSummary.builder()
                .studentId(studentId)
                .unitYearSemesterId(unitId)
                .sessions(sessions)
                .totalSessions(totalSessions)
                .totalPresent(totalPresent)
                .totalLateArrival(totalLateArrival)
                .totalEarlyDeparture(totalEarlyDep)
                .attendanceRate(attendanceRate)
                .avgEngagementScore(avgEngagement)
                .avgPresenceQuality(avgPresence)
                .build();
    }

    /**
     * Late arrival = student's first motion record is more than 15 minutes
     * after the session start time
     *
     * @param record the raw attendance record
     * @return true if student arrived late
     */
    private boolean isLateArrival(RawAttendanceRecord record) {
        if (record.getRecords() == null || record.getRecords().isEmpty()) return false;
        if (record.getStartTime() == null) return false;

        // find the earliest motion time
        LocalTime firstMotionTime = record.getRecords().stream()
                .map(r -> LocalTime.parse(r.getTime()))
                .min(LocalTime::compareTo)
                .orElse(null);

        if (firstMotionTime == null) return false;

        // late if first motion is more than 15 mins after session start
        return firstMotionTime.isAfter(record.getStartTime().plusMinutes(LATE_THRESHOLD_MINUTES));
    }

    /**
     * Early departure = student's last motion record is more than 15 minutes
     * before the session end time
     *
     * @param record the raw attendance record
     * @return true if student departed early
     */
    private boolean isEarlyDeparture(RawAttendanceRecord record) {
        if (record.getRecords() == null || record.getRecords().isEmpty()) return false;
        if (record.getEndTime() == null) return false;

        // find the latest motion time
        LocalTime lastMotionTime = record.getRecords().stream()
                .map(r -> LocalTime.parse(r.getTime()))
                .max(LocalTime::compareTo)
                .orElse(null);

        if (lastMotionTime == null) return false;

        // early departure if last motion is more than 15 mins before session end
        return lastMotionTime.isBefore(record.getEndTime().minusMinutes(EARLY_THRESHOLD_MINUTES));
    }
}

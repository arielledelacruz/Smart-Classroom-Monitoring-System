package com.fyp.mcs14.model.model;

import com.fyp.mcs14.model.dto.AnalyticsExplanationDTO;
import com.fyp.mcs14.model.dto.RiskBreakdownDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Class to represent the analytics result of a student in a unit semester
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StudentAnalyticsResult {

    /**
     * Unique identifier of the student
     * e.g. 12345678
     */
    private String studentId;

    /**
     * Overall attendance rate (0.0 - 1.0)
     * e.g. 0.83
     */
    private double attendanceRate;

    /**
     * Average engagement score across all present sessions (0.0 - 1.0)
     * e.g. 0.65
     */
    private double engagementScore;

    /**
     * Effective presence quality across all present sessions (0.0 - 1.0)
     * e.g. 0.75
     */
    private double effectivePresence;

    /**
     * Trend slope of attendance over sessions
     * Positive = improving, Negative = declining
     * e.g. -0.05
     */
    private double trendSlope;

    /**
     * Maximum consecutive absences recorded
     * e.g. 3
     */
    private int consecutiveAbsences;

    /**
     * Overall risk score (0.0 - 1.0)
     * e.g. 0.72
     */
    private double riskScore;

    /**
     * Cluster label assigned by clustering algorithm
     * e.g. Engaged, Passive, Independent, At Risk
     */
    private String clusterLabel;

    /**
     * List of generated insights for this student
     */
    private List<String> insights;

    private int totalLateArrival;

    private int totalEarlyDeparture;

    private List<AnalyticsExplanationDTO> explanations;

    private RiskBreakdownDTO riskBreakdown;
}

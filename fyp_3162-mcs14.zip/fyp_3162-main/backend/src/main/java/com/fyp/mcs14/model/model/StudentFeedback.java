package com.fyp.mcs14.model.model;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class StudentFeedback {
    private String feedbackId;
    
    private String studentId;
    
    private String lecturerId;
    
    private String unitCode;
    
    private String feedbackContent;
    
    private LocalDateTime createdAt;
    
    private LocalDateTime updatedAt;
    
    private String feedbackType; // e.g., "ATTENDANCE", "ENGAGEMENT", "PERFORMANCE", "GENERAL"
}

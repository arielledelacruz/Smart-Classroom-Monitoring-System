package com.fyp.mcs14.model.model;

import com.fyp.mcs14.model.model.attendance.SessionId;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class to represent a summarised attendance record of a student in a single session
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StudentSessionSummary {

    /**
     * Unique identifier of the student
     * e.g. 12345678
     */
    private String studentId;

    /**
     * Session identifier
     * e.g. FIT3077-2025-S1-W1-LEC
     */
    private SessionId sessionId;

    /**
     * Whether the student was present in the session
     */
    private boolean present;

    /**
     * Whether the student arrived late
     */
    private boolean lateArrival;

    /**
     * Whether the student departed early
     */
    private boolean earlyDeparture;

    /**
     * Engagement score for this session (0.0 - 1.0)
     * computed from motion records
     */
    private double engagementScore;

    /**
     * Presence quality score for this session (0.0 - 1.0)
     * computed from active duration / session duration
     */
    private double presenceQuality;
}

package com.fyp.mcs14.model.model;

import com.fyp.mcs14.model.model.attendance.UnitYearSemesterId;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Class to represent aggregated attendance data of a student in a unit semester
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StudentUnitSummary {

    /**
     * Unique identifier of the student
     * e.g. 12345678
     */
    private String studentId;

    /**
     * Unique identifier of the unit semester
     * e.g. FIT3077-2025-S1
     */
    private UnitYearSemesterId unitYearSemesterId;

    /**
     * Ordered list of session summaries across all weeks
     * ordered by week and class type
     */
    private List<StudentSessionSummary> sessions;

    /**
     * Total number of sessions in the unit
     * e.g. 12
     */
    private int totalSessions;

    /**
     * Total number of sessions the student was present
     * e.g. 10
     */
    private int totalPresent;

    /**
     * Total number of late arrivals
     * e.g. 2
     */
    private int totalLateArrival;

    /**
     * Total number of early departures
     * e.g. 1
     */
    private int totalEarlyDeparture;

    /**
     * Overall attendance rate (0.0 - 1.0)
     * e.g. 0.83
     */
    private double attendanceRate;

    /**
     * Average engagement score across all present sessions (0.0 - 1.0)
     * e.g. 0.65
     */
    private double avgEngagementScore;

    /**
     * Average presence quality across all present sessions (0.0 - 1.0)
     * e.g. 0.75
     */
    private double avgPresenceQuality;
}
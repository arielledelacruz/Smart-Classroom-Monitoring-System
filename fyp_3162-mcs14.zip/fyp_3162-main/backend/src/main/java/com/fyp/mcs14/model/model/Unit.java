package com.fyp.mcs14.model.model;

import com.fyp.mcs14.model.enums.UnitCodeEnum;
import lombok.Data;

import java.util.List;

@Data
public class Unit {

    /**
     * Unique unit code, used as primary key
     * e.g. FIT3077
     */
    private UnitCodeEnum unitCode;

    /**
     * Full name of the unit
     * e.g. Software Architecture
     */
    private String unitName;

    /**
     * Faculty the unit belongs to
     * e.g. Faculty of IT
     */
    private String faculty;

    /**
     * Credit points awarded for completing the unit
     * e.g. 6
     */
    private int creditPoints;
}

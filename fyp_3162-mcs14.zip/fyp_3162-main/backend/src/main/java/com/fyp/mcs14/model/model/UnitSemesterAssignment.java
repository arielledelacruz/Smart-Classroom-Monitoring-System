package com.fyp.mcs14.model.model;

import com.fyp.mcs14.model.model.attendance.UnitYearSemesterId;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class to represent an assignment of a unit semester
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UnitSemesterAssignment {

    /**
     * Unique identifier of the unit semester
     * e.g. FIT3077-2025-S1
     */
    private UnitYearSemesterId unitYearSemesterId;

    /**
     * Assignment id
     * e.g. A1
     */
    private String assignmentId;

    /**
     * Assignment name
     * e.g. Assignment 1
     */
    private String assignmentName;

    /**
     * Generates a unique string ID for this assignment
     * e.g. FIT3077-2025-S1-A1
     */
    public String generateUniqueId() {
        return unitYearSemesterId.generateUniqueId() + "-" + assignmentId;
    }
}
package com.fyp.mcs14.model.model;

import com.fyp.mcs14.model.model.attendance.UnitYearSemesterId;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UnitSemesterData {
    private UnitYearSemesterId id;

    private int totalStudents;

    private List<String> studentIdList;
}

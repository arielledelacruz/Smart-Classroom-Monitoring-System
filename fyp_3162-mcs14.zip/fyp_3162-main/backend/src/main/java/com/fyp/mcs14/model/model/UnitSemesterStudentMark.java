package com.fyp.mcs14.model.model;

import com.fyp.mcs14.model.model.attendance.UnitYearSemesterId;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class to represent a student assignment mark
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UnitSemesterStudentMark {

    /**
     * Unique identifier of the unit semester
     * e.g. FIT3077-2025-S1
     */
    private UnitYearSemesterId unitYearSemesterId;

    /**
     * Assignment id
     * e.g. A1
     */
    private String assignmentId;

    /**
     * Unique identifier of the student
     * e.g. 12345678
     */
    private String studentId;

    /**
     * Marks obtained by the student
     * e.g. 85
     */
    private double marks;

    /**
     * Generates a unique string ID for this student mark
     * e.g. FIT3077-2025-S1-A1-12345678
     */
    public String generateUniqueId() {
        return unitYearSemesterId.generateUniqueId() + "-" + assignmentId + "-" + studentId;
    }
}
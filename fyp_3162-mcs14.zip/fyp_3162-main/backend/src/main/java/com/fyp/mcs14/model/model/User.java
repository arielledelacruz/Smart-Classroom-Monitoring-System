package com.fyp.mcs14.model.model;

import lombok.Data;

@Data
public class User {
    private String email;

    private String password;
}

package com.fyp.mcs14.model.model.attendance;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Abstract class to represent common attendance data fields
 */
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class AbstractAttendanceData {

    /**
     * Total number of attendances recorded
     * e.g. 10
     */
    private int totalAttendance;

    /**
     * Total number of absences recorded
     * e.g. 2
     */
    private int totalAbsence;

    /**
     * Total number of early departures recorded
     * e.g. 1
     */
    private int totalEarlyDeparture;

    /**
     * Total number of late arrivals recorded
     * e.g. 3
     */
    private int totalLateArrival;
}

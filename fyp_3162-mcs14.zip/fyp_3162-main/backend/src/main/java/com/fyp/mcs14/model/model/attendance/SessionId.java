package com.fyp.mcs14.model.model.attendance;

import com.fyp.mcs14.model.enums.ClassTypeEnum;
import com.fyp.mcs14.model.enums.SemesterEnum;
import com.fyp.mcs14.model.enums.UnitCodeEnum;
import com.fyp.mcs14.model.enums.WeekEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class to represent a unique session identifier for a student,
 * combining student and class scheduling information
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SessionId {

    /**
     * Unique identifier of the student
     * e.g. 12345678
     */
    private String studentId;

    /**
     * Unit code associated with this session
     * e.g. FIT3077
     */
    private UnitCodeEnum unitCode;

    /**
     * Academic year of the session
     * e.g. 2025
     */
    private String year;

    /**
     * Semester in which the session takes place
     * e.g. S1, S2
     */
    private SemesterEnum semester;

    /**
     * Week of the semester for this session
     * e.g. W1, W2
     */
    private WeekEnum week;

    /**
     * Type of class for this session
     * e.g. LECTURE, TUTORIAL
     */
    private ClassTypeEnum classType;

    /**
     * Generates a unique string ID for this session by concatenating
     * all session components separated by hyphens
     * e.g. 12345678-FIT3077-2025S1-W1-LEC
     *
     * @return a unique session identifier string
     */
    public String getUniqueId() {
        return studentId + "-" + unitCode.name() + "-" + year + semester.name() + "-" + week.getWeekCodeString() + "-" + classType.getCode();
    }

    /**
     * Parses a unique session ID string back into a SessionId object
     * e.g. 12345678-FIT3077-2025S1-W1-LEC
     *
     * @param sessionUniqueId the unique session ID string to parse
     * @return the parsed SessionId object
     */
    public static SessionId getByUniqueId(String sessionUniqueId) {
        // e.g. 12345678-FIT3077-2025S1-W1-LEC
        String[] parts = sessionUniqueId.split("-");
        return SessionId.builder()
                .studentId(parts[0])
                .unitCode(UnitCodeEnum.valueOf(parts[1]))
                .year(parts[2].substring(0, 4))                          // e.g. 2025
                .semester(SemesterEnum.valueOf(parts[2].substring(4)))   // e.g. S1
                .week(WeekEnum.getByString(parts[3]))                         // e.g. W1
                .classType(ClassTypeEnum.getByCode(parts[4]))            // e.g. LEC
                .build();
    }
}

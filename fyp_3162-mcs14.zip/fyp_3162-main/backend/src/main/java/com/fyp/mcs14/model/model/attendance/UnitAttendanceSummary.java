package com.fyp.mcs14.model.model.attendance;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.SuperBuilder;

import java.util.List;

/**
 * Class to represent attendance summary data of a unit in a semester year
 */
@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
public class UnitAttendanceSummary extends AbstractAttendanceData {

    /**
     * Unique id to store in db
     * e.g. FIT3077-2025-S2
     */
    private UnitYearSemesterId unitYearSemesterId;

    /**
     * Unit Code
     * e.g. FIT3077
     */
    private String unitCode;

    /**
     * Unit name
     * e.g. Software Architecture
     */
    private String unitName;

    /**
     * Total number of students of the Unit in current semester year
     */
    private int totalStudents;

    /**
     * Overall attendance rate throughout the semester
     */
    private int overallAttendanceRate;

    /**
     * Overall/average engagement score of the students of this unit in current semester
     */
    private double overallEngagementScore;

    /**
     * Weekly unit attendance summary of the unit in the current semester year
     */
    private List<UnitWeeklyAttendanceSummary> unitWeeklyAttendanceSummaryList;
}

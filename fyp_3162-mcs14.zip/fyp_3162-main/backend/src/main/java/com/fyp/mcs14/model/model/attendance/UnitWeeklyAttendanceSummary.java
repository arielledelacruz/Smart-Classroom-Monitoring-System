package com.fyp.mcs14.model.model.attendance;

import com.fyp.mcs14.model.enums.WeekEnum;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.SuperBuilder;

/**
 * Class to represent attendance summary data of a unit in a specific week
 */
@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
public class UnitWeeklyAttendanceSummary extends AbstractAttendanceData {

    /**
     * Unique id to store in db
     * e.g. FIT3077-2025-S2-W1
     */
    private UnitYearSemesterWeekId id;

    /**
     * Week of the semester
     * e.g. W1, W2
     */
    private WeekEnum week;
}

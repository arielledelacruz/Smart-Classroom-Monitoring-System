package com.fyp.mcs14.model.model.attendance;

import com.fyp.mcs14.model.enums.SemesterEnum;
import com.fyp.mcs14.model.enums.UnitCodeEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Class to represent a unique identifier for a unit in a semester year
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class UnitYearSemesterId {

    /**
     * Unit code of the unit
     * e.g. FIT3077
     */
    private UnitCodeEnum unitCode;

    /**
     * Academic year of the semester
     * e.g. 2025
     */
    private int year;

    /**
     * Semester of the academic year
     * e.g. S1, S2
     */
    private SemesterEnum semester;

    public String generateUniqueId() {
        return unitCode.name() + "-" + year + "-" + semester.name();
    }

    /**
     * Converts a unique string ID back to a UnitYearSemesterId object
     * e.g. "FIT3077-2025-S1" → UnitYearSemesterId
     *
     * @param uniqueId the unique string ID to convert
     * @return the converted UnitYearSemesterId object
     */
    public static UnitYearSemesterId fromUniqueId(String uniqueId) {
        String[] parts = uniqueId.split("-");
        return UnitYearSemesterId.builder()
                .unitCode(UnitCodeEnum.valueOf(parts[0]))
                .year(Integer.parseInt(parts[1]))
                .semester(SemesterEnum.valueOf(parts[2]))
                .build();
    }
}

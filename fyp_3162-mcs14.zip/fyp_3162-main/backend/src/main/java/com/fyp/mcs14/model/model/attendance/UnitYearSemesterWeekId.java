package com.fyp.mcs14.model.model.attendance;

import com.fyp.mcs14.model.enums.SemesterEnum;
import com.fyp.mcs14.model.enums.UnitCodeEnum;
import com.fyp.mcs14.model.enums.WeekEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Class to represent a unique identifier for a unit in a specific week of a semester year
 */
@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@SuperBuilder
public class UnitYearSemesterWeekId extends UnitYearSemesterId {

    /**
     * Week of the semester
     * e.g. W1, W2
     */
    private WeekEnum week;

    /**
     * Generates a unique string ID from the unit, year, semester and week
     * e.g. FIT3077-2025-S1-W1
     *
     * @return a unique identifier string in the format: unitCode-year-semester-week
     */
    public String generateUniqueId() {
        return getUnitCode().name() + "-"
                + getYear() + "-"
                + getSemester().name() + "-"
                + week.getWeekCodeString();
    }
}

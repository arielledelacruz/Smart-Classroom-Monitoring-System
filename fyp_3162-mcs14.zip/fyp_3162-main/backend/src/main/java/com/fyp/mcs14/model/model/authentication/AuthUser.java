package com.fyp.mcs14.model.model.authentication;

import com.fyp.mcs14.model.enums.FacultyEnum;
import com.fyp.mcs14.model.enums.UserRoleEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class to represent an authenticated user
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AuthUser {

    /**
     * Unique identifier of the user
     */
    private String id;

    /**
     * Email address of the user
     * e.g. "john@example.com"
     */
    private String email;

    /**
     * Role of the user in the system
     * e.g. STUDENT, LECTURER
     */
    private UserRoleEnum userRole;

    /**
     * Full name of the user
     * e.g. "Dr. John Smith"
     */
    private String name;

    /**
     * URL of the user's profile photo stored in Firebase Cloud Storage
     * e.g. "https://storage.googleapis.com/bucket/profile-photos/lecturers/L001.jpg"
     * Null if no photo has been uploaded
     */
    private String profilePhotoUrl;

    /**
     * Faculty the user belongs to
     */
    private FacultyEnum faculty;

    /**
     * Phone number for user
     */
    private String phone;
}
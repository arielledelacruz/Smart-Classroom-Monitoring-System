package com.fyp.mcs14.model.model.authentication;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class LecturerAuthUser extends AuthUser {
    private String office;

    private List<String> researchArea;
}

package com.fyp.mcs14.model.model.authentication;

import lombok.Data;

/**
 * Class to represent a login request from a user
 */
@Data
public class LoginRequest {

    /**
     * Email address of the user
     * e.g. john.doe@example.com
     */
    private String email;

    /**
     * Password of the user account
     * e.g. P@ssw0rd
     */
    private String password;
}
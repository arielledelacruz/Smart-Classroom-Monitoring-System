package com.fyp.mcs14.model.model.authentication;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class StudentAuthUser extends AuthUser {
    private int enrolledYear;
}

package com.fyp.mcs14.model.model.dashboard;

import com.fyp.mcs14.model.enums.SemesterEnum;
import com.fyp.mcs14.model.enums.UnitCodeEnum;
import com.fyp.mcs14.model.enums.WeekEnum;
import lombok.Data;

import java.util.List;

/**
 * Class to represent a filter request for the dashboard
 */
@Data
public class DashboardFilterRequest {

    /**
     * List of unit codes to filter by
     * e.g. [FIT3077, FIT2099]
     */
    private List<UnitCodeEnum> unitCodeList;

    /**
     * Start week of the filter range
     * e.g. W1
     */
    private WeekEnum weekStart;

    /**
     * End week of the filter range
     * e.g. W12
     */
    private WeekEnum weekEnd;

    /**
     * Academic year to filter by
     * e.g. 2025
     */
    private String year;

    /**
     * Semester to filter by
     * e.g. S1, S2
     */
    private SemesterEnum semester;
}

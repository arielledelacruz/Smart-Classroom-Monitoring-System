package com.fyp.mcs14.model.model.dashboard;

import com.fyp.mcs14.model.enums.SemesterEnum;
import com.fyp.mcs14.model.enums.UnitCodeEnum;
import lombok.Data;

@Data
public class DashboardQueryUnitStudentRequest {
    private UnitCodeEnum unitCode;

    private int year;

    private SemesterEnum semester;
}

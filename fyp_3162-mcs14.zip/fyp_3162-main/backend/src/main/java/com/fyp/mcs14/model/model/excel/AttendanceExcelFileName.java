package com.fyp.mcs14.model.model.excel;

import com.fyp.mcs14.model.enums.ClassTypeEnum;
import com.fyp.mcs14.model.enums.SemesterEnum;
import com.fyp.mcs14.model.enums.UnitCodeEnum;
import com.fyp.mcs14.model.enums.WeekEnum;
import lombok.Builder;
import lombok.Data;

/**
 * Class to represent the file name components of an attendance Excel file
 */
@Data
@Builder
public class AttendanceExcelFileName {

    /**
     * Unit code associated with the attendance file
     * e.g. FIT3077
     */
    private UnitCodeEnum unitCode;

    /**
     * Academic year of the attendance file
     * e.g. 2025
     */
    private String year;

    /**
     * Semester of the attendance file
     * e.g. S1, S2
     */
    private SemesterEnum semester;

    /**
     * Week of the attendance file
     * e.g. W1, W2
     */
    private WeekEnum week;

    /**
     * Class type of the attendance file
     * e.g. APPLIED, TUTORIAL
     */
    private ClassTypeEnum classType;
}

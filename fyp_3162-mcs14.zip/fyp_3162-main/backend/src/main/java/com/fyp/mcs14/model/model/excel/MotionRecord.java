package com.fyp.mcs14.model.model.excel;

import com.fyp.mcs14.model.enums.MotionTypeEnum;
import lombok.Builder;
import lombok.Data;

/**
 * Class to represent a motion record of a student in a time frame
 */
@Data
@Builder
public class MotionRecord {

    /**
     * Type of motion detected
     * e.g. HEAD, HAND
     */
    private MotionTypeEnum motionType;

    /**
     * Time of the motion record
     * e.g. 09:00
     */
    private String time;

    /**
     * Number of motions detected at the given time
     * e.g. 5
     */
    private int numberOfMotion;
}

package com.fyp.mcs14.model.model.excel;

import com.fyp.mcs14.model.model.attendance.SessionId;
import lombok.Builder;
import lombok.Data;

import java.time.LocalTime;
import java.util.List;

/**
 * Class to represent a raw attendance record of a student in a class session
 */
@Builder
@Data
public class RawAttendanceRecord {

    /**
     * Unique identifier of the student
     * e.g. 12345678
     */
    private String studentId;

    /**
     * Session identifier containing the class scheduling details
     * e.g. 12345678-FIT3077-2025S1-W1-LEC
     */
    private SessionId sessionId;

    /**
     * List of motion records captured during the session
     */
    private List<MotionRecord> records;

    private int sessionDuration;

    private LocalTime startTime;

    private LocalTime endTime;
}

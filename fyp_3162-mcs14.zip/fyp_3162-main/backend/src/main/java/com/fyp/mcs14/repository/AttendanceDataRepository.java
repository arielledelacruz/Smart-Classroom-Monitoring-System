package com.fyp.mcs14.repository;

public interface AttendanceDataRepository {
    boolean saveAll();
}

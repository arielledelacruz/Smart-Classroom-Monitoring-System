package com.fyp.mcs14.repository;

import com.fyp.mcs14.model.dataobject.RawAttendanceRecordDO;

import java.util.List;
import java.util.concurrent.ExecutionException;

public interface AttendanceStudentRawRecordRepository {
    int save(RawAttendanceRecordDO rawAttendanceRecordDO);

    int saveAll(List<RawAttendanceRecordDO> rawAttendanceRecordDOList) throws ExecutionException, InterruptedException;

    void deleteAll();
}

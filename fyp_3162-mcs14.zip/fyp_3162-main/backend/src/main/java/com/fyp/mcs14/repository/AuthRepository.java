package com.fyp.mcs14.repository;

import com.fyp.mcs14.model.model.authentication.AuthUser;
import com.fyp.mcs14.model.model.authentication.LoginRequest;

public interface AuthRepository {
    boolean findByEmail(String email);

    AuthUser findByEmailAndPassword(LoginRequest loginRequest);
}

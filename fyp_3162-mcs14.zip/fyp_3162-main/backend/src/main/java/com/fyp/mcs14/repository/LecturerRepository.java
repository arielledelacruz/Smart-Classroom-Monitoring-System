package com.fyp.mcs14.repository;

import com.fyp.mcs14.model.dataobject.LecturerDO;

import java.util.List;

public interface LecturerRepository {
    void updateProfilePhotoUrl(String lecturerId, String photoUrl);

    LecturerDO getLecturerByEmail(String email);

    void saveAll(List<LecturerDO> lecturerDOList);

    LecturerDO getById(String id);

    List<LecturerDO> getByIdList(List<String> idList);
}

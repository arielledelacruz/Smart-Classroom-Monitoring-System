package com.fyp.mcs14.repository;

/**
 * Repository to store data about attendance summary per session
 */
public interface SessionAttendanceSummaryRepository {
}

package com.fyp.mcs14.repository;

import com.fyp.mcs14.model.dataobject.StudentAnalyticsResultDO;

import java.util.List;
import java.util.Map;

public interface StudentAnalyticsResultRepository {
    void saveAll(List<StudentAnalyticsResultDO> resultDOs);
    void updateClusters(Map<String, String> clusters, String unitSemesterId);
    List<StudentAnalyticsResultDO> getByUnitSemesterId(String unitSemesterId);
    List<StudentAnalyticsResultDO> getByStudentId(String studentId);
    StudentAnalyticsResultDO getByStudentAndUnit(String studentId, String unitSemesterId);
    void deleteByUnitSemesterId(String unitSemesterId);
}
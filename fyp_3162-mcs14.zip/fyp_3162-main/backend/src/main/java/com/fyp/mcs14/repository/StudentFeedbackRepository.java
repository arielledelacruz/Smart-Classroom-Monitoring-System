package com.fyp.mcs14.repository;

import java.util.List;

import com.fyp.mcs14.model.dataobject.StudentFeedbackDO;

public interface StudentFeedbackRepository {
    
    void saveFeedback(StudentFeedbackDO feedbackDO);
    
    StudentFeedbackDO getFeedbackById(String feedbackId);
    
    List<StudentFeedbackDO> getFeedbackByStudentIdAndUnitCode(String studentId, String unitCode);
    
    List<StudentFeedbackDO> getFeedbackByStudentId(String studentId);
    
    List<StudentFeedbackDO> getFeedbackByUnitCode(String unitCode);
    
    List<StudentFeedbackDO> getFeedbackByLecturerIdAndUnitCode(String lecturerId, String unitCode);
    
    void deleteFeedback(String feedbackId);
}

package com.fyp.mcs14.repository;

import com.fyp.mcs14.model.dataobject.StudentDO;

import java.util.List;

public interface StudentRepository {

    StudentDO getStudentByEmail(String email);

    void saveAll(List<StudentDO> studentDOList);

    List<StudentDO> getByIdList(List<String> idList);

    StudentDO getById(String id);

}

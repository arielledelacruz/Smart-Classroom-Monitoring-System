package com.fyp.mcs14.repository;

import com.fyp.mcs14.model.dataobject.StudentSessionSummaryDO;

import java.util.List;

public interface StudentSessionSummaryRepository {
    void saveAll(List<StudentSessionSummaryDO> sessionSummaryDOList);

    List<StudentSessionSummaryDO> getByStudentUnitSemester(String studentId, String unitSemesterId);

    /**
     *
     * @param unitSemesterId e.g. FIT3077-2025S1
     * @return
     */
    List<StudentSessionSummaryDO> getByUnitSemesterId(String unitSemesterId);

    /**
     *
     * @param sessionId e.g. FIT3077-2025S1-W1
     * @return
     */
    List<StudentSessionSummaryDO> getBySessionId(String sessionId);
}

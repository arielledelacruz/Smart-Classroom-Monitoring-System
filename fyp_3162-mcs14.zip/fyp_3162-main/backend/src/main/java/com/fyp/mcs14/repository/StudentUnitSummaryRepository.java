package com.fyp.mcs14.repository;

import com.fyp.mcs14.model.dataobject.StudentUnitSummaryDO;

import java.util.List;

public interface StudentUnitSummaryRepository {
    void save(StudentUnitSummaryDO studentUnitSummaryDO);

    StudentUnitSummaryDO getById(String id);

    List<StudentUnitSummaryDO> getByUnitSemesterId(String unitSemesterId);

    List<StudentUnitSummaryDO> getByStudentId(String studentId);

    StudentUnitSummaryDO getByStudentAndUnitSemesterId(String studentId, String unitSemesterId);
}

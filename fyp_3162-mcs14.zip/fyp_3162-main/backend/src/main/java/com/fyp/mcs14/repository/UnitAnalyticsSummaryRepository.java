package com.fyp.mcs14.repository;

import com.fyp.mcs14.model.dataobject.UnitAnalyticsSummaryDO;

public interface UnitAnalyticsSummaryRepository {
    void save(UnitAnalyticsSummaryDO summaryDO);

    UnitAnalyticsSummaryDO getByUnitSemesterId(String unitSemesterId);
}

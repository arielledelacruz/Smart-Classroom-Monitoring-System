package com.fyp.mcs14.repository;

import com.fyp.mcs14.model.dataobject.UnitDO;

import java.util.List;

public interface UnitRepository {
    UnitDO getUnitByUnitCode(String unitCode);

    void saveUnit(UnitDO unitDO);

    void saveAll(List<UnitDO> unitDOList);

    List<UnitDO> getAllUnits();
}

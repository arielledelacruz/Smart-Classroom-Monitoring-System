package com.fyp.mcs14.repository;

import com.fyp.mcs14.model.dataobject.UnitSemesterAssignmentDO;

import java.util.List;

public interface UnitSemesterAssignmentRepository {
    void save(UnitSemesterAssignmentDO assignmentDO, String documentId);

    List<UnitSemesterAssignmentDO> getByUnitSemesterId(String unitSemesterId);

    void saveAll(List<UnitSemesterAssignmentDO> assignmentDOs);
}

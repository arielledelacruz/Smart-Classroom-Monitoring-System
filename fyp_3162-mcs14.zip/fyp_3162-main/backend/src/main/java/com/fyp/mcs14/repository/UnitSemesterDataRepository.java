package com.fyp.mcs14.repository;

import com.fyp.mcs14.model.dataobject.UnitSemesterDataDO;

import java.util.List;

public interface UnitSemesterDataRepository {
    void saveAll(List<UnitSemesterDataDO> dataDOList);

    UnitSemesterDataDO getById(String id);

    void save(UnitSemesterDataDO dataDO);
}

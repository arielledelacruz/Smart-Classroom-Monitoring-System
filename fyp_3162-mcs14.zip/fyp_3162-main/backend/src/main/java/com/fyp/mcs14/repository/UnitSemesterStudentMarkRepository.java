package com.fyp.mcs14.repository;

import com.fyp.mcs14.model.dataobject.UnitSemesterStudentMarkDO;

import java.util.List;

public interface UnitSemesterStudentMarkRepository {
    void saveAll(List<UnitSemesterStudentMarkDO> markDOs);

    void save(UnitSemesterStudentMarkDO markDO, String documentId);

    List<UnitSemesterStudentMarkDO> getByUnitSemesterAssignmentId(String unitSemesterAssignmentId);

    List<UnitSemesterStudentMarkDO> getByUnitSemesterStudentId(String unitSemesterId, String studentId);
}
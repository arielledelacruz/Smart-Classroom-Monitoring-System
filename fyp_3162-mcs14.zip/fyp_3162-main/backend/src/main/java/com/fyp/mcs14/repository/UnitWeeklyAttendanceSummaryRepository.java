package com.fyp.mcs14.repository;

import com.fyp.mcs14.model.dataobject.UnitWeeklyAttendanceSummaryDO;

import java.util.List;

/**
 * Repository to store data about attendance summary per unit week
 */
public interface UnitWeeklyAttendanceSummaryRepository {
    void saveUnitWeeklyAttendanceSummary(UnitWeeklyAttendanceSummaryDO unitWeeklyAttendanceSummaryDO);

    UnitWeeklyAttendanceSummaryDO getUnitWeeklyAttendanceSummaryById(String id);

    List<UnitWeeklyAttendanceSummaryDO> getUnitWeeklyAttendanceSummaryByIdList(List<String> id);

    List<UnitWeeklyAttendanceSummaryDO> getWeeklySummariesByUnitYearSemesterWeekRange(
            String unitCode, String year, String semester, List<String> weekIds
    );

    void deleteAll();
}
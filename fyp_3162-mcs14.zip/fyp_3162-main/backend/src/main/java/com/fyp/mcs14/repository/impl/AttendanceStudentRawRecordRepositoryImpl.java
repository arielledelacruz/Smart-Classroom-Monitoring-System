package com.fyp.mcs14.repository.impl;

import com.fyp.mcs14.model.dataobject.RawAttendanceRecordDO;
import com.fyp.mcs14.repository.AttendanceStudentRawRecordRepository;
import com.google.cloud.firestore.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.concurrent.ExecutionException;

@Repository
public class AttendanceStudentRawRecordRepositoryImpl implements AttendanceStudentRawRecordRepository {

    @Autowired
    private Firestore firestore;

    private final String ATTENDANCE_RAW_RECORD_COLLECTION = "attendance_student_raw_records";

    @Override
    public int save(RawAttendanceRecordDO record) {
        firestore.collection(ATTENDANCE_RAW_RECORD_COLLECTION)
                .document()
                .set(record);
        return 1;
    }

    @Override
    public int saveAll(List<RawAttendanceRecordDO> rawAttendanceRecordDOList) throws ExecutionException, InterruptedException {
        WriteBatch batch = firestore.batch();
        CollectionReference collection = firestore.collection(ATTENDANCE_RAW_RECORD_COLLECTION);

        for (RawAttendanceRecordDO record : rawAttendanceRecordDOList) {
            DocumentReference docRef = collection.document(record.getSessionId());
            batch.set(docRef, record);
        }

        batch.commit().get();

        return rawAttendanceRecordDOList.size();
    }

    @Override
    public void deleteAll() {
        try {
            List<QueryDocumentSnapshot> documents = firestore.collection(ATTENDANCE_RAW_RECORD_COLLECTION)
                    .get()
                    .get()
                    .getDocuments();

            WriteBatch batch = firestore.batch();
            for (QueryDocumentSnapshot doc : documents) {
                batch.delete(doc.getReference());
            }
            batch.commit().get();
        } catch (Exception e) {
            throw new RuntimeException("Failed to delete all unit weekly attendance summaries", e);
        }
    }
}

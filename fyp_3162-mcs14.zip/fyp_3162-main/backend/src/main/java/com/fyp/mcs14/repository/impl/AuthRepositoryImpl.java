package com.fyp.mcs14.repository.impl;

import com.fyp.mcs14.model.enums.UserRoleEnum;
import com.fyp.mcs14.model.model.authentication.AuthUser;
import com.fyp.mcs14.model.model.authentication.LecturerAuthUser;
import com.fyp.mcs14.model.model.authentication.LoginRequest;
import com.fyp.mcs14.model.model.authentication.StudentAuthUser;
import com.fyp.mcs14.repository.AuthRepository;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.concurrent.ExecutionException;

@Service
public class AuthRepositoryImpl implements AuthRepository {
    @Autowired
    private Firestore firestore;

    private final String AUTH_USER_COLLECTION = "auth_user";

    @Override
    public boolean findByEmail(String email) {
        try {
            DocumentSnapshot doc = firestore.collection(AUTH_USER_COLLECTION)
                    .document(email)
                    .get()
                    .get();

            if (!doc.exists()) {
                return false;
            }
            return true;

        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public AuthUser findByEmailAndPassword(LoginRequest user) {
        try {
            DocumentSnapshot doc = firestore.collection(AUTH_USER_COLLECTION)
                    .document(user.getEmail())
                    .get()
                    .get();
            if (!doc.exists()) {
                return null;
            }

            String storedPassword = doc.getString("password");
            if (storedPassword == null) return null;

            if (storedPassword.equals(user.getPassword())) {
                // In authRepository
                String storedRole = doc.contains("user_role")
                    ? doc.getString("user_role")
                    : doc.getString("role");
                if (storedRole == null) return null;

                UserRoleEnum role;
                try {
                    role = UserRoleEnum.valueOf(storedRole.toUpperCase());
                } catch (IllegalArgumentException e) {
                    return null;
                }

                if (role == UserRoleEnum.LECTURER) {
                    LecturerAuthUser authUser = new LecturerAuthUser();
                    authUser.setId(user.getEmail());
                    authUser.setEmail(user.getEmail());
                    authUser.setUserRole(role);
                    authUser.setName(doc.getString("name"));
                    return authUser;
                } else if (role == UserRoleEnum.STUDENT) {
                    StudentAuthUser authUser = new StudentAuthUser();
                    authUser.setId(user.getEmail());
                    authUser.setEmail(user.getEmail());
                    authUser.setUserRole(role);
                    authUser.setName(doc.getString("name"));
                    return authUser;
                }

                return null;
            }
            else {
                return null;
            }

        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
            return null;
        }
    }
}

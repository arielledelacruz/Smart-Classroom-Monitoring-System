package com.fyp.mcs14.repository.impl;

import com.fyp.mcs14.model.dataobject.LecturerDO;
import com.fyp.mcs14.repository.LecturerRepository;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class LecturerRepositoryImpl implements LecturerRepository {

    @Autowired
    private Firestore firestore;

    private static final String COLLECTION = "lecturer_collection";

    @Override
    public void updateProfilePhotoUrl(String lecturerId, String photoUrl) {
        try {
            firestore.collection(COLLECTION)
                    .document(lecturerId)
                    .update("profilePhotoUrl", photoUrl)
                    .get();
        } catch (Exception e) {
            throw new RuntimeException("Failed to update profile photo URL for lecturer: " + lecturerId, e);
        }
    }

    @Override
    public LecturerDO getLecturerByEmail(String email) {
        try {
            List<QueryDocumentSnapshot> documents = firestore.collection(COLLECTION)
                    .whereEqualTo("email", email)
                    .get().get().getDocuments();

            if (documents.isEmpty()) return null;

            QueryDocumentSnapshot doc = documents.get(0);
            LecturerDO lecturerDO = doc.toObject(LecturerDO.class);
            lecturerDO.setId(doc.getId());
            return lecturerDO;
        } catch (Exception e) {
            throw new RuntimeException("Failed to get lecturer by email: " + email, e);
        }
    }

    @Override
    public void saveAll(List<LecturerDO> lecturerDOList) {
        try {
            WriteBatch batch = firestore.batch();

            for (LecturerDO lecturerDO : lecturerDOList) {
                DocumentReference docRef = firestore
                        .collection(COLLECTION)
                        .document(lecturerDO.getId());

                Map<String, Object> data = new HashMap<>();
                data.put("id", lecturerDO.getId());
                data.put("name", lecturerDO.getName());
                data.put("email", lecturerDO.getEmail());
                data.put("phone", lecturerDO.getPhone());
                data.put("faculty", lecturerDO.getFaculty());
                data.put("profilePhotoUrl", lecturerDO.getProfilePhotoUrl());
                data.put("office", lecturerDO.getOffice());
                data.put("researchArea", lecturerDO.getResearchArea());

                batch.set(docRef, data);
            }

            batch.commit().get();
        } catch (Exception e) {
            throw new RuntimeException("Failed to batch save lecturers", e);
        }
    }

    @Override
    public List<LecturerDO> getByIdList(List<String> idList) {
        try {
            List<ApiFuture<DocumentSnapshot>> futures = idList.stream()
                    .map(id -> firestore.collection(COLLECTION).document(id).get())
                    .toList();

            List<LecturerDO> lecturers = new ArrayList<>();
            for (ApiFuture<DocumentSnapshot> future : futures) {
                DocumentSnapshot document = future.get();
                if (document.exists()) {
                    LecturerDO lecturerDO = document.toObject(LecturerDO.class);
                    lecturerDO.setId(document.getId());
                    lecturers.add(lecturerDO);
                }
            }
            return lecturers;
        } catch (Exception e) {
            throw new RuntimeException("Failed to get lecturers by id list", e);
        }
    }

    @Override
    public LecturerDO getById(String id) {
        try {
            DocumentSnapshot document = firestore
                    .collection(COLLECTION)
                    .document(id)
                    .get()
                    .get();

            if (document.exists()) {
                LecturerDO lecturerDO = document.toObject(LecturerDO.class);
                lecturerDO.setId(document.getId());
                return lecturerDO;
            }
            return null;
        } catch (Exception e) {
            throw new RuntimeException("Failed to get lecturer by id: " + id, e);
        }
    }
}

package com.fyp.mcs14.repository.impl;

import com.fyp.mcs14.repository.SessionAttendanceSummaryRepository;
import org.springframework.stereotype.Repository;

@Repository
public class SessionAttendanceSummaryRepositoryImpl implements SessionAttendanceSummaryRepository {
    private final String COLLECTION = "session_attendance_summary";
}

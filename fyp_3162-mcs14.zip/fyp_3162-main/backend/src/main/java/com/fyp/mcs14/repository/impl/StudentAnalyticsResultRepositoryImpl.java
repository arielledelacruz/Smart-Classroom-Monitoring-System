package com.fyp.mcs14.repository.impl;

import com.fyp.mcs14.model.dataobject.StudentAnalyticsResultDO;
import com.fyp.mcs14.repository.StudentAnalyticsResultRepository;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.QuerySnapshot;
import com.google.cloud.firestore.WriteBatch;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Repository
public class StudentAnalyticsResultRepositoryImpl implements StudentAnalyticsResultRepository {

    @Autowired
    private Firestore firestore;

    private final String COLLECTION = "student_analytics_result";

    @Override
    public void saveAll(List<StudentAnalyticsResultDO> resultDOs) {
        try {
            WriteBatch batch = firestore.batch();

            for (StudentAnalyticsResultDO resultDO : resultDOs) {
                DocumentReference docRef = firestore
                        .collection(COLLECTION)
                        .document(resultDO.generateDocumentId());

                Map<String, Object> data = new HashMap<>();
                data.put("studentId", resultDO.getStudentId());
                data.put("unitSemesterId", resultDO.getUnitSemesterId());
                data.put("attendanceRate", resultDO.getAttendanceRate());
                data.put("engagementScore", resultDO.getEngagementScore());
                data.put("effectivePresence", resultDO.getEffectivePresence());
                data.put("trendSlope", resultDO.getTrendSlope());
                data.put("consecutiveAbsences", resultDO.getConsecutiveAbsences());
                data.put("riskScore", resultDO.getRiskScore());
                data.put("insights", resultDO.getInsights());
                data.put("clusterLabel", resultDO.getClusterLabel());
                data.put("riskBreakdown", resultDO.getRiskBreakdown());
                data.put("explanations", resultDO.getExplanations());

                batch.set(docRef, data);
            }

            batch.commit().get();
        } catch (Exception e) {
            throw new RuntimeException("Failed to batch save analytics results", e);
        }
    }

    @Override
    public void updateClusters(Map<String, String> clusters, String unitSemesterId) {
        try {
            WriteBatch batch = firestore.batch();

            for (Map.Entry<String, String> entry : clusters.entrySet()) {
                String documentId = entry.getKey() + "-" + unitSemesterId;
                DocumentReference docRef = firestore
                        .collection(COLLECTION)
                        .document(documentId);
                batch.update(docRef, "clusterLabel", entry.getValue());
            }

            batch.commit().get();
        } catch (Exception e) {
            throw new RuntimeException("Failed to update cluster labels for unit: " + unitSemesterId, e);
        }
    }

    @Override
    public List<StudentAnalyticsResultDO> getByUnitSemesterId(String unitSemesterId) {
        try {
            QuerySnapshot querySnapshot = firestore
                    .collection(COLLECTION)
                    .whereEqualTo("unitSemesterId", unitSemesterId)
                    .get()
                    .get();

            return querySnapshot.getDocuments().stream()
                    .map(doc -> doc.toObject(StudentAnalyticsResultDO.class))
                    .collect(Collectors.toList());
        } catch (Exception e) {
            throw new RuntimeException("Failed to get analytics results by unit: " + unitSemesterId, e);
        }
    }

    @Override
    public StudentAnalyticsResultDO getByStudentAndUnit(String studentId, String unitSemesterId) {
        try {
            DocumentSnapshot document = firestore
                    .collection(COLLECTION)
                    .document(studentId + "-" + unitSemesterId)
                    .get()
                    .get();

            if (document.exists()) {
                return document.toObject(StudentAnalyticsResultDO.class);
            }
            return null;
        } catch (Exception e) {
            throw new RuntimeException("Failed to get analytics result - student: "
                    + studentId + " unit: " + unitSemesterId, e);
        }
    }

    @Override
    public List<StudentAnalyticsResultDO> getByStudentId(String studentId) {
        try {
            QuerySnapshot querySnapshot = firestore
                    .collection(COLLECTION)
                    .whereEqualTo("studentId", studentId)
                    .get()
                    .get();

            return querySnapshot.getDocuments().stream()
                    .map(doc -> doc.toObject(StudentAnalyticsResultDO.class))
                    .collect(Collectors.toList());
        } catch (Exception e) {
            throw new RuntimeException("Failed to get analytics results by student: " + studentId, e);
        }
    }

    @Override
    public void deleteByUnitSemesterId(String unitSemesterId) {
        try {
            QuerySnapshot querySnapshot = firestore
                    .collection(COLLECTION)
                    .whereEqualTo("unitSemesterId", unitSemesterId)
                    .get()
                    .get();

            WriteBatch batch = firestore.batch();
            querySnapshot.getDocuments()
                    .forEach(doc -> batch.delete(doc.getReference()));

            batch.commit().get();
        } catch (Exception e) {
            throw new RuntimeException("Failed to delete analytics results for unit: " + unitSemesterId, e);
        }
    }
}

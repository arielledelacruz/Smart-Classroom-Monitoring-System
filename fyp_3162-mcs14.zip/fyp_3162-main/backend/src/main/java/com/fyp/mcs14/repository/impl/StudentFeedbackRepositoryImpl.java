package com.fyp.mcs14.repository.impl;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fyp.mcs14.model.dataobject.StudentFeedbackDO;
import com.fyp.mcs14.repository.StudentFeedbackRepository;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.QuerySnapshot;

@Repository
public class StudentFeedbackRepositoryImpl implements StudentFeedbackRepository {

    @Autowired
    private Firestore firestore;

    private final String COLLECTION = "student_feedback";

    @Override
    public void saveFeedback(StudentFeedbackDO feedbackDO) {
        try {
            if (feedbackDO.getFeedbackId() == null || feedbackDO.getFeedbackId().isEmpty()) {
                feedbackDO.setFeedbackId(UUID.randomUUID().toString());
            }

            feedbackDO.setUpdatedAt(LocalDateTime.now());
            if (feedbackDO.getCreatedAt() == null) {
                feedbackDO.setCreatedAt(LocalDateTime.now());
            }

            Map<String, Object> feedbackMap = new HashMap<>();
            feedbackMap.put("studentId", feedbackDO.getStudentId());
            feedbackMap.put("lecturerId", feedbackDO.getLecturerId());
            feedbackMap.put("unitCode", feedbackDO.getUnitCode());
            feedbackMap.put("feedbackContent", feedbackDO.getFeedbackContent());
            feedbackMap.put("feedbackType", feedbackDO.getFeedbackType());
            feedbackMap.put("createdAt", toDate(feedbackDO.getCreatedAt()));
            feedbackMap.put("updatedAt", toDate(feedbackDO.getUpdatedAt()));

            firestore.collection(COLLECTION)
                    .document(feedbackDO.getFeedbackId())
                    .set(feedbackMap)
                    .get();
        } catch (Exception e) {
            throw new RuntimeException("Failed to save feedback: " + e.getMessage(), e);
        }
    }

    @Override
    public StudentFeedbackDO getFeedbackById(String feedbackId) {
        try {
            DocumentSnapshot document = firestore
                    .collection(COLLECTION)
                    .document(feedbackId)
                    .get()
                    .get();

            if (document.exists()) {
                return mapDocumentToFeedbackDO(document);
            }
            return null;
        } catch (Exception e) {
            throw new RuntimeException("Failed to get feedback by ID: " + feedbackId, e);
        }
    }

    @Override
    public List<StudentFeedbackDO> getFeedbackByStudentIdAndUnitCode(String studentId, String unitCode) {
        try {
            QuerySnapshot querySnapshot = firestore
                    .collection(COLLECTION)
                    .whereEqualTo("studentId", studentId)
                    .whereEqualTo("unitCode", unitCode)
                    .get()
                    .get();

            return querySnapshot.getDocuments()
                    .stream()
                    .map(this::mapDocumentToFeedbackDO)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            throw new RuntimeException("Failed to get feedback by student ID and unit code", e);
        }
    }

    @Override
    public List<StudentFeedbackDO> getFeedbackByStudentId(String studentId) {
        try {
            QuerySnapshot querySnapshot = firestore
                    .collection(COLLECTION)
                    .whereEqualTo("studentId", studentId)
                    .get()
                    .get();

            return querySnapshot.getDocuments()
                    .stream()
                    .map(this::mapDocumentToFeedbackDO)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            throw new RuntimeException("Failed to get feedback by student ID", e);
        }
    }

    @Override
    public List<StudentFeedbackDO> getFeedbackByUnitCode(String unitCode) {
        try {
            QuerySnapshot querySnapshot = firestore
                    .collection(COLLECTION)
                    .whereEqualTo("unitCode", unitCode)
                    .get()
                    .get();

            return querySnapshot.getDocuments()
                    .stream()
                    .map(this::mapDocumentToFeedbackDO)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            throw new RuntimeException("Failed to get feedback by unit code", e);
        }
    }

    @Override
    public List<StudentFeedbackDO> getFeedbackByLecturerIdAndUnitCode(String lecturerId, String unitCode) {
        try {
            QuerySnapshot querySnapshot = firestore
                    .collection(COLLECTION)
                    .whereEqualTo("lecturerId", lecturerId)
                    .whereEqualTo("unitCode", unitCode)
                    .get()
                    .get();

            return querySnapshot.getDocuments()
                    .stream()
                    .map(this::mapDocumentToFeedbackDO)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            throw new RuntimeException("Failed to get feedback by lecturer ID and unit code", e);
        }
    }

    @Override
    public void deleteFeedback(String feedbackId) {
        try {
            firestore.collection(COLLECTION)
                    .document(feedbackId)
                    .delete()
                    .get();
        } catch (Exception e) {
            throw new RuntimeException("Failed to delete feedback", e);
        }
    }

    private StudentFeedbackDO mapDocumentToFeedbackDO(DocumentSnapshot doc) {
        StudentFeedbackDO feedbackDO = new StudentFeedbackDO();
        feedbackDO.setFeedbackId(doc.getId());
        feedbackDO.setStudentId(doc.getString("studentId"));
        feedbackDO.setLecturerId(doc.getString("lecturerId"));
        feedbackDO.setUnitCode(doc.getString("unitCode"));
        feedbackDO.setFeedbackContent(doc.getString("feedbackContent"));
        feedbackDO.setFeedbackType(doc.getString("feedbackType"));
        feedbackDO.setCreatedAt(toLocalDateTime(doc.getDate("createdAt")));
        feedbackDO.setUpdatedAt(toLocalDateTime(doc.getDate("updatedAt")));
        return feedbackDO;
    }

    private Date toDate(LocalDateTime localDateTime) {
        if (localDateTime == null) {
            return null;
        }
        return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
    }

    private LocalDateTime toLocalDateTime(Date date) {
        if (date == null) {
            return null;
        }
        return LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault());
    }
}

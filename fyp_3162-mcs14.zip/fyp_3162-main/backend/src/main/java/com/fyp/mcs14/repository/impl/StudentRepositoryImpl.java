package com.fyp.mcs14.repository.impl;

import com.fyp.mcs14.model.dataobject.StudentDO;
import com.fyp.mcs14.repository.StudentRepository;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class StudentRepositoryImpl implements StudentRepository {

    @Autowired
    private Firestore firestore;

    private final String COLLECTION = "student_collection";

    @Override
    public StudentDO getStudentByEmail(String email) {
        try {
            List<QueryDocumentSnapshot> documents = firestore.collection(COLLECTION)
                    .whereEqualTo("email", email)
                    .get().get().getDocuments();

            if (documents.isEmpty()) return null;

            QueryDocumentSnapshot doc = documents.get(0);
            StudentDO studentDO = doc.toObject(StudentDO.class);
            studentDO.setStudentId(doc.getId());
            return studentDO;
        } catch (Exception e) {
            throw new RuntimeException("Failed to get student by email: " + email, e);
        }
    }

    @Override
    public void saveAll(List<StudentDO> studentDOList) {
        try {
            WriteBatch batch = firestore.batch();

            for (StudentDO studentDO : studentDOList) {
                DocumentReference docRef = firestore
                        .collection(COLLECTION)
                        .document(studentDO.getStudentId());

                Map<String, Object> data = new HashMap<>();
                data.put("email", studentDO.getEmail());
                data.put("userRole", studentDO.getUserRole());
                data.put("name", studentDO.getName());
                data.put("profilePhotoUrl", studentDO.getProfilePhotoUrl());
                data.put("faculty", studentDO.getFaculty());
                data.put("phone", studentDO.getPhone());
                data.put("enrolledYear", studentDO.getEnrolledYear());

                batch.set(docRef, data);
            }

            batch.commit().get();
        } catch (Exception e) {
            throw new RuntimeException("Failed to batch save students", e);
        }
    }

    @Override
    public List<StudentDO> getByIdList(List<String> idList) {
        try {
            // fetch all in parallel
            List<ApiFuture<DocumentSnapshot>> futures = idList.stream()
                    .map(id -> firestore.collection(COLLECTION).document(id).get())
                    .toList();

            List<StudentDO> students = new ArrayList<>();
            for (ApiFuture<DocumentSnapshot> future : futures) {
                DocumentSnapshot document = future.get();
                if (document.exists()) {
                    StudentDO studentDO = document.toObject(StudentDO.class);
                    studentDO.setStudentId(document.getId());
                    students.add(studentDO);
                }
            }
            return students;
        } catch (Exception e) {
            throw new RuntimeException("Failed to get students by id list", e);
        }
    }
    @Override
    public StudentDO getById(String id) {
        try {
            DocumentSnapshot document = firestore
                    .collection(COLLECTION)
                    .document(id)
                    .get()
                    .get();

            if (document.exists()) {
                StudentDO studentDO = document.toObject(StudentDO.class);
                studentDO.setStudentId(document.getId());
                return studentDO;
            }
            return null;
        } catch (Exception e) {
            throw new RuntimeException("Failed to get student by id: " + id, e);
        }
    }
}

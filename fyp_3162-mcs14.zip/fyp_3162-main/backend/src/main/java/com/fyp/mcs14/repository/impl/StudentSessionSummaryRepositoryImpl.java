package com.fyp.mcs14.repository.impl;

import com.fyp.mcs14.model.dataobject.StudentSessionSummaryDO;
import com.fyp.mcs14.repository.StudentSessionSummaryRepository;
import com.google.cloud.firestore.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Repository
public class StudentSessionSummaryRepositoryImpl implements StudentSessionSummaryRepository {

    @Autowired
    private Firestore firestore;

    private final String COLLECTION = "student_session_summary";

    @Override
    public void saveAll(List<StudentSessionSummaryDO> summaryDOs) {
        try {
            WriteBatch batch = firestore.batch();

            for (StudentSessionSummaryDO summaryDO : summaryDOs) {
                DocumentReference docRef = firestore
                        .collection(COLLECTION)
                        .document(summaryDO.generateDocumentId()); // concatenate here
                System.out.println(summaryDO.generateDocumentId());
                Map<String, Object> data = new HashMap<>();
                data.put("studentId", summaryDO.getStudentId());
                data.put("sessionId", summaryDO.getSessionId());
                data.put("unitSemesterId", extractUnitSemesterId(summaryDO.getSessionId()));
                data.put("present", summaryDO.isPresent());
                data.put("lateArrival", summaryDO.isLateArrival());
                data.put("earlyDeparture", summaryDO.isEarlyDeparture());
                data.put("engagementScore", summaryDO.getEngagementScore());
                data.put("presenceQuality", summaryDO.getPresenceQuality());

                batch.set(docRef, data);
            }

            batch.commit().get();
        } catch (Exception e) {
            throw new RuntimeException("Failed to batch save student session summaries", e);
        }
    }

    @Override
    public List<StudentSessionSummaryDO> getByStudentUnitSemester(String studentId, String unitSemesterId) {
        try {
            // query all documents starting with e.g. "12345678-FIT3077-2025-S1"
            QuerySnapshot querySnapshot = firestore
                    .collection(COLLECTION)
                    .whereGreaterThanOrEqualTo(FieldPath.documentId(), studentId + "-" + unitSemesterId)
                    .whereLessThan(FieldPath.documentId(), studentId + "-" + unitSemesterId + "~")
                    .get()
                    .get();

            return querySnapshot.getDocuments().stream()
                    .map(doc -> {
                        return doc.toObject(StudentSessionSummaryDO.class);
                    })
                    .collect(Collectors.toList());
        } catch (Exception e) {
            throw new RuntimeException("Failed to get student session summaries: " + studentId, e);
        }
    }

    @Override
    public List<StudentSessionSummaryDO> getByUnitSemesterId(String unitSemesterId) {
        try {
            QuerySnapshot querySnapshot = firestore
                    .collection(COLLECTION)
                    .whereEqualTo("unitSemesterId", unitSemesterId)
                    .get()
                    .get();

            return querySnapshot.getDocuments().stream()
                    .map(doc -> {
                        StudentSessionSummaryDO summaryDO = doc.toObject(StudentSessionSummaryDO.class);
                        summaryDO.setStudentId(doc.get("studentId", String.class));
                        summaryDO.setSessionId(doc.get("sessionId", String.class));
                        return summaryDO;
                    })
                    .collect(Collectors.toList());
        } catch (Exception e) {
            throw new RuntimeException("Failed to get session summaries by unit: " + unitSemesterId, e);
        }
    }

    /**
     * Retrieves all student session summaries for a specific unit semester week
     * e.g. all students session summaries for FIT3077-2025-S1-W1
     *
     * @param unitSemesterWeekId the unit semester week id e.g. FIT3077-2025-S1-W1
     * @return list of StudentSessionSummaryDO for the given week
     */
    @Override
    public List<StudentSessionSummaryDO> getBySessionId(String unitSemesterWeekId) {
        try {
            // sessionId format stored in doc: FIT3077-2025S1-W1-LEC
            // unitSemesterWeekId format: FIT3077-2025-S1-W1
            // need to extract unitCode, year, semester, week to match sessionId prefix

            String[] parts = unitSemesterWeekId.split("-");
            String unitCode = parts[0];             // FIT3077
            String year     = parts[1];             // 2025
            String semester = parts[2];             // S1
            String week     = parts[3];             // W1

            // sessionId stored as: FIT3077-2025S1-W1-LEC
            // so prefix to match: FIT3077-2025S1-W1
            String sessionIdPrefix = unitCode + "-" + year + semester + "-" + week;

            QuerySnapshot querySnapshot = firestore
                    .collection(COLLECTION)
                    .whereGreaterThanOrEqualTo("sessionId", sessionIdPrefix)
                    .whereLessThan("sessionId", sessionIdPrefix + "~")
                    .get()
                    .get();

            return querySnapshot.getDocuments().stream()
                    .map(doc -> {
                        StudentSessionSummaryDO summaryDO = doc.toObject(StudentSessionSummaryDO.class);
                        summaryDO.setStudentId(doc.get("studentId", String.class));
                        summaryDO.setSessionId(doc.get("sessionId", String.class));
                        return summaryDO;
                    })
                    .collect(Collectors.toList());

        } catch (Exception e) {
            throw new RuntimeException("Failed to get session summaries by week: " + unitSemesterWeekId, e);
        }
    }

    /**
     * Extracts unit semester id from session id
     * e.g. FIT3077-2025S1-W1-LEC -> FIT3077-2025-S1
     */
    private String extractUnitSemesterId(String sessionId) {
        // sessionId format: FIT3077-2025S1-W1-LEC
        // extract unit code, year, semester only
        String[] parts = sessionId.split("-");
        String unitCode = parts[0];                          // FIT3077
        String year     = parts[1].substring(0, 4);          // 2025
        String semester = parts[1].substring(4);             // S1
        return unitCode + "-" + year + "-" + semester;       // FIT3077-2025-S1
    }
}
package com.fyp.mcs14.repository.impl;

import com.fyp.mcs14.model.dataobject.StudentUnitSummaryDO;
import com.fyp.mcs14.repository.StudentUnitSummaryRepository;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.QuerySnapshot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Repository
public class StudentUnitSummaryRepositoryImpl implements StudentUnitSummaryRepository {

    @Autowired
    private Firestore firestore;

    private final String COLLECTION = "student_unit_summary";

    @Override
    public void save(StudentUnitSummaryDO summaryDO) {
        try {
            Map<String, Object> data = new HashMap<>();
            data.put("studentId", summaryDO.getStudentId());
            data.put("unitSemesterId", summaryDO.getUnitSemesterId());
            data.put("totalSessions", summaryDO.getTotalSessions());
            data.put("totalPresent", summaryDO.getTotalPresent());
            data.put("totalLateArrival", summaryDO.getTotalLateArrival());
            data.put("totalEarlyDeparture", summaryDO.getTotalEarlyDeparture());
            data.put("attendanceRate", summaryDO.getAttendanceRate());
            data.put("avgEngagementScore", summaryDO.getAvgEngagementScore());
            data.put("avgPresenceQuality", summaryDO.getAvgPresenceQuality());

            firestore
                    .collection(COLLECTION)
                    .document(summaryDO.generateDocumentId())
                    .set(data)
                    .get();
        } catch (Exception e) {
            throw new RuntimeException("Failed to save student unit summary: " + summaryDO.generateDocumentId(), e);
        }
    }

    @Override
    public StudentUnitSummaryDO getById(String id) {
        try {
            DocumentSnapshot document = firestore
                    .collection(COLLECTION)
                    .document(id)
                    .get()
                    .get();

            if (document.exists()) {
                StudentUnitSummaryDO summaryDO = document.toObject(StudentUnitSummaryDO.class);
                return summaryDO;
            }
            return null;
        } catch (Exception e) {
            throw new RuntimeException("Failed to get student unit summary: " + id, e);
        }
    }

    @Override
    public List<StudentUnitSummaryDO> getByUnitSemesterId(String unitSemesterId) {
        try {
            // query all documents where unitSemesterId field matches
            QuerySnapshot querySnapshot = firestore
                    .collection(COLLECTION)
                    .whereEqualTo("unitSemesterId", unitSemesterId)
                    .get()
                    .get();

            return querySnapshot.getDocuments().stream()
                    .map(doc -> doc.toObject(StudentUnitSummaryDO.class))
                    .collect(Collectors.toList());
        } catch (Exception e) {
            throw new RuntimeException("Failed to get student unit summaries by unit: " + unitSemesterId, e);
        }
    }

    @Override
    public List<StudentUnitSummaryDO> getByStudentId(String studentId) {
        try {
            // query all documents where studentId field matches
            QuerySnapshot querySnapshot = firestore
                    .collection(COLLECTION)
                    .whereEqualTo("studentId", studentId)
                    .get()
                    .get();

            return querySnapshot.getDocuments().stream()
                    .map(doc -> doc.toObject(StudentUnitSummaryDO.class))
                    .collect(Collectors.toList());
        } catch (Exception e) {
            throw new RuntimeException("Failed to get student unit summaries by student: " + studentId, e);
        }
    }

    @Override
    public StudentUnitSummaryDO getByStudentAndUnitSemesterId(String studentId, String unitSemesterId) {
        try {
            QuerySnapshot querySnapshot = firestore
                    .collection(COLLECTION)
                    .whereEqualTo("studentId", studentId)
                    .whereEqualTo("unitSemesterId", unitSemesterId)
                    .get()
                    .get();

            if (!querySnapshot.isEmpty()) {
                // Assuming only one result
                DocumentSnapshot doc = querySnapshot.getDocuments().get(0);
                return doc.toObject(StudentUnitSummaryDO.class);
            }

            return null;

        } catch (Exception e) {
            throw new RuntimeException(
                    "Failed to get student unit summary for studentId=" + studentId +
                            ", unitSemesterId=" + unitSemesterId, e);
        }
    }
}
package com.fyp.mcs14.repository.impl;

import com.fyp.mcs14.model.dataobject.UnitAnalyticsSummaryDO;
import com.fyp.mcs14.repository.UnitAnalyticsSummaryRepository;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;

@Repository
public class UnitAnalyticsSummaryRepositoryImpl implements UnitAnalyticsSummaryRepository {

    @Autowired
    private Firestore firestore;

    private final String COLLECTION = "unit_analytics_summary";

    @Override
    public void save(UnitAnalyticsSummaryDO summaryDO) {
        try {
            Map<String, Object> data = new HashMap<>();
            data.put("avgAttendanceRate", summaryDO.getAvgAttendanceRate());
            data.put("avgEngagementScore", summaryDO.getAvgEngagementScore());
            data.put("avgPresenceQuality", summaryDO.getAvgPresenceQuality());
            data.put("avgRiskScore", summaryDO.getAvgRiskScore());
            data.put("clusterDistribution", summaryDO.getClusterDistribution());
            data.put("highRiskCount", summaryDO.getHighRiskCount());
            data.put("totalStudents", summaryDO.getTotalStudents());

            firestore
                    .collection(COLLECTION)
                    .document(summaryDO.getUnitSemesterId())
                    .set(data)
                    .get();
        } catch (Exception e) {
            throw new RuntimeException("Failed to save unit analytics summary: " + summaryDO.getUnitSemesterId(), e);
        }
    }

    @Override
    public UnitAnalyticsSummaryDO getByUnitSemesterId(String unitSemesterId) {
        try {
            DocumentSnapshot document = firestore
                    .collection(COLLECTION)
                    .document(unitSemesterId)
                    .get()
                    .get();

            if (document.exists()) {
                UnitAnalyticsSummaryDO summaryDO = document.toObject(UnitAnalyticsSummaryDO.class);
                summaryDO.setUnitSemesterId(document.getId());
                return summaryDO;
            }
            return null;
        } catch (Exception e) {
            throw new RuntimeException("Failed to get unit analytics summary: " + unitSemesterId, e);
        }
    }
}

package com.fyp.mcs14.repository.impl;

import com.fyp.mcs14.repository.UnitAttendanceSummaryRepository;
import org.springframework.stereotype.Repository;

@Repository
public class UnitAttendanceSummaryRepositoryImpl implements UnitAttendanceSummaryRepository {
    private final String COLLECTION = "unit_attendance_summary";
}

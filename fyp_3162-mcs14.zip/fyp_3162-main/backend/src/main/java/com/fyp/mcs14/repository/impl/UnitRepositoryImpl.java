package com.fyp.mcs14.repository.impl;

import com.fyp.mcs14.model.dataobject.UnitDO;
import com.fyp.mcs14.repository.UnitRepository;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.QuerySnapshot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Repository
public class UnitRepositoryImpl implements UnitRepository {

    @Autowired
    private Firestore firestore;

    private final String COLLECTION = "unit";

    @Override
    public UnitDO getUnitByUnitCode(String unitCode) {
        try {
            DocumentSnapshot document = firestore
                    .collection(COLLECTION)
                    .document(unitCode)
                    .get()
                    .get();

            if (document.exists()) {
                UnitDO unitDO = document.toObject(UnitDO.class);
                unitDO.setUnitCode(document.getId());
                return unitDO;
            }
            return null;
        } catch (Exception e) {
            throw new RuntimeException("Failed to get unit by unit code: " + unitCode, e);
        }
    }

    @Override
    public void saveUnit(UnitDO unitDO) {
        try {
            Map<String, Object> unitMap = new HashMap<>();
            unitMap.put("unitName", unitDO.getUnitName());
            unitMap.put("faculty", unitDO.getFaculty());
            unitMap.put("creditPoints", unitDO.getCreditPoints());

            firestore
                    .collection(COLLECTION)
                    .document(unitDO.getUnitCode())
                    .set(unitMap)
                    .get();
        } catch (Exception e) {
            throw new RuntimeException("Failed to save unit: " + unitDO.getUnitCode(), e);
        }
    }

    @Override
    public void saveAll(List<UnitDO> unitDOList) {

    }

    @Override
    public List<UnitDO> getAllUnits() {
        try {
            QuerySnapshot querySnapshot = firestore
                    .collection(COLLECTION)
                    .get()
                    .get();

            return querySnapshot.getDocuments()
                    .stream()
                    .map(document -> {
                        UnitDO unitDO = document.toObject(UnitDO.class);
                        unitDO.setUnitCode(document.getId());
                        return unitDO;
                    })
                    .collect(Collectors.toList());
        } catch (Exception e) {
            throw new RuntimeException("Failed to get all units", e);
        }
    }
}

package com.fyp.mcs14.repository.impl;

import com.fyp.mcs14.model.dataobject.UnitSemesterAssignmentDO;
import com.fyp.mcs14.repository.UnitSemesterAssignmentRepository;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.WriteBatch;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class UnitSemesterAssignmentRepositoryImpl implements UnitSemesterAssignmentRepository {
    @Autowired
    private Firestore firestore;

    private final String COLLECTION = "unit_semester_assignment";

    @Override
    public void save(UnitSemesterAssignmentDO assignmentDO, String documentId) {

    }

    // UnitSemesterAssignmentRepository
    @Override
    public void saveAll(List<UnitSemesterAssignmentDO> assignmentDOs) {
        try {
            WriteBatch batch = firestore.batch();

            for (UnitSemesterAssignmentDO assignmentDO : assignmentDOs) {
                DocumentReference docRef = firestore.collection(COLLECTION).document(assignmentDO.getId());

                Map<String, Object> data = new HashMap<>();
                data.put("assignmentId", assignmentDO.getAssignmentId());
                data.put("assignmentName", assignmentDO.getAssignmentName());

                batch.set(docRef, data);
            }

            batch.commit().get();
        } catch (Exception e) {
            throw new RuntimeException("Failed to batch save assignments", e);
        }
    }

    @Override
    public List<UnitSemesterAssignmentDO> getByUnitSemesterId(String unitSemesterId) {
        return List.of();
    }
}

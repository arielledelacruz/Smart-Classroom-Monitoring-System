package com.fyp.mcs14.repository.impl;

import com.fyp.mcs14.model.dataobject.UnitSemesterDataDO;
import com.fyp.mcs14.repository.UnitSemesterDataRepository;
import com.google.cloud.firestore.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class UnitSemesterDataRepositoryImpl implements UnitSemesterDataRepository {
    @Autowired
    private Firestore firestore;

    private final String COLLECTION = "unit_semester_data";

    @Override
    public void saveAll(List<UnitSemesterDataDO> dataDOList) {
        try {
            for (UnitSemesterDataDO unitSemesterDataDO : dataDOList) {
                Map<String, Object> data = new HashMap<>();
                data.put("totalStudents", unitSemesterDataDO.getTotalStudents());
                data.put("studentIdList", unitSemesterDataDO.getStudentIdList());

                firestore
                        .collection(COLLECTION)
                        .document(unitSemesterDataDO.getId())
                        .set(data)
                        .get();
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to save unit semester data", e);
        }
    }

    @Override
    public UnitSemesterDataDO getById(String unitSemesterId) {
        try {
            DocumentSnapshot document = firestore
                    .collection(COLLECTION)
                    .document(unitSemesterId)
                    .get()
                    .get();

            if (document.exists()) {
                UnitSemesterDataDO dataDO = document.toObject(UnitSemesterDataDO.class);
                assert dataDO != null;
                dataDO.setId(unitSemesterId);
                return dataDO;
            }
            return null;
        } catch (Exception e) {
            throw new RuntimeException("Failed to get unit semester: " + unitSemesterId, e);
        }
    }

    @Override
    public void save(UnitSemesterDataDO dataDO) {
        try {
            Map<String, Object> data = new HashMap<>();
            data.put("totalStudents", dataDO.getTotalStudents());
            data.put("studentIdList", dataDO.getStudentIdList());

            firestore
                    .collection(COLLECTION)
                    .document(dataDO.getId())
                    .set(data)
                    .get();
        } catch (Exception e) {
            throw new RuntimeException("Failed to save unit semester data", e);
        }

    }
}

package com.fyp.mcs14.repository.impl;

import com.fyp.mcs14.model.dataobject.UnitSemesterStudentMarkDO;
import com.fyp.mcs14.repository.UnitSemesterStudentMarkRepository;
import com.google.cloud.firestore.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Repository
public class UnitSemesterStudentMarkRepositoryImpl implements UnitSemesterStudentMarkRepository {
    @Autowired
    private Firestore firestore;

    private final String COLLECTION = "unit_semester_student_mark";

    // UnitSemesterStudentMarkRepository
    @Override
    public void saveAll(List<UnitSemesterStudentMarkDO> markDOs) {
        try {
            WriteBatch batch = firestore.batch();

            for (UnitSemesterStudentMarkDO markDO : markDOs) {
                DocumentReference docRef = firestore.collection(COLLECTION).document(markDO.getId());

                Map<String, Object> data = new HashMap<>();
                data.put("marks", markDO.getMarks());

                batch.set(docRef, data);
            }

            batch.commit().get();
        } catch (Exception e) {
            throw new RuntimeException("Failed to batch save student marks", e);
        }
    }

    @Override
    public void save(UnitSemesterStudentMarkDO markDO, String documentId) {
        try {
            Map<String, Object> data = new HashMap<>();
            data.put("marks", markDO.getMarks());

            firestore.collection(COLLECTION).document(documentId).set(data).get();
        } catch (Exception e) {
            throw new RuntimeException("Failed to save student mark: " + documentId, e);
        }
    }

    @Override
    public List<UnitSemesterStudentMarkDO> getByUnitSemesterAssignmentId(String unitSemesterAssignmentId) {
        try {
            // query all documents starting with e.g. "FIT3077-2025-S1-A1-"
            QuerySnapshot querySnapshot = firestore
                    .collection(COLLECTION)
                    .whereGreaterThanOrEqualTo(FieldPath.documentId(), unitSemesterAssignmentId + "-")
                    .whereLessThan(FieldPath.documentId(), unitSemesterAssignmentId + ".")
                    .get()
                    .get();

            return querySnapshot.getDocuments().stream()
                    .map(doc -> {
                        UnitSemesterStudentMarkDO markDO = doc.toObject(UnitSemesterStudentMarkDO.class);
                        return markDO;
                    })
                    .collect(Collectors.toList());
        } catch (Exception e) {
            throw new RuntimeException("Failed to get marks by assignment: " + unitSemesterAssignmentId, e);
        }
    }

    @Override
    public List<UnitSemesterStudentMarkDO> getByUnitSemesterStudentId(String unitSemesterId, String studentId) {
        try {
            // query all documents starting with e.g. "FIT3077-2025-S1-" and ending with "-12345678"
            QuerySnapshot querySnapshot = firestore
                    .collection(COLLECTION)
                    .whereGreaterThanOrEqualTo(FieldPath.documentId(), unitSemesterId + "-")
                    .whereLessThan(FieldPath.documentId(), unitSemesterId + ".")
                    .get()
                    .get();

            return querySnapshot.getDocuments().stream()
                    .filter(doc -> doc.getId().endsWith("-" + studentId))
                    .map(doc -> doc.toObject(UnitSemesterStudentMarkDO.class))
                    .collect(Collectors.toList());
        } catch (Exception e) {
            throw new RuntimeException("Failed to get marks by student: " + studentId, e);
        }
    }
}

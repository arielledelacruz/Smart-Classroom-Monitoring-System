package com.fyp.mcs14.repository.impl;

import com.fyp.mcs14.model.dataobject.UnitWeeklyAttendanceSummaryDO;
import com.fyp.mcs14.repository.UnitWeeklyAttendanceSummaryRepository;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.WriteBatch;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class UnitWeeklyAttendanceSummaryRepositoryImpl implements UnitWeeklyAttendanceSummaryRepository {

    @Autowired
    private Firestore firestore;

    private final String COLLECTION = "unit_weekly_attendance_summary";

    @Override
    public void saveUnitWeeklyAttendanceSummary(UnitWeeklyAttendanceSummaryDO summaryDO) {
        try {
            Map<String, Object> summaryMap = new HashMap<>();
            summaryMap.put("totalAttendance", summaryDO.getTotalAttendance());
            summaryMap.put("totalAbsence", summaryDO.getTotalAbsence());
            summaryMap.put("totalEarlyDeparture", summaryDO.getTotalEarlyDeparture());
            summaryMap.put("totalLateArrival", summaryDO.getTotalLateArrival());

            firestore
                    .collection(COLLECTION)
                    .document(summaryDO.getId())
                    .set(summaryMap)
                    .get();
        } catch (Exception e) {
            throw new RuntimeException("Failed to save unit weekly attendance summary: " + summaryDO.getId(), e);
        }
    }

    @Override
    public UnitWeeklyAttendanceSummaryDO getUnitWeeklyAttendanceSummaryById(String id) {
        try {
            DocumentSnapshot document = firestore
                    .collection(COLLECTION)
                    .document(id)
                    .get()
                    .get();

            if (document.exists()) {
                UnitWeeklyAttendanceSummaryDO summaryDO = document.toObject(UnitWeeklyAttendanceSummaryDO.class);
                summaryDO.setId(document.getId());
                return summaryDO;
            }
            return null;
        } catch (Exception e) {
            throw new RuntimeException("Failed to get unit weekly attendance summary: " + id + e.toString(), e);
        }
    }

    @Override
    public List<UnitWeeklyAttendanceSummaryDO> getUnitWeeklyAttendanceSummaryByIdList(List<String> idList) {
        List<UnitWeeklyAttendanceSummaryDO> unitWeeklyAttendanceSummaryDOS = new ArrayList<>();

        for (String id : idList) {
            unitWeeklyAttendanceSummaryDOS.add(this.getUnitWeeklyAttendanceSummaryById(id));
        }

        return unitWeeklyAttendanceSummaryDOS;
    }

    @Override
    public List<UnitWeeklyAttendanceSummaryDO> getWeeklySummariesByUnitYearSemesterWeekRange(
            String unitCode, String year, String semester, List<String> weekIds) {
        try {
            // weekIds = ["FIT3077-2025-S1-W1", "FIT3077-2025-S1-W2", ...]
            List<UnitWeeklyAttendanceSummaryDO> results = new ArrayList<>();

            for (String weekId : weekIds) {
                DocumentSnapshot document = firestore
                        .collection(COLLECTION)
                        .document(weekId)
                        .get()
                        .get();

                if (document.exists()) {
                    UnitWeeklyAttendanceSummaryDO summaryDO = document.toObject(UnitWeeklyAttendanceSummaryDO.class);
                    summaryDO.setId(document.getId());
                    results.add(summaryDO);
                }
            }
            return results;
        } catch (Exception e) {
            throw new RuntimeException("Failed to get weekly summaries", e);
        }
    }

    @Override
    public void deleteAll() {
        try {
            List<QueryDocumentSnapshot> documents = firestore.collection(COLLECTION)
                    .get()
                    .get()
                    .getDocuments();

            WriteBatch batch = firestore.batch();
            for (QueryDocumentSnapshot doc : documents) {
                batch.delete(doc.getReference());
            }
            batch.commit().get();
        } catch (Exception e) {
            throw new RuntimeException("Failed to delete all unit weekly attendance summaries", e);
        }
    }
}

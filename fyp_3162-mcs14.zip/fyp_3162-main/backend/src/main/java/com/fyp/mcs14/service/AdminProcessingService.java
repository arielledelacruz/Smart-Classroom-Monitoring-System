package com.fyp.mcs14.service;

import org.springframework.web.multipart.MultipartFile;

public interface AdminProcessingService {
    void processUnitSemesterExcel(MultipartFile file);

    void processLecturerExcel(MultipartFile file);

    void processUnitExcel(MultipartFile file);

    void processStudentExcel(MultipartFile file);

    void processUnitSemesterMarkExcel(MultipartFile file);
}

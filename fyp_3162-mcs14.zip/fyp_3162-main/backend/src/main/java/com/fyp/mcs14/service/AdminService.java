package com.fyp.mcs14.service;

import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.concurrent.ExecutionException;

public interface AdminService {
    void uploadAttendanceRawRecordExcel(MultipartFile file) throws IOException, ExecutionException, InterruptedException;

    void uploadUnitSemesterDataExcel(MultipartFile file);

    void uploadStudentsExcel(MultipartFile file);

    void uploadUnitSemesterStudentMarkExcel(MultipartFile file);

    void uploadLecturersExcel(MultipartFile file);
}

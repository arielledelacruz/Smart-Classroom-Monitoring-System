package com.fyp.mcs14.service;

import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.concurrent.ExecutionException;

public interface AttendanceProcessingService {
    void processExcel(MultipartFile file) throws IOException, ExecutionException, InterruptedException;
}

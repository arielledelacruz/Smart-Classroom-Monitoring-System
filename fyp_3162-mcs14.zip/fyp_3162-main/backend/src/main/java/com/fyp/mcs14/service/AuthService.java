package com.fyp.mcs14.service;

import com.fyp.mcs14.model.dto.authentication.LoginRequestDTO;
import com.fyp.mcs14.common.ResponseResult;
import com.fyp.mcs14.model.dto.authentication.AuthUserDTO;

public interface AuthService {
    ResponseResult<AuthUserDTO> validateLogin(LoginRequestDTO loginRequestDTO);
}

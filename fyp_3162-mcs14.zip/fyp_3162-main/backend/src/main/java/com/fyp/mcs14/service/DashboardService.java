package com.fyp.mcs14.service;

import com.fyp.mcs14.model.enums.UnitCodeEnum;
import com.fyp.mcs14.model.model.dashboard.DashboardQueryUnitStudentRequest;
import com.fyp.mcs14.model.dto.dashboard.DashboardUnitAttendanceSummaryResponseDTO;
import com.fyp.mcs14.model.dto.dashboard.DashboardUnitSemesterStudentsResponseDTO;
import com.fyp.mcs14.model.model.dashboard.DashboardFilterRequest;
import com.fyp.mcs14.model.model.attendance.UnitAttendanceSummary;

public interface DashboardService {
    DashboardUnitAttendanceSummaryResponseDTO getFilteredData(DashboardFilterRequest dashboardFilterRequest);

    DashboardUnitSemesterStudentsResponseDTO getUnitSemesterStudents(DashboardQueryUnitStudentRequest dashboardFilterRequest);

    UnitAttendanceSummary getUnitAttendanceSummary(UnitCodeEnum unitCode, DashboardFilterRequest request);
}

package com.fyp.mcs14.service;

import com.fyp.mcs14.model.model.Lecturer;
import com.fyp.mcs14.model.model.ParsedMarkData;
import com.fyp.mcs14.model.model.Student;
import com.fyp.mcs14.model.model.UnitSemesterData;
import com.fyp.mcs14.model.model.excel.RawAttendanceRecord;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface ExcelParserService {
    List<RawAttendanceRecord> parseAttendanceExcel(MultipartFile file) throws IOException;

    UnitSemesterData parseUnitSemesterDataExcel(MultipartFile file);

    ParsedMarkData parseUnitSemesterMarkExcel(MultipartFile file);

    List<Student> parseStudentsExcel(MultipartFile file);

    List<Lecturer> parseLecturersExcel(MultipartFile file);
}

package com.fyp.mcs14.service;

import org.springframework.web.multipart.MultipartFile;

public interface LecturerService {
    void uploadProfilePhoto(String lecturerId, MultipartFile file);
}

package com.fyp.mcs14.service;

import com.fyp.mcs14.model.dto.StudentFeedbackDTO;
import com.fyp.mcs14.model.model.StudentFeedback;

import java.util.List;

public interface StudentFeedbackService {
    
    void saveFeedback(StudentFeedback feedback);
    
    StudentFeedbackDTO getFeedbackById(String feedbackId);
    
    List<StudentFeedbackDTO> getFeedbackByStudentAndUnit(String studentId, String unitCode);
    
    List<StudentFeedbackDTO> getFeedbackByStudent(String studentId);
    
    List<StudentFeedbackDTO> getFeedbackByUnit(String unitCode);
    
    List<StudentFeedbackDTO> getFeedbackByLecturerAndUnit(String lecturerId, String unitCode);
    
    void deleteFeedback(String feedbackId);
}

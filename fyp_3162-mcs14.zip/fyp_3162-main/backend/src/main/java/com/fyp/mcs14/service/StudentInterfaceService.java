package com.fyp.mcs14.service;

import com.fyp.mcs14.model.dto.StudentInterface.*;

public interface StudentInterfaceService {
    StudentEnrolledUnitsDTO getEnrolledUnits(String studentId, String year, String semester);

    StudentOverallAttendanceSummaryDTO getAttendanceSummary(String studentId, String year, String semester);

    StudentUnitAttendanceDetailDTO getUnitAttendanceDetail(String studentId, String unitSemesterId);

    StudentAnalyticsResultDTO getStudentAnalytics(String studentId, String unitSemesterId);

    StudentSessionHistoryDTO getSessionHistory(String studentId, String unitSemesterId);
}

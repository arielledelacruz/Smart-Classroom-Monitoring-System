package com.fyp.mcs14.service;

import com.fyp.mcs14.model.dto.UnitOverviewResponseDTO;
import com.fyp.mcs14.model.enums.WeekEnum;

public interface UnitOverviewService {
    UnitOverviewResponseDTO getUnitOverview(String unitSemesterId, WeekEnum weekStart, WeekEnum weekEnd);
}

package com.fyp.mcs14.service;

import com.fyp.mcs14.model.model.UnitSemesterData;

import java.util.List;

/**
 * Service interface to handle unit related operations
 */
public interface UnitService {

    /**
     * Retrieves all unit codes available in the system
     *
     * @return a list of unit code strings
     * e.g. [FIT3077, FIT2099]
     */
    List<String> getAllUnitCodes();

    UnitSemesterData getUnitSemesterData(String id);
}

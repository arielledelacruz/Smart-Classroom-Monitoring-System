package com.fyp.mcs14.service;

import com.fyp.mcs14.model.model.attendance.UnitWeeklyAttendanceSummary;
import com.fyp.mcs14.model.model.excel.RawAttendanceRecord;

import java.util.List;

public interface UnitWeeklyAttendanceSummaryService {
    UnitWeeklyAttendanceSummary calculateWeeklySummary(List<RawAttendanceRecord> records);
}

package com.fyp.mcs14.service.impl;

import com.fyp.mcs14.model.converter.*;
import com.fyp.mcs14.model.dataobject.LecturerDO;
import com.fyp.mcs14.model.dataobject.StudentDO;
import com.fyp.mcs14.model.model.Lecturer;
import com.fyp.mcs14.model.model.ParsedMarkData;
import com.fyp.mcs14.model.model.Student;
import com.fyp.mcs14.model.model.UnitSemesterData;
import com.fyp.mcs14.repository.*;
import com.fyp.mcs14.service.AdminProcessingService;
import com.fyp.mcs14.service.ExcelParserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class AdminProcessingServiceImpl implements AdminProcessingService {

    private final String SERVICE = "admin_processing_service: ";

    @Autowired
    private ExcelParserService excelParserService;

    @Autowired
    private UnitSemesterDataRepository unitSemesterDataRepository;

    @Autowired
    private UnitSemesterAssignmentRepository unitSemesterAssignmentRepository;

    @Autowired
    private UnitSemesterStudentMarkRepository unitSemesterStudentMarkRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private LecturerRepository lecturerRepository;

    @Override
    public void processUnitSemesterExcel(MultipartFile file) {
        log.info("{} Received unit semester data excel", SERVICE);
        UnitSemesterData data = excelParserService.parseUnitSemesterDataExcel(file);

        unitSemesterDataRepository.save(UnitSemesterDataConverter.convertModel2DO(data));
    }

    @Override
    public void processLecturerExcel(MultipartFile file) {
        log.info("{} Received lecturer data excel", SERVICE);

        List<Lecturer> lecturers = excelParserService.parseLecturersExcel(file);

        List<LecturerDO> lecturerDOS = LecturerConverter.convertModelList2DOList(lecturers);

        lecturerRepository.saveAll(lecturerDOS);
    }

    @Override
    public void processUnitExcel(MultipartFile file) {
        log.info("{} Received unit data excel", SERVICE);
    }

    @Override
    public void processStudentExcel(MultipartFile file) {
        log.info("{} Received students data excel", SERVICE);

        List<Student> students = excelParserService.parseStudentsExcel(file);

        List<StudentDO> studentDOs = StudentConverter.convertModelList2DOList(students);

        studentRepository.saveAll(studentDOs);
    }

    @Override
    public void processUnitSemesterMarkExcel(MultipartFile file) {
        log.info("{} Received unit semester mark data excel", SERVICE);

        ParsedMarkData parsedMarkData = excelParserService.parseUnitSemesterMarkExcel(file);

        unitSemesterAssignmentRepository.saveAll(
                parsedMarkData.getAssignments().stream()
                        .map(UnitSemesterAssignmentConverter::toDO)
                        .collect(Collectors.toList())
        );

        unitSemesterStudentMarkRepository.saveAll(
                parsedMarkData.getStudentMarks().stream()
                        .map(UnitSemesterStudentMarkConverter::toDO)
                        .collect(Collectors.toList())
        );
    }
}

package com.fyp.mcs14.service.impl;

import com.fyp.mcs14.service.AdminProcessingService;
import com.fyp.mcs14.service.AdminService;
import com.fyp.mcs14.service.AttendanceProcessingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.concurrent.ExecutionException;

@Service
public class AdminServiceImpl implements AdminService {
    @Autowired
    private AttendanceProcessingService attendanceProcessingService;

    @Autowired
    private AdminProcessingService adminProcessingService;

    @Override
    public void uploadAttendanceRawRecordExcel(MultipartFile file) throws IOException, ExecutionException, InterruptedException {
        attendanceProcessingService.processExcel(file);
    }

    @Override
    public void uploadUnitSemesterDataExcel(MultipartFile file) {
        adminProcessingService.processUnitSemesterExcel(file);
    }

    @Override
    public void uploadStudentsExcel(MultipartFile file) {
        adminProcessingService.processStudentExcel(file);
    }

    @Override
    public void uploadUnitSemesterStudentMarkExcel(MultipartFile file) {
        adminProcessingService.processUnitSemesterMarkExcel(file);
    }

    @Override
    public void uploadLecturersExcel(MultipartFile file) {
        adminProcessingService.processLecturerExcel(file);
    }
}

package com.fyp.mcs14.service.impl;

import com.fyp.mcs14.analytics.AnalyticsService;
import com.fyp.mcs14.analytics.UnitAnalyticService;
import com.fyp.mcs14.analytics.insights.ClusteringService;
import com.fyp.mcs14.model.converter.*;
import com.fyp.mcs14.model.dataobject.StudentSessionSummaryDO;
import com.fyp.mcs14.model.enums.ClassTypeEnum;
import com.fyp.mcs14.model.enums.SemesterEnum;
import com.fyp.mcs14.model.enums.UnitCodeEnum;
import com.fyp.mcs14.model.enums.WeekEnum;
import com.fyp.mcs14.model.model.SessionSummaryBuilder;
import com.fyp.mcs14.model.model.StudentAnalyticsResult;
import com.fyp.mcs14.model.model.StudentSessionSummary;
import com.fyp.mcs14.model.model.StudentUnitSummary;
import com.fyp.mcs14.model.model.attendance.SessionId;
import com.fyp.mcs14.model.model.attendance.UnitWeeklyAttendanceSummary;
import com.fyp.mcs14.model.model.attendance.UnitYearSemesterId;
import com.fyp.mcs14.model.model.attendance.UnitYearSemesterWeekId;
import com.fyp.mcs14.model.model.excel.RawAttendanceRecord;
import com.fyp.mcs14.repository.*;
import com.fyp.mcs14.service.AttendanceProcessingService;
import com.fyp.mcs14.service.ExcelParserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class AttendanceProcessingServiceImpl implements AttendanceProcessingService {

    @Autowired
    private ExcelParserService excelParserService;

    @Autowired
    private SessionSummaryBuilder sessionSummaryBuilder;

    @Autowired
    private AnalyticsService analyticsService;

    @Autowired
    private ClusteringService clusteringService;

    @Autowired
    private StudentSessionSummaryRepository studentSessionSummaryRepository;

    @Autowired
    private StudentUnitSummaryRepository studentUnitSummaryRepository;

    @Autowired
    private StudentAnalyticsResultRepository studentAnalyticsResultRepository;

    @Autowired
    private UnitWeeklyAttendanceSummaryRepository unitWeeklyAttendanceSummaryRepository;

    @Autowired
    private UnitAnalyticService unitAnalyticService;

    @Autowired
    private UnitSemesterDataRepository unitSemesterDataRepository;

    /**
     * Processes an attendance Excel file by:
     * 1. Parsing raw records from Excel
     * 2. Saving raw records
     * 3. Building and saving session summaries
     * 4. Rebuilding and saving student unit summaries
     * 5. Recomputing and saving analytics results per student
     * 6. Recomputing and saving clustering results
     * 7. Recomputing and saving unit weekly attendance summary
     *
     * Expected filename: FIT3077-2025-S1-W8-LEC.xlsx
     *
     * @param file the Excel file to process
     */
    @Override
    public void processExcel(MultipartFile file) throws IOException {
        try {
            log.info("processAttendanceExcel started - file: {}", file.getOriginalFilename());
            long start = System.currentTimeMillis();

            // ── Step 1: Parse filename ─────────────────────────────────────────────
            SessionId sessionId = parseSessionIdFromFilename(Objects.requireNonNull(file.getOriginalFilename()));
            UnitYearSemesterId unitYearSemesterId = UnitYearSemesterId.builder()
                    .unitCode(sessionId.getUnitCode())
                    .year(Integer.parseInt(sessionId.getYear()))
                    .semester(sessionId.getSemester())
                    .build();
            String unitSemId = unitYearSemesterId.generateUniqueId();

            // ── Step 2: Parse Excel ────────────────────────────────────────────────
            List<RawAttendanceRecord> rawRecords = excelParserService.parseAttendanceExcel(file);

            rawRecords.forEach(record -> {
                record.setSessionId(SessionId.builder()
                        .studentId(record.getStudentId())
                        .unitCode(sessionId.getUnitCode())
                        .year(sessionId.getYear())
                        .semester(sessionId.getSemester())
                        .week(sessionId.getWeek())
                        .classType(sessionId.getClassType())
                        .build());
            });

            log.info("Parsed {} raw records", rawRecords.size());

            // ── Step 3: Build session summaries from uploaded records ──────────────
            List<StudentSessionSummary> uploadedSummaries = rawRecords.stream()
                    .map(sessionSummaryBuilder::build)
                    .toList();

            // ── NEW: Resolve enrolled students & inject absent records ─────────────
            // Get all students allocated to this unit-semester
            List<String> enrolledStudentIds = unitSemesterDataRepository
                    .getById(unitSemId).getStudentIdList();

            // Find which students are already covered by the upload
            Set<String> attendedStudentIds = uploadedSummaries.stream()
                    .map(StudentSessionSummary::getStudentId)
                    .collect(Collectors.toSet());

            // Build absent records for students not in the upload
            List<StudentSessionSummary> absentSummaries = enrolledStudentIds.stream()
                    .filter(id -> !attendedStudentIds.contains(id))
                    .map(id -> sessionSummaryBuilder.buildAbsent(id, sessionId))
                    .toList();

            log.info("{} attended, {} absent out of {} enrolled",
                    attendedStudentIds.size(), absentSummaries.size(), enrolledStudentIds.size());

            // Merge: all summaries for this session (attended + absent)
            List<StudentSessionSummary> allThisWeekSummaries = new ArrayList<>(uploadedSummaries);
            allThisWeekSummaries.addAll(absentSummaries);

            // ── Step 4: Save session summaries (including absent ones) ────────────
            studentSessionSummaryRepository.saveAll(
                    StudentSessionSummaryConverter.toDOList(allThisWeekSummaries)
            );
            log.info("Saved {} session summaries - took {}ms",
                    allThisWeekSummaries.size(), System.currentTimeMillis() - start);

            // ── Step 5: Rebuild StudentUnitSummary for ALL enrolled students ───────
            List<StudentSessionSummaryDO> allSessionSummaryDOs = studentSessionSummaryRepository
                    .getByUnitSemesterId(unitSemId);

            Map<String, List<StudentSessionSummary>> byStudent = StudentSessionSummaryConverter
                    .toModelList(allSessionSummaryDOs)
                    .stream()
                    .collect(Collectors.groupingBy(StudentSessionSummary::getStudentId));

            // IMPORTANT: also include enrolled students with zero sessions recorded yet
            // (edge case: if DB had no prior records for them)
            enrolledStudentIds.forEach(id ->
                    byStudent.putIfAbsent(id, Collections.emptyList())
            );

            List<StudentUnitSummary> unitSummaries = byStudent.entrySet().stream()
                    .map(entry -> StudentUnitSummaryConverter.fromSessions(
                            entry.getKey(),
                            unitYearSemesterId,
                            entry.getValue()
                    ))
                    .collect(Collectors.toList());

            unitSummaries.forEach(summary ->
                    studentUnitSummaryRepository.save(
                            StudentUnitSummaryConverter.toDO(summary)
                    )
            );
            log.info("Saved unit summaries for {} students - took {}ms",
                    unitSummaries.size(), System.currentTimeMillis() - start);

            // ── Step 6: Recompute analytics per student ────────────────────────────
            List<StudentAnalyticsResult> analyticsResults = unitSummaries.stream()
                    .map(analyticsService::analyzeStudentAnalytics)
                    .toList();

            // save analytics results
            studentAnalyticsResultRepository.saveAll(
                    analyticsResults.stream()
                            .map(r -> StudentAnalyticsResultConverter.toDO(r, unitYearSemesterId.generateUniqueId()))
                            .collect(Collectors.toList())
            );
            log.info("Saved analytics results - took {}ms", System.currentTimeMillis() - start);

            // ── Step 7: Recompute clustering ───────────────────────────────────────
            Map<String, String> clusters = clusteringService.clusterStudents(unitSummaries);

            // update analytics results with cluster labels
            studentAnalyticsResultRepository.updateClusters(
                    clusters,
                    unitYearSemesterId.generateUniqueId()
            );
            log.info("Saved clustering results - took {}ms", System.currentTimeMillis() - start);

            // ── Step 8: Recompute unit weekly attendance summary ───────────────────
            UnitWeeklyAttendanceSummary weeklySummary = buildWeeklySummary(
                    allThisWeekSummaries, sessionId, unitYearSemesterId
            );

            unitWeeklyAttendanceSummaryRepository.saveUnitWeeklyAttendanceSummary(
                    UnitWeeklyAttendanceSummaryConverter.convertModel2DO(weeklySummary)
            );

            // ── Step 10: Recompute unit-level analytics ────────────────────────
            unitAnalyticService.computeAndSave(
                    unitYearSemesterId.generateUniqueId(),
                    analyticsResults,
                    clusters
            );
            log.debug("Saved unit analytics - {}ms", System.currentTimeMillis() - start);

            log.info("processAttendanceExcel completed - took {}ms", System.currentTimeMillis() - start);
        }
        catch (Exception e) {
            log.error(e.getMessage());
            log.error("e: ", e);
        }
    }

    /**
     * Parses the session ID from the Excel filename
     * e.g. FIT3077-2025-S1-W8-LEC.xlsx -> SessionId
     *
     * @param filename the Excel filename
     * @return the parsed SessionId
     */
    private SessionId parseSessionIdFromFilename(String filename) {
        // "FIT3077_2025S1_W7_T.xlsx" → "FIT3077_2025S1_W7_T"
        String name    = filename.replace(".xlsx", "").replace(".xls", "").trim();
        String[] parts = name.split("_");

        if (parts.length < 5) {
            throw new IllegalArgumentException(
                    "Invalid filename format. Expected: UNITCODE_YEAR_SEMSETER_W#_CLASSTYPE.xlsx, got: " + filename
            );
        }

        return SessionId.builder()
                .unitCode(UnitCodeEnum.valueOf(parts[0]))
                .year(parts[1])
                .semester(SemesterEnum.valueOf(parts[2]))
                .week(WeekEnum.getByString(parts[3]))
                .classType(ClassTypeEnum.getByCode(parts[4]))
                .build();
    }

    /**
     * Builds a UnitWeeklyAttendanceSummary from session summaries
     *
     * @param sessionSummaries   list of session summaries for this week
     * @param sessionId          the session id
     * @param unitYearSemesterId the unit year semester id
     * @return the built UnitWeeklyAttendanceSummary
     */
    private UnitWeeklyAttendanceSummary buildWeeklySummary(List<StudentSessionSummary> sessionSummaries,
                                                           SessionId sessionId,
                                                           UnitYearSemesterId unitYearSemesterId) {
        int totalAttendance    = (int) sessionSummaries.stream().filter(StudentSessionSummary::isPresent).count();
        int totalAbsence       = (int) sessionSummaries.stream().filter(s -> !s.isPresent()).count();
        int totalLateArrival   = (int) sessionSummaries.stream().filter(StudentSessionSummary::isLateArrival).count();
        int totalEarlyDeparture = (int) sessionSummaries.stream().filter(StudentSessionSummary::isEarlyDeparture).count();

        UnitYearSemesterWeekId weekId = UnitYearSemesterWeekId.builder()
                .unitCode(unitYearSemesterId.getUnitCode())
                .year(unitYearSemesterId.getYear())
                .semester(unitYearSemesterId.getSemester())
                .week(sessionId.getWeek())
                .build();

        return UnitWeeklyAttendanceSummary.builder()
                .id(weekId)
                .week(sessionId.getWeek())
                .totalAttendance(totalAttendance)
                .totalAbsence(totalAbsence)
                .totalLateArrival(totalLateArrival)
                .totalEarlyDeparture(totalEarlyDeparture)
                .build();
    }
}

package com.fyp.mcs14.service.impl;

import com.fyp.mcs14.common.ResponseResult;
import com.fyp.mcs14.model.converter.LoginConverter;
import com.fyp.mcs14.model.dataobject.LecturerDO;
import com.fyp.mcs14.model.dataobject.StudentDO;
import com.fyp.mcs14.model.dto.authentication.AuthUserDTO;
import com.fyp.mcs14.model.dto.authentication.LoginRequestDTO;
import com.fyp.mcs14.model.enums.FacultyEnum;
import com.fyp.mcs14.model.enums.ResponseStatusEnum;
import com.fyp.mcs14.model.enums.UserRoleEnum;
import com.fyp.mcs14.model.model.authentication.AuthUser;
import com.fyp.mcs14.model.model.authentication.LecturerAuthUser;
import com.fyp.mcs14.model.model.authentication.StudentAuthUser;
import com.fyp.mcs14.repository.AuthRepository;
import com.fyp.mcs14.repository.LecturerRepository;
import com.fyp.mcs14.repository.StudentRepository;
import com.fyp.mcs14.service.AuthService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class AuthServiceImpl implements AuthService {
    @Autowired
    private AuthRepository authRepository;

    @Autowired
    private LecturerRepository lecturerRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Override
    public ResponseResult<AuthUserDTO> validateLogin(LoginRequestDTO loginRequestDTO) {

        AuthUser authUser = authRepository.findByEmailAndPassword(LoginConverter.convertDTO2Model(loginRequestDTO));

        if (authUser == null) {
            return new ResponseResult<>(ResponseStatusEnum.FAIL, null);
        }
        if (authUser.getUserRole() == UserRoleEnum.LECTURER) {
            LecturerDO lecturerDO = lecturerRepository.getLecturerByEmail(authUser.getEmail());
            if (lecturerDO != null) {
                LecturerAuthUser lecturerAuthUser = new LecturerAuthUser();
                lecturerAuthUser.setId(lecturerDO.getId());
                lecturerAuthUser.setEmail(lecturerDO.getEmail());
                lecturerAuthUser.setPhone(lecturerDO.getPhone());
                lecturerAuthUser.setUserRole(authUser.getUserRole());
                lecturerAuthUser.setName(lecturerDO.getName());
                lecturerAuthUser.setProfilePhotoUrl(lecturerDO.getProfilePhotoUrl());
                lecturerAuthUser.setFaculty(FacultyEnum.valueOf(lecturerDO.getFaculty()));
                lecturerAuthUser.setOffice(lecturerDO.getOffice());
                lecturerAuthUser.setResearchArea(lecturerDO.getResearchArea());
                authUser = lecturerAuthUser;
            }
        }
        else if (authUser.getUserRole() == UserRoleEnum.STUDENT) {
            StudentDO studentDO = studentRepository.getStudentByEmail(authUser.getEmail());
            if (studentDO != null) {
                StudentAuthUser studentAuthUser = new StudentAuthUser();
                studentAuthUser.setId(studentDO.getStudentId());
                studentAuthUser.setEmail(studentDO.getEmail());
                studentAuthUser.setUserRole(authUser.getUserRole());
                studentAuthUser.setName(studentDO.getName());
                studentAuthUser.setProfilePhotoUrl(studentDO.getProfilePhotoUrl());
                studentAuthUser.setFaculty(FacultyEnum.valueOf(studentDO.getFaculty()));
                studentAuthUser.setPhone(studentDO.getPhone());
                authUser = studentAuthUser;
            }
        }

        // TODO: continue student logic
        log.info("User logged in: {}", authUser);
        return ResponseResult.success(LoginConverter.convertModel2DTO(authUser));
    }
}

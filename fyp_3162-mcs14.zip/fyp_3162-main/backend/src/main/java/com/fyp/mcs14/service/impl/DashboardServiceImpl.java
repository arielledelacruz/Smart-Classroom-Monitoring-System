package com.fyp.mcs14.service.impl;

import com.fyp.mcs14.model.converter.StudentConverter;
import com.fyp.mcs14.model.converter.UnitWeeklyAttendanceSummaryConverter;
import com.fyp.mcs14.model.dataobject.StudentUnitSummaryDO;
import com.fyp.mcs14.model.dataobject.UnitWeeklyAttendanceSummaryDO;
import com.fyp.mcs14.model.dto.UnitOverviewResponseDTO;
import com.fyp.mcs14.model.dto.dashboard.DashboardQueryUnitStudentRequestDTO;
import com.fyp.mcs14.model.dto.dashboard.StudentListViewDTO;
import com.fyp.mcs14.model.model.Student;
import com.fyp.mcs14.model.model.StudentUnitSummary;
import com.fyp.mcs14.model.model.UnitSemesterData;
import com.fyp.mcs14.model.model.dashboard.DashboardQueryUnitStudentRequest;
import com.fyp.mcs14.model.dto.dashboard.DashboardUnitAttendanceSummaryResponseDTO;
import com.fyp.mcs14.model.dto.dashboard.DashboardUnitSemesterStudentsResponseDTO;
import com.fyp.mcs14.model.enums.UnitCodeEnum;
import com.fyp.mcs14.model.enums.WeekEnum;
import com.fyp.mcs14.model.model.attendance.UnitWeeklyAttendanceSummary;
import com.fyp.mcs14.model.model.attendance.UnitYearSemesterId;
import com.fyp.mcs14.model.model.attendance.UnitYearSemesterWeekId;
import com.fyp.mcs14.model.model.dashboard.DashboardFilterRequest;
import com.fyp.mcs14.model.model.attendance.UnitAttendanceSummary;
import com.fyp.mcs14.repository.StudentRepository;
import com.fyp.mcs14.repository.StudentUnitSummaryRepository;
import com.fyp.mcs14.repository.UnitWeeklyAttendanceSummaryRepository;
import com.fyp.mcs14.service.DashboardService;
import com.fyp.mcs14.service.UnitOverviewService;
import com.fyp.mcs14.service.UnitService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Slf4j
@Service
public class DashboardServiceImpl implements DashboardService {
        @Autowired
        private UnitWeeklyAttendanceSummaryRepository weeklyAttendanceSummaryRepository;

        @Autowired
        private UnitService unitService;

        @Autowired
        private StudentRepository studentRepository;

        @Autowired
        private StudentUnitSummaryRepository studentUnitSummaryRepository;

        @Autowired
        private UnitOverviewService unitOverviewService;

        private final String dashboardLoggerPrefix = "DASHBOARD_SERVICE: ";

        @Override
        public DashboardUnitAttendanceSummaryResponseDTO getFilteredData(DashboardFilterRequest request) {
            try {
                log.info("{} receive dashboard unit filter request: {}", dashboardLoggerPrefix, request);

                if (request.getUnitCodeList().size() > 2) {
                    throw new IllegalArgumentException("Maximum 2 units allowed for comparison");
                }

                List<UnitOverviewResponseDTO> unitOverviewList = request.getUnitCodeList()
                        .stream()
                        .map(unitCode -> {
                            String unitSemesterId = UnitYearSemesterId.builder()
                                    .unitCode(unitCode)
                                    .year(Integer.parseInt(request.getYear()))
                                    .semester(request.getSemester())
                                    .build()
                                    .generateUniqueId();
                            return unitOverviewService.getUnitOverview(unitSemesterId, request.getWeekStart(), request.getWeekEnd());
                        })
                        .collect(Collectors.toList());

                log.info("Unit Overview List: {}", unitOverviewList);

                return DashboardUnitAttendanceSummaryResponseDTO.builder()
                        .unitOverviewList(unitOverviewList)
                        .build();
            }
            catch (Exception e) {
                log.error("Error: ", e);
                return null;
            }
        }

        @Override
        public DashboardUnitSemesterStudentsResponseDTO getUnitSemesterStudents(DashboardQueryUnitStudentRequest dashboardFilterRequest) {
            try {

                log.info("{} get all students of unit {}", dashboardLoggerPrefix, dashboardFilterRequest);

                String id = UnitYearSemesterId.builder()
                        .unitCode(dashboardFilterRequest.getUnitCode())
                        .year(dashboardFilterRequest.getYear())
                        .semester(dashboardFilterRequest.getSemester())
                        .build()
                        .generateUniqueId();

                UnitSemesterData unitSemesterData = unitService.getUnitSemesterData(id);

                log.info("Student id list: {}", unitSemesterData.getStudentIdList());

                List<Student> studentList = StudentConverter.convertDOList2ModelList(
                        studentRepository.getByIdList(unitSemesterData.getStudentIdList())
                );

                DashboardUnitSemesterStudentsResponseDTO dto = new DashboardUnitSemesterStudentsResponseDTO();
                dto.setUnitSemesterId(id);
                dto.setTotalStudents(unitSemesterData.getTotalStudents());
                dto.setStudents(studentList.stream().map(StudentConverter::convertModel2ListViewDTO).toList());

                fillStudentAttendanceData(dto);

                log.info("Students retrieved: {}", dto);

                return dto;
            }
            catch (Exception e) {
                log.error("error: ", e);
            }
            return null;
        }

        /**
         * Generates a list of Firestore document IDs for the given week range
         * e.g. ["FIT3077-2025-S1-W1", "FIT3077-2025-S1-W2", ...]
         */
        private List<String> generateWeekIds(UnitCodeEnum unitCode, DashboardFilterRequest request) {
            List<String> weekIds = new ArrayList<>();
            boolean inRange = false;

            for (WeekEnum week : WeekEnum.values()) {
                if (week == request.getWeekStart()) inRange = true;
                if (inRange) {
                    UnitYearSemesterWeekId id = UnitYearSemesterWeekId.builder()
                            .unitCode(unitCode)
                            .year(Integer.parseInt(request.getYear()))
                            .semester(request.getSemester())
                            .week(week)
                            .build();
                    weekIds.add(id.generateUniqueId());
                }
                if (week == request.getWeekEnd()) break;
            }
            log.info("weekIds: {}", weekIds);
            return weekIds;
        }

        /**
         * Builds a UnitAttendanceSummary by aggregating weekly summaries
         */
        private UnitAttendanceSummary buildUnitAttendanceSummary(UnitCodeEnum unitCode,
                                                                 DashboardFilterRequest request,
                                                                 List<UnitWeeklyAttendanceSummary> weeklySummaries) {
            int totalAttendance = weeklySummaries.stream().mapToInt(UnitWeeklyAttendanceSummary::getTotalAttendance).sum();
            int totalAbsence = weeklySummaries.stream().mapToInt(UnitWeeklyAttendanceSummary::getTotalAbsence).sum();
            int totalEarlyDeparture = weeklySummaries.stream().mapToInt(UnitWeeklyAttendanceSummary::getTotalEarlyDeparture).sum();
            int totalLateArrival = weeklySummaries.stream().mapToInt(UnitWeeklyAttendanceSummary::getTotalLateArrival).sum();

            UnitYearSemesterId unitYearSemesterId = UnitYearSemesterId.builder()
                    .unitCode(unitCode)
                    .year(Integer.parseInt(request.getYear()))
                    .semester(request.getSemester())
                    .build();

            int overallAttendanceRate = 0;
            int denom = totalAttendance + totalAbsence;
            if (denom > 0) {
                overallAttendanceRate = (int) ((long) totalAttendance * 100 / denom);
            }

            return UnitAttendanceSummary.builder()
                    .unitYearSemesterId(unitYearSemesterId)
                    .unitCode(unitCode.name())
                    .unitWeeklyAttendanceSummaryList(weeklySummaries)
                    .totalAttendance(totalAttendance)
                    .totalAbsence(totalAbsence)
                    .totalEarlyDeparture(totalEarlyDeparture)
                    .totalLateArrival(totalLateArrival)
                    .overallAttendanceRate(overallAttendanceRate)
                    .overallEngagementScore(0.0)
                    .build();
        }

        @Override
        public UnitAttendanceSummary getUnitAttendanceSummary(UnitCodeEnum unitCode, DashboardFilterRequest request) {
            List<String> weekIds = generateWeekIds(unitCode, request);

            List<UnitWeeklyAttendanceSummaryDO> summaryDOs = weeklyAttendanceSummaryRepository.getUnitWeeklyAttendanceSummaryByIdList(weekIds);

            List<UnitWeeklyAttendanceSummary> weeklySummaries = summaryDOs.stream()
                    .map(UnitWeeklyAttendanceSummaryConverter::convertDO2Model)
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());

            return buildUnitAttendanceSummary(unitCode, request, weeklySummaries);
        }

        private void fillStudentAttendanceData(DashboardUnitSemesterStudentsResponseDTO dto) {
            List<StudentListViewDTO> studentList = dto.getStudents();

            for (StudentListViewDTO student: studentList) {
                StudentUnitSummaryDO studentUnitSummaryDO = studentUnitSummaryRepository.getByStudentAndUnitSemesterId(student.getId(), dto.getUnitSemesterId());
                log.info("Student Summary DO: {}", studentUnitSummaryDO);
                if (studentUnitSummaryDO != null) {
                    student.setAttendanceRate(studentUnitSummaryDO.getAttendanceRate());
                    student.setEngagementScore(studentUnitSummaryDO.getAvgEngagementScore());
                }
            }
        }
}

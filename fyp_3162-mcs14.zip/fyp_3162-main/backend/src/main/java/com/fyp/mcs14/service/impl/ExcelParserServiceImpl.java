package com.fyp.mcs14.service.impl;

import com.fyp.mcs14.model.enums.*;
import com.fyp.mcs14.model.model.*;
import com.fyp.mcs14.model.model.attendance.UnitYearSemesterId;
import com.fyp.mcs14.model.model.excel.AttendanceExcelFileName;
import com.fyp.mcs14.model.model.excel.MotionRecord;
import com.fyp.mcs14.model.model.excel.RawAttendanceRecord;
import com.fyp.mcs14.service.ExcelParserService;
import com.fyp.mcs14.model.model.attendance.SessionId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.Duration;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class ExcelParserServiceImpl implements ExcelParserService{

    // main entry point
    @Override
    public List<RawAttendanceRecord> parseAttendanceExcel(MultipartFile file) throws IOException {

        AttendanceExcelFileName fileInfo = parseFilename(Objects.requireNonNull(file.getOriginalFilename()));
        UnitCodeEnum unitCode   = fileInfo.getUnitCode();
        String year             = fileInfo.getYear();
        SemesterEnum semester   = fileInfo.getSemester();
        WeekEnum week           = fileInfo.getWeek();
        ClassTypeEnum classType = fileInfo.getClassType();
        LocalTime startTime = null;
        LocalTime endTime = null;

        Workbook workbook = new XSSFWorkbook(file.getInputStream());

        Map<String, List<RawRow>> byStudent = new HashMap<>();

        // new: total duration across all sheets
        long totalSessionDurationMinutes = 0;

        for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
            Sheet sheet = workbook.getSheetAt(i);

            LocalTime sheetStart = null;
            LocalTime sheetEnd = null;

            for (Row row : sheet) {
                if (row.getRowNum() == 0) continue;
                if (isRowEmpty(row)) continue;

                String studentId  = getCellValue(row, 1);
                String motionType = getCellValue(row, 2);
                String time       = getCellValue(row, 4);

                byStudent.computeIfAbsent(studentId, k -> new ArrayList<>())
                        .add(new RawRow(motionType, time));

                // parse time for sheet duration calculation
                LocalTime currentTime = parseTime(time);
                if (currentTime != null) {
                    if (sheetStart == null || currentTime.isBefore(sheetStart)) {
                        sheetStart = currentTime;
                    }
                    if (sheetEnd == null || currentTime.isAfter(sheetEnd)) {
                        sheetEnd = currentTime;
                    }
                }

                if (currentTime != null) {

                    if (startTime == null) {
                        startTime = currentTime;
                    }

                    endTime = currentTime;
                }
            }

            // add this sheet's duration
            if (sheetStart != null && sheetEnd != null) {
                totalSessionDurationMinutes += Duration.between(sheetStart, sheetEnd).toMinutes();
            }
        }

        workbook.close();

        List<RawAttendanceRecord> result = new ArrayList<>();

        for (Map.Entry<String, List<RawRow>> entry : byStudent.entrySet()) {
            String studentId = entry.getKey();
            List<RawRow> rows = entry.getValue();

            SessionId sessionId = new SessionId(studentId, unitCode, year, semester, week, classType);

            Map<String, Map<String, Long>> grouped = rows.stream()
                    .collect(Collectors.groupingBy(
                            RawRow::getTime,
                            Collectors.groupingBy(
                                    RawRow::getMotionType,
                                    Collectors.counting()
                            )
                    ));

            List<MotionRecord> records = new ArrayList<>();
            for (Map.Entry<String, Map<String, Long>> timeEntry : grouped.entrySet()) {
                for (Map.Entry<String, Long> motionEntry : timeEntry.getValue().entrySet()) {
                    records.add(MotionRecord.builder()
                            .time(to24HourFormat(timeEntry.getKey()))
                            .motionType(MotionTypeEnum.getByString(motionEntry.getKey()))
                            .numberOfMotion(motionEntry.getValue().intValue())
                            .build());
                }
            }

            records.sort(Comparator.comparing(MotionRecord::getTime));

            result.add(RawAttendanceRecord.builder()
                    .studentId(studentId)
                    .sessionId(sessionId)
                    .sessionDuration((int) totalSessionDurationMinutes) // or long
                    .startTime(startTime)
                    .endTime(endTime)
                    .records(records)
                    .build());
        }

        log.info("Parsed Records: {}", result);

        return result;
    }

    private LocalTime parseTime(String time) {
        if (time == null || time.isBlank()) return null;

        String formatted = to24HourFormat(time); // assuming this returns something like 13:45:00 or 13:45
        try {
            return LocalTime.parse(formatted);
        } catch (Exception e) {
            try {
                return LocalTime.parse(formatted, DateTimeFormatter.ofPattern("H:mm"));
            } catch (Exception ex) {
                try {
                    return LocalTime.parse(formatted, DateTimeFormatter.ofPattern("H:mm:ss"));
                } catch (Exception ignored) {
                    return null;
                }
            }
        }
    }

    @Override
    public UnitSemesterData parseUnitSemesterDataExcel(MultipartFile file) {
        try (Workbook workbook = new XSSFWorkbook(file.getInputStream())) {
            Sheet sheet = workbook.getSheetAt(0);

            // Step 1: parse filename to get unit semester id
            String originalFilename = file.getOriginalFilename();
            String unitSemesterId = originalFilename.replace("-students.xlsx", "");
            UnitYearSemesterId unitYearSemesterId = UnitYearSemesterId.fromUniqueId(unitSemesterId);

            // Step 2: parse student ids from excel
            List<String> studentIds = new ArrayList<>();
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;

                String studentId = getCellValue(row, 0);
                if (!studentId.isEmpty()) {
                    studentIds.add(studentId);
                }
            }

            // Step 3: build UnitSemesterData
            return UnitSemesterData.builder()
                    .id(unitYearSemesterId)
                    .studentIdList(studentIds)
                    .totalStudents(studentIds.size())
                    .build();

        } catch (Exception e) {
            throw new RuntimeException("Failed to parse unit semester Excel file: " + file.getOriginalFilename(), e);
        }
    }

    /**
     * Method to parse excel containing student assignment marks of a unit in a semester year
     * File name will be expecting 'FIT3077-2025-S1-marks.xlsx'
     *
     * @param file the Excel file to parse
     * @return ParsedMarkData containing assignments and student marks
     */
    @Override
    public ParsedMarkData parseUnitSemesterMarkExcel(MultipartFile file) {
        try (Workbook workbook = new XSSFWorkbook(file.getInputStream())) {
            Sheet sheet = workbook.getSheetAt(0);

            // Step 1: parse filename to get unit semester id
            String originalFilename = file.getOriginalFilename();
            String unitSemesterId = originalFilename.replace("-marks.xlsx", "");
            UnitYearSemesterId unitYearSemesterId = UnitYearSemesterId.fromUniqueId(unitSemesterId);

            // Step 2: parse rows
            Map<String, UnitSemesterAssignment> assignmentMap = new LinkedHashMap<>();
            List<UnitSemesterStudentMark> studentMarks = new ArrayList<>();

            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;

                String studentId      = getCellValue(row, 0);
                String assignmentId   = getCellValue(row, 1);
                String assignmentName = getCellValue(row, 2);
                double marks          = row.getCell(3).getNumericCellValue();

                // collect unique assignments
                assignmentMap.putIfAbsent(assignmentId, UnitSemesterAssignment.builder()
                        .unitYearSemesterId(unitYearSemesterId)
                        .assignmentId(assignmentId)
                        .assignmentName(assignmentName)
                        .build());

                // collect student marks
                studentMarks.add(UnitSemesterStudentMark.builder()
                        .unitYearSemesterId(unitYearSemesterId)
                        .assignmentId(assignmentId)
                        .studentId(studentId)
                        .marks(marks)
                        .build());
            }

            return ParsedMarkData.builder()
                    .assignments(new ArrayList<>(assignmentMap.values()))
                    .studentMarks(studentMarks)
                    .build();

        } catch (Exception e) {
            throw new RuntimeException("Failed to parse unit semester mark Excel file: " + file.getOriginalFilename(), e);
        }
    }

    /**
     * Method to parse excel containing student data
     * File name will be expecting 'students.xlsx'
     *
     * Expected file structure:
     * | studentId | email | name | faculty | phone | enrolledYear |
     *
     * @param file the Excel file to parse
     * @return list of Student domain objects parsed from the Excel file
     */
    @Override
    public List<Student> parseStudentsExcel(MultipartFile file) {
        try (Workbook workbook = new XSSFWorkbook(file.getInputStream())) {
            Sheet sheet = workbook.getSheetAt(0);
            List<Student> students = new ArrayList<>();

            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;

                String studentId  = getCellValue(row, 0);
                String email      = getCellValue(row, 1);
                String name       = getCellValue(row, 2);
                String faculty    = getCellValue(row, 3);
                String phone      = getCellValue(row, 4);
                int enrolledYear  = (int) row.getCell(5).getNumericCellValue();

                if (studentId.isEmpty()) continue;

                students.add(Student.builder()
                        .studentId(studentId)
                        .email(email)
                        .name(name)
                        .faculty(FacultyEnum.valueOf(faculty))
                        .phone(phone)
                        .enrolledYear(enrolledYear)
                        .userRole(UserRoleEnum.STUDENT)
                        .build());
            }

            return students;
        } catch (Exception e) {
            throw new RuntimeException("Failed to parse student Excel file: " + file.getOriginalFilename(), e);
        }
    }

    /**
     * Method to parse excel containing lecturer data
     * File name will be expecting 'lecturers.xlsx'
     *
     * Expected file structure:
     * | id | name | email | phone | faculty | office | researchArea (comma-separated) |
     *
     * @param file the Excel file to parse
     * @return list of Lecturer domain objects parsed from the Excel file
     */
    @Override
    public List<Lecturer> parseLecturersExcel(MultipartFile file) {
        try (Workbook workbook = new XSSFWorkbook(file.getInputStream())) {
            Sheet sheet = workbook.getSheetAt(0);
            List<Lecturer> lecturers = new ArrayList<>();

            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;

                String id          = getCellValue(row, 0);
                String name        = getCellValue(row, 1);
                String email       = getCellValue(row, 2);
                String phone       = getCellValue(row, 3);
                String faculty     = getCellValue(row, 4);
                String office      = getCellValue(row, 5);
                String researchRaw = getCellValue(row, 6);  // e.g. "BlockChain, AI, Machine Learning"

                if (id.isEmpty()) continue;

                List<String> researchArea = researchRaw.isEmpty()
                        ? new ArrayList<>()
                        : Arrays.stream(researchRaw.split(","))
                        .map(String::trim)
                        .collect(Collectors.toList());

                lecturers.add(Lecturer.builder()
                        .id(id)
                        .name(name)
                        .email(email)
                        .phone(phone)
                        .faculty(FacultyEnum.valueOf(faculty))
                        .office(office)
                        .researchArea(researchArea)
                        .build());
            }

            return lecturers;
        } catch (Exception e) {
            throw new RuntimeException("Failed to parse lecturer Excel file: " + file.getOriginalFilename(), e);
        }
    }

    private AttendanceExcelFileName parseFilename(String filename) {
        // "FIT3077_2025S1_W7_T.xlsx" → "FIT3077_2025S1_W7_T"
        String name    = filename.replace(".xlsx", "").replace(".xls", "").trim();
        String[] parts = name.split("_");

        if (parts.length < 5) {
            throw new IllegalArgumentException(
                    "Invalid filename format. Expected: UNITCODE_YEAR_SEMSETER_W#_CLASSTYPE.xlsx, got: " + filename
            );
        }

        String unitCodeStr  = parts[0];   // "FIT3077"
        String year = parts[1];   // "2025"
        String semester = parts[2]; // "S1"
        String weekStr      = parts[3];   // "W7"
        String classTypeStr = parts[4];   // "T"


        return AttendanceExcelFileName.builder()
                .unitCode(UnitCodeEnum.valueOf(unitCodeStr.toUpperCase()))
                .year(year)
                .semester(SemesterEnum.valueOf(semester.toUpperCase()))
                .week(WeekEnum.getByString(weekStr))
                .classType(ClassTypeEnum.getByCode(classTypeStr))
                .build();
    }

    // ─── Helper inner class ───────────────────────────────────────────────────
    @Data
    @AllArgsConstructor
    private static class RawRow {
        private String motionType;
        private String time;
    }

    // ─── Cell helpers ─────────────────────────────────────────────────────────
    private String getCellValue(Row row, int col) {
        Cell cell = row.getCell(col);
        if (cell == null) return "";
        return switch (cell.getCellType()) {
            case STRING  -> cell.getStringCellValue().trim();
            case NUMERIC -> String.valueOf((long) cell.getNumericCellValue());
            default      -> "";
        };
    }

    private boolean isRowEmpty(Row row) {
        Cell cell = row.getCell(0);
        return cell == null || cell.getCellType() == CellType.BLANK;
    }

    private static final DateTimeFormatter OUTPUT_FORMAT =
            DateTimeFormatter.ofPattern("HH:mm");

    private static final List<DateTimeFormatter> INPUT_FORMATS = List.of(
            DateTimeFormatter.ofPattern("h.mm.ss a", Locale.ENGLISH), // 8.15.23 AM
            DateTimeFormatter.ofPattern("h.mm a", Locale.ENGLISH),    // 8.15 AM
            DateTimeFormatter.ofPattern("H:mm:ss"),                   // 08:15:23
            DateTimeFormatter.ofPattern("H:mm")                       // 08:15
    );

    public String to24HourFormat(String raw) {
        if (raw == null || raw.isBlank()) return "";

        String normalized = raw
                .trim()
                .replace('\u00A0', ' ')   // Excel NBSP fix
                .replaceAll("\\s+", " ")
                .toUpperCase()
                .replaceAll("(?i)(\\d)(AM|PM)$", "$1 $2");

        for (DateTimeFormatter formatter : INPUT_FORMATS) {
            try {
                LocalTime time = LocalTime.parse(normalized, formatter);
                return time.format(OUTPUT_FORMAT);
            } catch (Exception ignored) {
            }
        }

        throw new IllegalArgumentException("Invalid time format: " + raw);
    }
}

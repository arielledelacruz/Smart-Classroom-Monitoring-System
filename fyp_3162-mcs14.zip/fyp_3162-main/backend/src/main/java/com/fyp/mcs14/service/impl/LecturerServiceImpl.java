package com.fyp.mcs14.service.impl;

import com.fyp.mcs14.repository.LecturerRepository;
import com.fyp.mcs14.service.LecturerService;
import com.google.api.client.util.Value;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Storage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class LecturerServiceImpl implements LecturerService {

    @Autowired
    private Storage storage;

    @Autowired
    private LecturerRepository lecturerRepository;

    @Value("${firebase.storage.bucket}")
    private String bucketName;

    @Override
    public void uploadProfilePhoto(String lecturerId, MultipartFile file) {
        validatePhotoFile(file);
        try {
            String storagePath = "profile-photos/lecturers/" + lecturerId + ".jpg";
            BlobId blobId = BlobId.of(bucketName, storagePath);
            BlobInfo blobInfo = BlobInfo.newBuilder(blobId)
                    .setContentType(file.getContentType())
                    .build();
            storage.create(blobInfo, file.getBytes());

            String photoUrl = String.format(
                    "https://storage.googleapis.com/%s/%s", bucketName, storagePath);

            lecturerRepository.updateProfilePhotoUrl(lecturerId, photoUrl);  // ← clean

        } catch (Exception e) {
            throw new RuntimeException("Failed to upload profile photo for lecturer: " + lecturerId, e);
        }
    }

    private void validatePhotoFile(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("Photo file must not be empty");
        }
        if (file.getContentType() == null || !file.getContentType().startsWith("image/")) {
            throw new IllegalArgumentException("File must be an image, got: " + file.getContentType());
        }
        if (file.getSize() > 5 * 1024 * 1024) {
            throw new IllegalArgumentException("File size must not exceed 5MB");
        }
    }
}

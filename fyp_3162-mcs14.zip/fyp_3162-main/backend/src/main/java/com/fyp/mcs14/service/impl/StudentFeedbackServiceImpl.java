package com.fyp.mcs14.service.impl;

import com.fyp.mcs14.model.dataobject.StudentDO;
import com.fyp.mcs14.model.dataobject.StudentFeedbackDO;
import com.fyp.mcs14.model.dto.StudentFeedbackDTO;
import com.fyp.mcs14.model.model.StudentFeedback;
import com.fyp.mcs14.repository.StudentFeedbackRepository;
import com.fyp.mcs14.service.StudentFeedbackService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class StudentFeedbackServiceImpl implements StudentFeedbackService {

    @Autowired
    private StudentFeedbackRepository studentFeedbackRepository;

    @Override
    public void saveFeedback(StudentFeedback feedback) {
        StudentFeedbackDO feedbackDO = convertModelToDO(feedback);
        studentFeedbackRepository.saveFeedback(feedbackDO);
    }

    @Override
    public StudentFeedbackDTO getFeedbackById(String feedbackId) {
        StudentFeedbackDO feedbackDO = studentFeedbackRepository.getFeedbackById(feedbackId);
        return feedbackDO != null ? convertDOToDTO(feedbackDO) : null;
    }

    @Override
    public List<StudentFeedbackDTO> getFeedbackByStudentAndUnit(String studentId, String unitCode) {
        List<StudentFeedbackDO> feedbackList = studentFeedbackRepository
                .getFeedbackByStudentIdAndUnitCode(studentId, unitCode);
        return feedbackList.stream()
                .map(this::convertDOToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<StudentFeedbackDTO> getFeedbackByStudent(String studentId) {
        List<StudentFeedbackDO> feedbackList = studentFeedbackRepository.getFeedbackByStudentId(studentId);
        return feedbackList.stream()
                .map(this::convertDOToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<StudentFeedbackDTO> getFeedbackByUnit(String unitCode) {
        List<StudentFeedbackDO> feedbackList = studentFeedbackRepository.getFeedbackByUnitCode(unitCode);
        return feedbackList.stream()
                .map(this::convertDOToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<StudentFeedbackDTO> getFeedbackByLecturerAndUnit(String lecturerId, String unitCode) {
        List<StudentFeedbackDO> feedbackList = studentFeedbackRepository
                .getFeedbackByLecturerIdAndUnitCode(lecturerId, unitCode);
        return feedbackList.stream()
                .map(this::convertDOToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public void deleteFeedback(String feedbackId) {
        studentFeedbackRepository.deleteFeedback(feedbackId);
    }

    /* ============= Helper Methods ============= */

    private StudentFeedbackDO convertModelToDO(StudentFeedback feedback) {
        StudentFeedbackDO feedbackDO = new StudentFeedbackDO();
        feedbackDO.setFeedbackId(feedback.getFeedbackId());
        feedbackDO.setStudentId(feedback.getStudentId());
        feedbackDO.setLecturerId(feedback.getLecturerId());
        feedbackDO.setUnitCode(feedback.getUnitCode());
        feedbackDO.setFeedbackContent(feedback.getFeedbackContent());
        feedbackDO.setFeedbackType(feedback.getFeedbackType());
        feedbackDO.setCreatedAt(feedback.getCreatedAt());
        feedbackDO.setUpdatedAt(feedback.getUpdatedAt());
        return feedbackDO;
    }

    private StudentFeedbackDTO convertDOToDTO(StudentFeedbackDO feedbackDO) {
        StudentFeedbackDTO feedbackDTO = new StudentFeedbackDTO();
        feedbackDTO.setFeedbackId(feedbackDO.getFeedbackId());
        feedbackDTO.setStudentId(feedbackDO.getStudentId());
        feedbackDTO.setLecturerId(feedbackDO.getLecturerId());
        feedbackDTO.setUnitCode(feedbackDO.getUnitCode());
        feedbackDTO.setFeedbackContent(feedbackDO.getFeedbackContent());
        feedbackDTO.setFeedbackType(feedbackDO.getFeedbackType());
        feedbackDTO.setCreatedAt(feedbackDO.getCreatedAt());
        feedbackDTO.setUpdatedAt(feedbackDO.getUpdatedAt());
        return feedbackDTO;
    }
}

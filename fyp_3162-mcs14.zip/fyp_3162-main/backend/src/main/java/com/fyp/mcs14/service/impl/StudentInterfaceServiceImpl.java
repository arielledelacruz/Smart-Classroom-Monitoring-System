package com.fyp.mcs14.service.impl;

import com.fyp.mcs14.common.AssertUtil;
import com.fyp.mcs14.model.dataobject.StudentAnalyticsResultDO;
import com.fyp.mcs14.model.dataobject.StudentDO;
import com.fyp.mcs14.model.dataobject.StudentSessionSummaryDO;
import com.fyp.mcs14.model.dataobject.StudentUnitSummaryDO;
import com.fyp.mcs14.model.dataobject.UnitDO;
import com.fyp.mcs14.model.dto.StudentInterface.EnrolledUnitDTO;
import com.fyp.mcs14.model.dto.StudentInterface.StudentAnalyticsResultDTO;
import com.fyp.mcs14.model.dto.StudentInterface.StudentEnrolledUnitsDTO;
import com.fyp.mcs14.model.dto.StudentInterface.StudentOverallAttendanceSummaryDTO;
import com.fyp.mcs14.model.dto.StudentInterface.StudentSessionHistoryDTO;
import com.fyp.mcs14.model.dto.StudentInterface.StudentSessionRecordDTO;
import com.fyp.mcs14.model.dto.StudentInterface.StudentUnitAttendanceDetailDTO;
import com.fyp.mcs14.model.dto.StudentInterface.StudentUnitSummaryCardDTO;
import com.fyp.mcs14.model.dto.StudentInterface.StudentWeeklyAttendanceDTO;
import com.fyp.mcs14.repository.StudentAnalyticsResultRepository;
import com.fyp.mcs14.repository.StudentRepository;
import com.fyp.mcs14.repository.StudentSessionSummaryRepository;
import com.fyp.mcs14.repository.StudentUnitSummaryRepository;
import com.fyp.mcs14.repository.UnitRepository;
import com.fyp.mcs14.service.StudentInterfaceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Slf4j
@Service
public class StudentInterfaceServiceImpl implements StudentInterfaceService {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private StudentAnalyticsResultRepository studentAnalyticsResultRepository;

    @Autowired
    private StudentSessionSummaryRepository studentSessionSummaryRepository;

    @Autowired
    private StudentUnitSummaryRepository studentUnitSummaryRepository;

    @Autowired
    private UnitRepository unitRepository;

    private final String logPrefix = "STUDENT_INTERFACE_SERVICE: ";

    @Override
    public StudentEnrolledUnitsDTO getEnrolledUnits(String studentId, String year, String semester) {
        log.info("{} getEnrolledUnits - studentId: {} year: {} semester: {}",
                logPrefix, studentId, year, semester);

        StudentDO studentDO = studentRepository.getById(studentId);
        if (studentDO == null) {
            throw new RuntimeException("Student not found: " + studentId);
        }

        // filter enrolled units by year and semester
        String yearSemesterSuffix = year + "-" + semester;
        List<String> filteredUnitSemesterIds = studentDO.getEnrolledUnitSemesterCode()
                .stream()
                .filter(id -> id.endsWith(yearSemesterSuffix))
                .toList();

        // build enrolled unit DTOs
        List<EnrolledUnitDTO> enrolledUnits = filteredUnitSemesterIds.stream()
                .map(unitSemesterId -> {
                    String[] parts = unitSemesterId.split("-");
                    return EnrolledUnitDTO.builder()
                            .unitSemesterId(unitSemesterId)
                            .unitCode(parts[0])
                            .unitName(getUnitName(parts[0]))
                            .build();
                })
                .collect(Collectors.toList());

        return StudentEnrolledUnitsDTO.builder()
                .studentId(studentId)
                .year(year)
                .semester(semester)
                .totalUnits(enrolledUnits.size())
                .enrolledUnits(enrolledUnits)
                .build();
    }

    @Override
    public StudentOverallAttendanceSummaryDTO getAttendanceSummary(String studentId,
                                                                   String year,
                                                                   String semester) {
        log.info("{} getAttendanceSummary - studentId: {} year: {} semester: {}",
                logPrefix, studentId, year, semester);

        StudentDO studentDO = studentRepository.getById(studentId);
        if (studentDO == null) {
            throw new RuntimeException("Student not found: " + studentId);
        }

        // filter enrolled units by year and semester
        String yearSemesterSuffix = year + "-" + semester;
        List<String> filteredUnitSemesterIds = studentDO.getEnrolledUnitSemesterCode()
                .stream()
                .filter(id -> id.endsWith(yearSemesterSuffix))
                .toList();

        // fetch analytics result for each unit
        List<StudentUnitSummaryCardDTO> unitSummaryList = filteredUnitSemesterIds.stream()
                .map(unitSemesterId -> buildUnitSummaryCard(studentId, unitSemesterId))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        // compute overall averages
        double overallAttendanceRate = unitSummaryList.stream()
                .mapToDouble(StudentUnitSummaryCardDTO::getAttendanceRate)
                .average().orElse(0);

        double overallEngagementScore = unitSummaryList.stream()
                .mapToDouble(StudentUnitSummaryCardDTO::getEngagementScore)
                .average().orElse(0);

        double overallRiskScore = unitSummaryList.stream()
                .mapToDouble(StudentUnitSummaryCardDTO::getRiskScore)
                .average().orElse(0);

        return StudentOverallAttendanceSummaryDTO.builder()
                .studentId(studentId)
                .year(year)
                .semester(semester)
                .overallAttendanceRate(overallAttendanceRate)
                .overallEngagementScore(overallEngagementScore)
                .overallRiskScore(overallRiskScore)
                .unitSummaryList(unitSummaryList)
                .build();
    }

    @Override
    public StudentUnitAttendanceDetailDTO getUnitAttendanceDetail(String studentId,
                                                                  String unitSemesterId) {
        log.info("{} getUnitAttendanceDetail - studentId: {} unit: {}",
                logPrefix, studentId, unitSemesterId);

        // fetch unit summary
        StudentUnitSummaryDO unitSummaryDO = studentUnitSummaryRepository
                .getByStudentAndUnitSemesterId(studentId, unitSemesterId);

        // fetch analytics result
        StudentAnalyticsResultDO analyticsResultDO = studentAnalyticsResultRepository
                .getByStudentAndUnit(studentId, unitSemesterId);

        // fetch session summaries for weekly breakdown
        List<StudentSessionSummaryDO> sessionSummaryDOs = studentSessionSummaryRepository
                .getByUnitSemesterId(unitSemesterId)
                .stream()
                .filter(s -> s.getStudentId().equals(studentId))
                .collect(Collectors.toList());

        // build weekly breakdown grouped by week
        Map<String, List<StudentSessionSummaryDO>> byWeek = sessionSummaryDOs.stream()
                .collect(Collectors.groupingBy(s -> extractWeek(s.getSessionId())));

        List<StudentWeeklyAttendanceDTO> weeklyBreakdown = byWeek.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .map(entry -> {
                    List<StudentSessionSummaryDO> weekSessions = entry.getValue();

                    // aggregate across class types (LEC + TUT) for the week
                    boolean present        = weekSessions.stream().anyMatch(StudentSessionSummaryDO::isPresent);
                    boolean lateArrival    = weekSessions.stream().anyMatch(StudentSessionSummaryDO::isLateArrival);
                    boolean earlyDeparture = weekSessions.stream().anyMatch(StudentSessionSummaryDO::isEarlyDeparture);
                    double avgEngagement   = weekSessions.stream()
                            .mapToDouble(StudentSessionSummaryDO::getEngagementScore)
                            .average().orElse(0);
                    double avgPresence     = weekSessions.stream()
                            .mapToDouble(StudentSessionSummaryDO::getPresenceQuality)
                            .average().orElse(0);

                    return StudentWeeklyAttendanceDTO.builder()
                            .week(entry.getKey())
                            .present(present)
                            .lateArrival(lateArrival)
                            .earlyDeparture(earlyDeparture)
                            .engagementScore(avgEngagement)
                            .presenceQuality(avgPresence)
                            .build();
                })
                .collect(Collectors.toList());

        String[] parts = unitSemesterId.split("-");
        String trend = deriveTrend(analyticsResultDO);

        return StudentUnitAttendanceDetailDTO.builder()
                .studentId(studentId)
                .unitSemesterId(unitSemesterId)
                .unitCode(parts[0])
                .attendanceRate(unitSummaryDO != null ? unitSummaryDO.getAttendanceRate() : 0)
                .engagementScore(unitSummaryDO != null ? unitSummaryDO.getAvgEngagementScore() : 0)
                .riskScore(analyticsResultDO != null ? analyticsResultDO.getRiskScore() : 0)
                .clusterLabel(analyticsResultDO != null ? analyticsResultDO.getClusterLabel() : null)
                .consecutiveAbsences(analyticsResultDO != null ? analyticsResultDO.getConsecutiveAbsences() : 0)
                .totalLateArrival(unitSummaryDO != null ? unitSummaryDO.getTotalLateArrival() : 0)
                .totalEarlyDeparture(unitSummaryDO != null ? unitSummaryDO.getTotalEarlyDeparture() : 0)
                .trend(trend)
                .weeklyBreakdown(weeklyBreakdown)
                .build();
    }

    @Override
    public StudentAnalyticsResultDTO getStudentAnalytics(String studentId, String unitSemesterId) {
        log.info("{} getStudentAnalytics - studentId: {} unit: {}",
                logPrefix, studentId, unitSemesterId);

        StudentAnalyticsResultDO resultDO = studentAnalyticsResultRepository
                .getByStudentAndUnit(studentId, unitSemesterId);

        if (resultDO == null) {
            throw new RuntimeException("Analytics result not found for student: "
                    + studentId + " unit: " + unitSemesterId);
        }

        return StudentAnalyticsResultDTO.builder()
                .studentId(resultDO.getStudentId())
                .unitSemesterId(resultDO.getUnitSemesterId())
                .attendanceRate(resultDO.getAttendanceRate())
                .engagementScore(resultDO.getEngagementScore())
                .effectivePresence(resultDO.getEffectivePresence())
                .trendSlope(resultDO.getTrendSlope())
                .consecutiveAbsences(resultDO.getConsecutiveAbsences())
                .riskScore(resultDO.getRiskScore())
                .clusterLabel(resultDO.getClusterLabel())
                .insights(toStudentFriendlyInsights(resultDO.getInsights()))
                .riskBreakdown(resultDO.getRiskBreakdown())
                .explanations(resultDO.getExplanations())
                .build();
    }

    @Override
    public StudentSessionHistoryDTO getSessionHistory(String studentId, String unitSemesterId) {
        log.info("{} getSessionHistory - studentId: {} unit: {}",
                logPrefix, studentId, unitSemesterId);

        List<StudentSessionSummaryDO> sessionSummaryDOs = studentSessionSummaryRepository
                .getByUnitSemesterId(unitSemesterId)
                .stream()
                .filter(s -> s.getStudentId().equals(studentId))
                .collect(Collectors.toList());

        List<StudentSessionRecordDTO> sessions = sessionSummaryDOs.stream()
                .map(s -> {
                    String[] sessionParts = s.getSessionId().split("-");
                    return StudentSessionRecordDTO.builder()
                            .sessionId(s.getSessionId())
                            .week(sessionParts[2])        // e.g. W1
                            .classType(sessionParts[3])   // e.g. LEC
                            .present(s.isPresent())
                            .lateArrival(s.isLateArrival())
                            .earlyDeparture(s.isEarlyDeparture())
                            .engagementScore(s.getEngagementScore())
                            .presenceQuality(s.getPresenceQuality())
                            .build();
                })
                .sorted(Comparator.comparing(StudentSessionRecordDTO::getWeek))
                .collect(Collectors.toList());

        int totalPresent = (int) sessions.stream()
                .filter(StudentSessionRecordDTO::isPresent).count();

        return StudentSessionHistoryDTO.builder()
                .studentId(studentId)
                .unitSemesterId(unitSemesterId)
                .totalSessions(sessions.size())
                .totalPresent(totalPresent)
                .sessions(sessions)
                .build();
    }

    /**
     * Builds a StudentUnitSummaryCardDTO for a student in a unit
     */
    private StudentUnitSummaryCardDTO buildUnitSummaryCard(String studentId, String unitSemesterId) {
        try {
            StudentUnitSummaryDO unitSummaryDO = studentUnitSummaryRepository
                    .getByStudentAndUnitSemesterId(studentId, unitSemesterId);

            StudentAnalyticsResultDO analyticsResultDO = studentAnalyticsResultRepository
                    .getByStudentAndUnit(studentId, unitSemesterId);

            String[] parts = unitSemesterId.split("-");
            String trend = deriveTrend(analyticsResultDO);

            return StudentUnitSummaryCardDTO.builder()
                    .unitSemesterId(unitSemesterId)
                    .unitCode(parts[0])
                    .attendanceRate(unitSummaryDO != null ? unitSummaryDO.getAttendanceRate() : 0)
                    .engagementScore(unitSummaryDO != null ? unitSummaryDO.getAvgEngagementScore() : 0)
                    .riskScore(analyticsResultDO != null ? analyticsResultDO.getRiskScore() : 0)
                    .clusterLabel(analyticsResultDO != null ? analyticsResultDO.getClusterLabel() : null)
                    .totalLateArrival(unitSummaryDO != null ? unitSummaryDO.getTotalLateArrival() : 0)
                    .totalEarlyDeparture(unitSummaryDO != null ? unitSummaryDO.getTotalEarlyDeparture() : 0)
                    .consecutiveAbsences(analyticsResultDO != null ? analyticsResultDO.getConsecutiveAbsences() : 0)
                    .trend(trend)
                    .build();
        } catch (Exception e) {
            log.error("{} failed to build unit summary card - studentId: {} unit: {}",
                    logPrefix, studentId, unitSemesterId, e);
            return null;
        }
    }

    /**
     * Derives attendance trend from trend slope
     * Positive slope = IMPROVING, Negative slope = DECLINING, else STABLE
     */
    private String deriveTrend(StudentAnalyticsResultDO analyticsResultDO) {
        if (analyticsResultDO == null) return "STABLE";
        double slope = analyticsResultDO.getTrendSlope();
        if (slope > 0.05) return "IMPROVING";
        if (slope < -0.05) return "DECLINING";
        return "STABLE";
    }

    /**
     * Extracts week from sessionId
     * e.g. FIT3077-2025S1-W1-LEC -> W1
     */
    private String extractWeek(String sessionId) {
        String[] parts = sessionId.split("-");
        return parts[2]; // W1, W2 etc
    }

    /**
     * Gets unit name from unit code
     * e.g. FIT3077 -> Software Architecture
     */
    private String getUnitName(String unitCode) {
        try {
            UnitDO unit = unitRepository.getUnitByUnitCode(unitCode);
            AssertUtil.assertNotNull(unit);
            return unit.getUnitName();
        } catch (Exception e) {
            log.warn("{} failed to get unit name for: {}", logPrefix, unitCode);
            return unitCode;
        }
    }

    /**
     * Converts lecturer-facing insights to student-friendly language
     * e.g. "High risk student - intervention recommended"
     *      -> "Your attendance needs improvement"
     */
    private List<String> toStudentFriendlyInsights(List<String> insights) {
        if (insights == null) return new ArrayList<>();

        return insights.stream()
                .map(insight -> switch (insight) {
                    case "Low attendance across sessions"
                            -> "Your attendance has been below the recommended level";
                    case "Attendance trend declining"
                            -> "Your attendance has been declining over recent weeks";
                    case "Repeated absence pattern"
                            -> "You have had several consecutive absences recently";
                    case "Low classroom interaction detected"
                            -> "Your classroom participation could be improved";
                    case "Short participation duration in sessions"
                            -> "You have been leaving sessions earlier than expected";
                    case "High risk student - intervention recommended"
                            -> "Your overall attendance and engagement needs improvement";
                    default -> insight;
                })
                .collect(Collectors.toList());
    }
}

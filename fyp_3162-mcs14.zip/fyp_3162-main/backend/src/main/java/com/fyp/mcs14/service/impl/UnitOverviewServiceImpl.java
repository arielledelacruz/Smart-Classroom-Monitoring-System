package com.fyp.mcs14.service.impl;

import com.fyp.mcs14.common.AssertUtil;
import com.fyp.mcs14.model.dataobject.StudentAnalyticsResultDO;
import com.fyp.mcs14.model.dataobject.StudentSessionSummaryDO;
import com.fyp.mcs14.model.dataobject.UnitAnalyticsSummaryDO;
import com.fyp.mcs14.model.dataobject.UnitWeeklyAttendanceSummaryDO;
import com.fyp.mcs14.model.dto.CategorizedInsightDTO;
import com.fyp.mcs14.model.dto.UnitKpiDTO;
import com.fyp.mcs14.model.dto.UnitOverviewResponseDTO;
import com.fyp.mcs14.model.dto.UnitRiskDistributionDTO;
import com.fyp.mcs14.model.dto.UnitWeeklyDataDTO;
import com.fyp.mcs14.model.enums.InsightCategory;
import com.fyp.mcs14.model.enums.WeekEnum;
import com.fyp.mcs14.repository.StudentAnalyticsResultRepository;
import com.fyp.mcs14.repository.StudentSessionSummaryRepository;
import com.fyp.mcs14.repository.UnitAnalyticsSummaryRepository;
import com.fyp.mcs14.repository.UnitWeeklyAttendanceSummaryRepository;
import com.fyp.mcs14.service.UnitOverviewService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class UnitOverviewServiceImpl implements UnitOverviewService {

    @Autowired
    private UnitWeeklyAttendanceSummaryRepository weeklyAttendanceSummaryRepository;

    @Autowired
    private StudentAnalyticsResultRepository studentAnalyticsResultRepository;

    @Autowired
    private UnitAnalyticsSummaryRepository unitAnalyticsSummaryRepository;

    @Autowired
    private StudentSessionSummaryRepository studentSessionSummaryRepository;

    @Override
    public UnitOverviewResponseDTO getUnitOverview(String unitSemesterId, WeekEnum weekStart, WeekEnum weekEnd) {
        log.info("getUnitOverview started - unit: {}", unitSemesterId);

        UnitAnalyticsSummaryDO unitAnalytics = unitAnalyticsSummaryRepository
                .getByUnitSemesterId(unitSemesterId);

        List<StudentAnalyticsResultDO> analyticsResultDOs = studentAnalyticsResultRepository
                .getByUnitSemesterId(unitSemesterId);

        List<UnitWeeklyDataDTO> weeklyData = buildWeeklyData(unitSemesterId, weekStart, weekEnd);

        UnitRiskDistributionDTO riskDistribution = buildRiskDistribution(
                unitSemesterId, weekStart, weekEnd);
        AssertUtil.assertNotNull(unitAnalytics);
        UnitKpiDTO kpi = buildKpi(
                unitSemesterId, weeklyData, analyticsResultDOs, unitAnalytics, weekStart, weekEnd);


        String[] parts = unitSemesterId.split("-");

        log.info("getUnitOverview completed - unit: {}", unitSemesterId);

        return UnitOverviewResponseDTO.builder()
                .unitSemesterId(unitSemesterId)
                .unitCode(parts[0])
                .year(parts[1])
                .semester(parts[2])
                .kpi(kpi)
                .weeklyData(weeklyData)
                .clusterDistribution(unitAnalytics.getClusterDistribution())
                .riskDistribution(riskDistribution)
                .analyticalExplanations(buildAnalyticalExplanations(kpi, riskDistribution, weeklyData))
                .recommendations(buildRecommendations(kpi, riskDistribution, weeklyData))
                .build();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Weekly data
    // ─────────────────────────────────────────────────────────────────────────

    private List<UnitWeeklyDataDTO> buildWeeklyData(String unitSemesterId, WeekEnum weekStart, WeekEnum weekEnd) {
        return Arrays.stream(WeekEnum.values())
                .filter(week ->
                        week.ordinal() >= weekStart.ordinal() &&
                                week.ordinal() <= weekEnd.ordinal())
                .map(week -> {
                    String sessionId = unitSemesterId + "-" + week.getWeekCodeString();

                    UnitWeeklyAttendanceSummaryDO summaryDO = weeklyAttendanceSummaryRepository
                            .getUnitWeeklyAttendanceSummaryById(sessionId);

                    if (summaryDO == null) return null;

                    // fetch once, reuse for both engagement and risk
                    List<StudentSessionSummaryDO> sessions = studentSessionSummaryRepository
                            .getBySessionId(sessionId);

                    int total = summaryDO.getTotalAttendance() + summaryDO.getTotalAbsence();
                    double attendanceRate = total == 0 ? 0 :
                            (double) summaryDO.getTotalAttendance() / total;

                    double avgEngagement = sessions.stream()
                            .filter(StudentSessionSummaryDO::isPresent)
                            .mapToDouble(StudentSessionSummaryDO::getEngagementScore)
                            .filter(Double::isFinite)
                            .average()
                            .orElse(0);

                    // group by student, compute comprehensive risk per student, then average
                    double avgRiskScore = sessions.stream()
                            .collect(Collectors.groupingBy(StudentSessionSummaryDO::getStudentId))
                            .values().stream()
                            .mapToDouble(studentSessions ->
                                    computeComprehensiveRisk(studentSessions, weekStart, weekEnd))
                            .filter(Double::isFinite)
                            .average()
                            .orElse(0);

                    return UnitWeeklyDataDTO.builder()
                            .week(week.getWeekCodeString())
                            .totalAttendance(summaryDO.getTotalAttendance())
                            .totalAbsence(summaryDO.getTotalAbsence())
                            .totalLateArrival(summaryDO.getTotalLateArrival())
                            .totalEarlyDeparture(summaryDO.getTotalEarlyDeparture())
                            .attendanceRate(attendanceRate)
                            .avgEngagementScore(avgEngagement)
                            .avgRiskScore(avgRiskScore)
                            .build();
                })
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Risk distribution
    // ─────────────────────────────────────────────────────────────────────────
    private UnitRiskDistributionDTO buildRiskDistribution(
            String unitSemesterId,
            WeekEnum weekStart,
            WeekEnum weekEnd) {

        List<Double> riskScores = computeRiskScoresPerStudent(unitSemesterId, weekStart, weekEnd);

        int total      = riskScores.size();
        int lowRisk    = (int) riskScores.stream().filter(r -> r < 0.4).count();
        int mediumRisk = (int) riskScores.stream().filter(r -> r >= 0.4 && r < 0.7).count();
        int highRisk   = (int) riskScores.stream().filter(r -> r >= 0.7).count();

        return UnitRiskDistributionDTO.builder()
                .lowRiskCount(lowRisk)
                .mediumRiskCount(mediumRisk)
                .highRiskCount(highRisk)
                .lowRiskRate(total == 0 ? 0 : (double) lowRisk / total)
                .mediumRiskRate(total == 0 ? 0 : (double) mediumRisk / total)
                .highRiskRate(total == 0 ? 0 : (double) highRisk / total)
                .build();
    }

    private UnitKpiDTO buildKpi(
            String unitSemesterId,
            List<UnitWeeklyDataDTO> weeklyData,
            List<StudentAnalyticsResultDO> analyticsResultDOs,
            UnitAnalyticsSummaryDO unitAnalytics,
            WeekEnum weekStart,
            WeekEnum weekEnd) {

        int totalStudents       = unitAnalytics != null ? unitAnalytics.getTotalStudents() : 0;
        int totalAttendance     = weeklyData.stream().mapToInt(UnitWeeklyDataDTO::getTotalAttendance).sum();
        int totalAbsence        = weeklyData.stream().mapToInt(UnitWeeklyDataDTO::getTotalAbsence).sum();
        int totalLateArrival    = weeklyData.stream().mapToInt(UnitWeeklyDataDTO::getTotalLateArrival).sum();
        int totalEarlyDeparture = weeklyData.stream().mapToInt(UnitWeeklyDataDTO::getTotalEarlyDeparture).sum();

        double avgAttendanceRate = (totalAttendance + totalAbsence) == 0 ? 0
                : (double) totalAttendance / (totalAttendance + totalAbsence);

        double avgEngagementScore = weeklyData.stream()
                .mapToDouble(UnitWeeklyDataDTO::getAvgEngagementScore)
                .average()
                .orElse(0);

        List<Double> riskScores = computeRiskScoresPerStudent(unitSemesterId, weekStart, weekEnd);

        double avgRiskScore = riskScores.stream()
                .mapToDouble(Double::doubleValue)
                .average()
                .orElse(0);

        int highRiskCount = (int) riskScores.stream().filter(r -> r >= 0.7).count();

        return UnitKpiDTO.builder()
                .totalStudents(totalStudents)
                .avgAttendanceRate(avgAttendanceRate)
                .avgEngagementScore(avgEngagementScore)
                .avgRiskScore(avgRiskScore)
                .highRiskCount(highRiskCount)
                .totalLateArrival(totalLateArrival)
                .totalEarlyDeparture(totalEarlyDeparture)
                .build();
    }

// ─────────────────────────────────────────────────────────────────────────
// Core: compute one risk score per student for the given week range
// Uses the same factors as StudentInsightExplanationEngine:
// attendance, engagement, presence, trend, consecutive absences
// ─────────────────────────────────────────────────────────────────────────

    private List<Double> computeRiskScoresPerStudent(
            String unitSemesterId,
            WeekEnum weekStart,
            WeekEnum weekEnd) {

        // Collect all sessions in the week range, grouped by student
        List<StudentSessionSummaryDO> selectedSessions = Arrays.stream(WeekEnum.values())
                .filter(w -> w.ordinal() >= weekStart.ordinal()
                        && w.ordinal() <= weekEnd.ordinal())
                .flatMap(w -> {
                    String sessionId = unitSemesterId + "-" + w.getWeekCodeString();
                    return studentSessionSummaryRepository.getBySessionId(sessionId).stream();
                })
                .collect(Collectors.toList());

        Map<String, List<StudentSessionSummaryDO>> byStudent = selectedSessions.stream()
                .collect(Collectors.groupingBy(StudentSessionSummaryDO::getStudentId));

        return byStudent.values().stream()
                .map(sessions -> computeComprehensiveRisk(sessions, weekStart, weekEnd))
                .filter(Double::isFinite)
                .collect(Collectors.toList());
    }
    private double computeComprehensiveRisk(List<StudentSessionSummaryDO> sessions, WeekEnum weekStart, WeekEnum weekEnd) {

        if (sessions == null || sessions.isEmpty()) return 0;

        List<StudentSessionSummaryDO> sortedSessions = sessions.stream()
                .filter(s -> {
                    WeekEnum w = extractWeekFromSessionId(s.getSessionId());
                    return w != null
                            && w.ordinal() >= weekStart.ordinal()
                            && w.ordinal() <= weekEnd.ordinal();
                })
                .sorted(Comparator.comparingInt(s -> {
                    WeekEnum w = extractWeekFromSessionId(s.getSessionId());
                    return w != null ? w.ordinal() : 0;
                }))
                .collect(Collectors.toList());

        // ── Attendance rate ────────────────────────────────────────────────
        long presentCount = sortedSessions.stream()
                .filter(StudentSessionSummaryDO::isPresent)
                .count();
        double attendanceRate = (double) presentCount / sortedSessions.size();

        // ── Engagement (present sessions only) ────────────────────────────
        double avgEngagement = sortedSessions.stream()
                .filter(StudentSessionSummaryDO::isPresent)
                .mapToDouble(StudentSessionSummaryDO::getEngagementScore)
                .filter(Double::isFinite)
                .average()
                .orElse(0);

        // ── Presence quality (present sessions only) ──────────────────────
        double avgPresence = sortedSessions.stream()
                .filter(StudentSessionSummaryDO::isPresent)
                .mapToDouble(StudentSessionSummaryDO::getPresenceQuality)
                .filter(Double::isFinite)
                .average()
                .orElse(0);

        // ── Trend slope (linear regression over attendance 0/1 per week) ──
        int n = sortedSessions.size();
        double slope = 0;
        if (n > 1) {
            double sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
            for (int i = 0; i < n; i++) {
                double x = i;
                double y = sortedSessions.get(i).isPresent() ? 1.0 : 0.0;
                sumX  += x;
                sumY  += y;
                sumXY += x * y;
                sumX2 += x * x;
            }
            double denom = n * sumX2 - sumX * sumX;
            slope = denom == 0 ? 0 : (n * sumXY - sumX * sumY) / denom;
        }

        // ── Consecutive absences ───────────────────────────────────────────
        int maxConsecutive = 0;
        int current = 0;
        for (StudentSessionSummaryDO s : sortedSessions) {
            if (!s.isPresent()) {
                current++;
                maxConsecutive = Math.max(maxConsecutive, current);
            } else {
                current = 0;
            }
        }

        // ── Late arrival / early departure penalty ─────────────────────────
        long lateOrEarlyCount = sortedSessions.stream()
                .filter(s -> s.isLateArrival() || s.isEarlyDeparture())
                .count();
        double attendanceQualityRisk = n == 0 ? 0 : (double) lateOrEarlyCount / n;

        // ── Risk formula ───────────────────────────────────────────────────
        double attendanceRisk      = 1 - attendanceRate;
        double engagementRisk      = 1 - avgEngagement;
        double presenceRisk        = 1 - avgPresence;
        double trendRisk           = slope < -0.05 ? 0.8 : (slope > 0.05 ? 0.2 : 0.5);
        double consecutiveRisk     = Math.min((double) maxConsecutive / 3.0, 1.0);

        return (attendanceRisk       * 0.30)
                + (engagementRisk       * 0.25)
                + (presenceRisk         * 0.15)
                + (trendRisk            * 0.15)
                + (consecutiveRisk      * 0.10)
                + (attendanceQualityRisk * 0.05);
    }

    private WeekEnum extractWeekFromSessionId(String sessionId) {
        if (sessionId == null) return null;
        String[] parts = sessionId.split("-");
        for (String part : parts) {
            WeekEnum week = WeekEnum.fromCode(part);
            if (week != null) return week;
        }
        return null;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Analytical explanations  (tagged by InsightCategory)
    // ─────────────────────────────────────────────────────────────────────────

    private List<CategorizedInsightDTO> buildAnalyticalExplanations(
            UnitKpiDTO kpi,
            UnitRiskDistributionDTO riskDistribution,
            List<UnitWeeklyDataDTO> weeklyData
    ) {
        List<CategorizedInsightDTO> explanations = new ArrayList<>();

        // ATTENDANCE
        explanations.add(CategorizedInsightDTO.builder()
                .category(InsightCategory.ATTENDANCE)
                .message(String.format(
                        "Average attendance is %.1f%%. Calculated from total present records divided by total attendance records, including absences.",
                        kpi.getAvgAttendanceRate() * 100))
                .build());

        // ENGAGEMENT
        explanations.add(CategorizedInsightDTO.builder()
                .category(InsightCategory.ENGAGEMENT)
                .message(String.format(
                        "Average engagement is %.1f%%. Derived from present students' engagement scores across the selected weeks.",
                        kpi.getAvgEngagementScore() * 100))
                .build());

        // RISK
        explanations.add(CategorizedInsightDTO.builder()
                .category(InsightCategory.RISK)
                .message(String.format(
                        "Average risk score is %.1f%%. Mainly contributed by absence risk and low engagement risk.",
                        kpi.getAvgRiskScore() * 100))
                .build());

        // RISK — high-risk headcount
        explanations.add(CategorizedInsightDTO.builder()
                .category(InsightCategory.RISK)
                .message(String.format(
                        "%d student(s) are currently high risk. High risk means their calculated risk score is at least 70%%.",
                        kpi.getHighRiskCount()))
                .build());

        // RISK — risk distribution breakdown
        if (riskDistribution != null) {
            explanations.add(CategorizedInsightDTO.builder()
                    .category(InsightCategory.RISK)
                    .message(String.format(
                            "Risk distribution: %.1f%% low risk, %.1f%% medium risk, %.1f%% high risk.",
                            riskDistribution.getLowRiskRate() * 100,
                            riskDistribution.getMediumRiskRate() * 100,
                            riskDistribution.getHighRiskRate() * 100))
                    .build());
        }

        // ATTENDANCE_QUALITY — late arrivals and early departures
        explanations.add(CategorizedInsightDTO.builder()
                .category(InsightCategory.ATTENDANCE_QUALITY)
                .message(String.format(
                        "Late arrivals total %d and early departures total %d. These contribute to weaker attendance quality even when students are marked present.",
                        kpi.getTotalLateArrival(),
                        kpi.getTotalEarlyDeparture()))
                .build());

        return explanations;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Recommendations  (tagged by InsightCategory)
    // ─────────────────────────────────────────────────────────────────────────

    private List<CategorizedInsightDTO> buildRecommendations(
            UnitKpiDTO kpi,
            UnitRiskDistributionDTO riskDistribution,
            List<UnitWeeklyDataDTO> weeklyData
    ) {
        List<CategorizedInsightDTO> recommendations = new ArrayList<>();

        // ATTENDANCE
        if (kpi.getAvgAttendanceRate() < 0.75) {
            recommendations.add(CategorizedInsightDTO.builder()
                    .category(InsightCategory.ATTENDANCE)
                    .message("Attendance is below the expected level. Consider sending reminders, checking timetable conflicts, and following up with repeatedly absent students.")
                    .build());
        }

        // ENGAGEMENT
        if (kpi.getAvgEngagementScore() < 0.6) {
            recommendations.add(CategorizedInsightDTO.builder()
                    .category(InsightCategory.ENGAGEMENT)
                    .message("Engagement is low. Consider adding more interactive activities, short quizzes, or participation checkpoints during sessions.")
                    .build());
        }

        // RISK — high-risk students
        if (kpi.getHighRiskCount() > 0) {
            recommendations.add(CategorizedInsightDTO.builder()
                    .category(InsightCategory.RISK)
                    .message("There are high-risk students. Prioritise early intervention by contacting these students and reviewing their recent attendance patterns.")
                    .build());
        }

        // ATTENDANCE_QUALITY — late arrivals
        if (kpi.getTotalLateArrival() > 0) {
            recommendations.add(CategorizedInsightDTO.builder()
                    .category(InsightCategory.ATTENDANCE_QUALITY)
                    .message("Late arrivals are present. Review whether session timing, room location, or first-hour activities are affecting punctuality.")
                    .build());
        }

        // ATTENDANCE_QUALITY — early departures
        if (kpi.getTotalEarlyDeparture() > 0) {
            recommendations.add(CategorizedInsightDTO.builder()
                    .category(InsightCategory.ATTENDANCE_QUALITY)
                    .message("Early departures are present. Consider checking whether students are disengaging near the end of class or leaving due to timetable clashes.")
                    .build());
        }

        // Fallback — all good
        if (recommendations.isEmpty()) {
            recommendations.add(CategorizedInsightDTO.builder()
                    .category(InsightCategory.ATTENDANCE)
                    .message("This unit is performing well overall. Continue monitoring attendance, engagement, and risk trends weekly.")
                    .build());
        }

        return recommendations;
    }
}
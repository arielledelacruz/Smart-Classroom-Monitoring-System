package com.fyp.mcs14.service.impl;

import com.fyp.mcs14.model.converter.UnitConverter;
import com.fyp.mcs14.model.converter.UnitSemesterDataConverter;
import com.fyp.mcs14.model.model.UnitSemesterData;
import com.fyp.mcs14.model.model.attendance.UnitYearSemesterId;
import com.fyp.mcs14.repository.UnitRepository;
import com.fyp.mcs14.repository.UnitSemesterDataRepository;
import com.fyp.mcs14.service.UnitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Service implementation to handle unit related operations
 */
@Service
public class UnitServiceImpl implements UnitService {

    @Autowired
    private UnitRepository unitRepository;

    @Autowired
    private UnitSemesterDataRepository unitSemesterDataRepository;

    @Override
    public List<String> getAllUnitCodes() {
        return UnitConverter.convertDOList2ModelList(unitRepository.getAllUnits())
                .stream()
                .map(unit -> unit.getUnitCode().name())
                .collect(Collectors.toList());
    }

    @Override
    public UnitSemesterData getUnitSemesterData(String id) {
        return UnitSemesterDataConverter.convertDO2Model(unitSemesterDataRepository.getById(id));
    }


}

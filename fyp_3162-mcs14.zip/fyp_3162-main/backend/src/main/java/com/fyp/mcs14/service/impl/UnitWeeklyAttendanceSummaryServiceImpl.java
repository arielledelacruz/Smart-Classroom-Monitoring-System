package com.fyp.mcs14.service.impl;

import com.fyp.mcs14.model.model.attendance.SessionId;
import com.fyp.mcs14.model.model.attendance.UnitWeeklyAttendanceSummary;
import com.fyp.mcs14.model.model.attendance.UnitYearSemesterWeekId;
import com.fyp.mcs14.model.model.excel.MotionRecord;
import com.fyp.mcs14.model.model.excel.RawAttendanceRecord;
import com.fyp.mcs14.service.UnitWeeklyAttendanceSummaryService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UnitWeeklyAttendanceSummaryServiceImpl implements UnitWeeklyAttendanceSummaryService {

    @Override
    public UnitWeeklyAttendanceSummary calculateWeeklySummary(List<RawAttendanceRecord> records) {
        int totalAttendance = 0;
        int totalAbsence = 0;
        int totalEarlyDeparture = 0;
        int totalLateArrival = 0;

        for (RawAttendanceRecord record : records) {
            boolean hasMotion = !record.getRecords().isEmpty();
            boolean isLateArrival = checkLateArrival(record.getRecords());
            boolean isEarlyDeparture = checkEarlyDeparture(record.getRecords());

            if (!hasMotion) {
                totalAbsence++;
            } else {
                totalAttendance++;
                if (isLateArrival) totalLateArrival++;
                if (isEarlyDeparture) totalEarlyDeparture++;
            }
        }

        SessionId sessionId = records.get(0).getSessionId();

        UnitYearSemesterWeekId id = UnitYearSemesterWeekId.builder()
                .unitCode(sessionId.getUnitCode())
                .year(Integer.parseInt(sessionId.getYear()))
                .semester(sessionId.getSemester())
                .week(sessionId.getWeek())
                .build();

        return UnitWeeklyAttendanceSummary.builder()
                .id(id)
                .week(sessionId.getWeek())
                .totalAttendance(totalAttendance)
                .totalAbsence(totalAbsence)
                .totalEarlyDeparture(totalEarlyDeparture)
                .totalLateArrival(totalLateArrival)
                .build();
    }

    private boolean checkLateArrival(List<MotionRecord> records) {
        // implement your late arrival logic here based on motion records
        return false;
    }

    private boolean checkEarlyDeparture(List<MotionRecord> records) {
        // implement your early departure logic here based on motion records
        return false;
    }
}

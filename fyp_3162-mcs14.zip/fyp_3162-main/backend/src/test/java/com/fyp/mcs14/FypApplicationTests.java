package com.fyp.mcs14;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FypApplicationTests {

    @Test
    void contextLoads() {
    }

}

import { useEffect } from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import { useAuth } from "./api/context/AuthContext";

import Layout from "./components/layout/Layout";
import Login from "./pages/Login";
import Dashboard from "./pages/LecturerDashboard";
import LecturerProfile from "./pages/LecturerProfile";
import StudentProfile from "./pages/StudentProfile";
import StudentInterface from "./pages/StudentInterface";
import Settings from "./pages/Settings";
import StudentReportList from "./pages/LecturerViewStudentReportList";
import LecturerViewStudentReport from "./pages/LecturerViewStudentReport";
import AdminUpload from "./pages/AdminUpload";

/* ---------------- Protected Route ---------------- */
const PrivateRoute = ({ children }) => {
    const { authUser } = useAuth();
    return authUser ? children : <Navigate to="/login" replace />;
};


const LecturerRoute = ({ children }) => {
    const { authUser } = useAuth();
    return authUser?.userRole === "LECTURER"
        ? children
        : <Navigate to={authUser?.userRole === "STUDENT" ? "/studentDashboard" : "/login"} replace />;
};

const StudentRoute = ({ children }) => {
    const { authUser } = useAuth();
    return authUser?.userRole === "STUDENT"
        ? children
        : <Navigate to={authUser?.userRole === "LECTURER" ? "/lecturerDashboard" : "/login"} replace />;
};

/* ---------------- App ---------------- */
function App() {
    const { authUser } = useAuth();

    // Apply saved dark mode theme on mount
    useEffect(() => {
        const savedTheme = localStorage.getItem("theme");
        if (savedTheme === "dark") {
            document.documentElement.classList.add("dark");
        }
    }, []);

    return (
        <Routes>
            {/* Public routes */}
            <Route
                path="/"
                element={
                    authUser ? (
                        authUser.userRole === "STUDENT" ? (
                            <Navigate to="/studentDashboard" replace />
                        ) : (
                            <Navigate to="/lecturerDashboard" replace />
                        )
                    ) : (
                        <Navigate to="/login" replace />
                    )
                }
            />
            <Route path="/login" element={<Login />} />

            {/* Protected routes with Layout */}
            <Route
                element={
                    <PrivateRoute>
                        <Layout />
                    </PrivateRoute>
                }
            >
                {/* Lecturer routes */}
                <Route
                    path="/lecturerDashboard"
                    element={
                        <LecturerRoute>
                            <Dashboard />
                        </LecturerRoute>
                    }
                />
                <Route
                    path="/studentList"
                    element={
                        <LecturerRoute>
                            <StudentReportList />
                        </LecturerRoute>
                    }
                />
                <Route
                    path="/lecturerViewStudentReport"
                    element={
                        <LecturerRoute>
                            <LecturerViewStudentReport />
                        </LecturerRoute>
                    }
                />
                <Route
                    path="/adminUpload"
                    element={
                        <LecturerRoute>
                            <AdminUpload />
                        </LecturerRoute>
                    }
                />
                <Route
                    path="/lecturerProfile"
                    element={
                        <LecturerRoute>
                            <LecturerProfile />
                        </LecturerRoute>
                    }
                />

                {/* Student routes */}
                <Route
                    path="/studentDashboard"
                    element={
                        <StudentRoute>
                            <StudentInterface />
                        </StudentRoute>
                    }
                />
                <Route
                    path="/studentProfile"
                    element={
                        <StudentRoute>
                            <StudentProfile />
                        </StudentRoute>
                    }
                />

                {/* Shared route */}
                <Route path="/settings" element={<Settings />} />
            </Route>
        </Routes>
    );
}

export default App;

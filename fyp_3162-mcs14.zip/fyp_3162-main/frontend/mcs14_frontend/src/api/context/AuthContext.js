import { createContext, useContext, useEffect, useState } from "react";

const AuthContext = createContext({
    authUser: null,
    login: () => {},
    logout: () => {},
    dashboardState: null,
    setDashboardState: () => {},
    studentState: null,
    setStudentState: () => {},
});

export const AuthProvider = ({ children }) => {
    const [authUser, setAuthUser] = useState(null);
    const [dashboardState, setDashboardState] = useState(null);
    const [studentState, setStudentState] = useState(null);

    useEffect(() => {
        try {
            const savedUser = localStorage.getItem("authUser");
            if (savedUser) {
                setAuthUser(JSON.parse(savedUser));
            }
        } catch (err) {
            console.error("Failed to restore auth user from localStorage", err);
        }
    }, []);

    const login = (userData) => {
        setAuthUser(userData);
        localStorage.setItem("authUser", JSON.stringify(userData));
    };

    const logout = () => {
        setAuthUser(null);
        setDashboardState(null);
        setStudentState(null);
        localStorage.removeItem("authUser");
    };

    return (
        <AuthContext.Provider value={{ authUser, login, logout, dashboardState, setDashboardState, studentState, setStudentState }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => useContext(AuthContext);
import { ApiUrls } from "../../constants/apiUrl";

/**
 * Validates user login credentials against the backend
 * @param {string} email
 * @param {string} password
 * @returns {Promise<Object>} response body containing AuthUserDTO on success
 */
export const validateLogin = async (email, password) => {
    const response = await fetch(ApiUrls.VALIDATE_LOGIN, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
    });
    console.log(ApiUrls.VALIDATE_LOGIN)
    return response.json();
};
import { ApiUrls } from "../../constants/apiUrl";

/**
 * Fetches all available unit codes for the filter dropdown
 * @returns {Promise<string[]>} list of unit codes
 */
export const queryAllUnitCodes = async () => {
    const response = await fetch(ApiUrls.QUERY_ALL_UNIT_CODE);
    const data = await response.json();
    return data?.responseBody || [];
};

/**
 * Fetches filtered dashboard data based on selected units and date range
 * @param {Object} filters
 * @param {string[]} filters.unitCodeList
 * @param {number} filters.weekStart
 * @param {number} filters.weekEnd
 * @param {string} filters.year
 * @param {string} filters.semester
 * @returns {Promise<Object>} dashboard summary data
 */
export const queryFilterData = async ({ unitCodeList, weekStart, weekEnd, year, semester }) => {
    const response = await fetch(ApiUrls.QUERY_FILTER_DATA, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ unitCodeList, weekStart, weekEnd, year, semester }),
    });
    const data = await response.json();
    return data?.responseBody || null;
};


export const queryFilterStudentData = async ({ unitCode, year, semester }) => {
    const response = await fetch(ApiUrls.QUERY_STUDENT_LIST, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ unitCode, year, semester }),
    });
    const data = await response.json();
    return data?.responseBody || null;
};
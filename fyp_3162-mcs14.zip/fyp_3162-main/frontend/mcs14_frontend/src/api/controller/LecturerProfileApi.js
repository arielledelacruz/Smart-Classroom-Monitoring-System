import { ApiUrls } from "../../constants/apiUrl";

export const uploadProfilePhoto = async (lecturerId, file) => {
    try {
        const formData = new FormData();
        formData.append("lecturerId", lecturerId);
        formData.append("file", file);

        const response = await fetch(ApiUrls.UPLOAD_LECTURER_PROFILE_PHOTO, {
            method: "POST",
            body: formData,
        });

        const data = await response.json();

        if (data.responseStatus === "SUCCESS") {
            alert("Photo uploaded successfully");
        } else {
            alert("Photo upload failed");
        }

    } catch (error) {
        console.error(error);
        alert("Photo upload error");
    }
};
import { ApiUrls } from "../../constants/apiUrl";

export const getEnrolledUnits = async (studentId, year, semester) => {
    const res = await fetch(ApiUrls.QUERY_STUDENT_ENROLLED_UNITS, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ studentId, year, semester })
    });
    const data = await res.json();
    return data.responseBody;
};

export const getAttendanceSummary = async (studentId, year, semester) => {
    const res = await fetch(ApiUrls.QUERY_STUDENT_ATTENDANCE_SUMMARY, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ studentId, year, semester })
    });
    const data = await res.json();
    return data.responseBody;
};

export const getUnitAttendanceDetail = async (studentId, unitCode, year, semester) => {
    const res = await fetch(ApiUrls.QUERY_UNIT_ATTENDANCE_DETAIL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ studentId, unitCode, year, semester })
    });
    const data = await res.json();
    return data.responseBody;
};

export const getSessionHistory = async (studentId, unitCode, year, semester) => {
    const res = await fetch(ApiUrls.QUERY_SESSION_HISTORY, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ studentId, unitCode, year, semester })
    });
    const data = await res.json();
    return data.responseBody;
};

export const getStudentAnalytics = async (studentId, unitCode, year, semester) => {
    const res = await fetch(ApiUrls.QUERY_STUDENT_ANALYTICS, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ studentId, unitCode, year, semester })
    });
    const data = await res.json();
    return data.responseBody;
};

import { ApiUrls } from "../../constants/apiUrl";

/**
 * Save student feedback (create or update)
 * @param {Object} feedback - feedback object
 * @param {string} feedback.studentId
 * @param {string} feedback.lecturerId
 * @param {string} feedback.unitCode
 * @param {string} feedback.feedbackContent
 * @param {string} feedback.feedbackType - ATTENDANCE, ENGAGEMENT, PERFORMANCE, GENERAL
 * @returns {Promise<Object>}
 */
export const saveFeedback = async (feedback) => {
    const response = await fetch(ApiUrls.SAVE_STUDENT_FEEDBACK, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(feedback),
    });
    const data = await response.json();
    return data?.responseStatus === "SUCCESS";
};

/**
 * Get feedback by feedback ID
 * @param {string} feedbackId
 * @returns {Promise<Object>} feedback object
 */
export const getFeedbackById = async (feedbackId) => {
    const response = await fetch(`${ApiUrls.GET_FEEDBACK_BY_ID}/${feedbackId}`);
    const data = await response.json();
    return data?.responseBody || null;
};

/**
 * Get feedback for a specific student in a specific unit
 * @param {string} studentId
 * @param {string} unitCode
 * @returns {Promise<Array>} list of feedback objects
 */
export const getFeedbackByStudentAndUnit = async (studentId, unitCode) => {
    const response = await fetch(
        `${ApiUrls.GET_FEEDBACK_BY_STUDENT_UNIT}/${studentId}/${unitCode}`
    );
    const data = await response.json();
    return data?.responseBody || [];
};

/**
 * Get all feedback for a specific student
 * @param {string} studentId
 * @returns {Promise<Array>} list of feedback objects
 */
export const getFeedbackByStudent = async (studentId) => {
    const response = await fetch(`${ApiUrls.GET_FEEDBACK_BY_STUDENT}/${studentId}`);
    const data = await response.json();
    return data?.responseBody || [];
};

/**
 * Get all feedback for a specific unit
 * @param {string} unitCode
 * @returns {Promise<Array>} list of feedback objects
 */
export const getFeedbackByUnit = async (unitCode) => {
    const response = await fetch(`${ApiUrls.GET_FEEDBACK_BY_UNIT}/${unitCode}`);
    const data = await response.json();
    return data?.responseBody || [];
};

/**
 * Get all feedback for a lecturer in a specific unit
 * @param {string} lecturerId
 * @param {string} unitCode
 * @returns {Promise<Array>} list of feedback objects
 */
export const getFeedbackByLecturerAndUnit = async (lecturerId, unitCode) => {
    const response = await fetch(
        `${ApiUrls.GET_FEEDBACK_BY_LECTURER_UNIT}/${lecturerId}/${unitCode}`
    );
    const data = await response.json();
    return data?.responseBody || [];
};

/**
 * Delete feedback
 * @param {string} feedbackId
 * @returns {Promise<boolean>}
 */
export const deleteFeedback = async (feedbackId) => {
    const response = await fetch(`${ApiUrls.DELETE_FEEDBACK}/${feedbackId}`, {
        method: "DELETE",
    });
    const data = await response.json();
    return data?.responseStatus === "SUCCESS";
};

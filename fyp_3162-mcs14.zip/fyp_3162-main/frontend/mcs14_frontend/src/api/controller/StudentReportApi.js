import { ApiUrls } from "../../constants/apiUrl";

export const fetchAllUnitCodesForStudentReport = async () => {
    const response = await fetch(ApiUrls.QUERY_ALL_UNIT_CODE, {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
        },
    });

    const data = await response.json();
    console.log("unit code response:", data);

    return data?.responseBody || data?.data || [];
};

export const fetchStudentsByUnitSemester = async ({ unitCode, year, semester }) => {
    const response = await fetch(ApiUrls.QUERY_STUDENT_LIST, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            unitCode,
            year: Number(year),
            semester,
        }),
    });

    const data = await response.json();
    console.log("student list response:", data);

    return data?.responseBody || data?.data || null;
};

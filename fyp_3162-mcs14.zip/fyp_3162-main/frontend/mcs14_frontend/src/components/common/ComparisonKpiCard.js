import InfoTooltip from "./InfoTooltip";

export default function ComparisonKPICard({
    title,
    leftLabel,
    leftValue,
    rightLabel,
    rightValue,
    accent,
    tooltip,
}) {
    return (
        <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl shadow-sm overflow-visible">
            {accent && <div className={`h-1 ${accent}`} />}

            <div className="p-6">
                <div className="flex items-center gap-2 mb-4">
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                        {title}
                    </p>
                    <InfoTooltip content={tooltip} />
                </div>

                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <p className="text-xs text-gray-400 dark:text-gray-500">
                            {leftLabel}
                        </p>
                        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                            {leftValue}
                        </h2>
                    </div>

                    <div>
                        <p className="text-xs text-gray-400 dark:text-gray-500">
                            {rightLabel}
                        </p>
                        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                            {rightValue}
                        </h2>
                    </div>
                </div>
            </div>
        </div>
    );
}

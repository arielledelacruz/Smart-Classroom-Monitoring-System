import { useState, useRef, useEffect } from "react";

export default function InfoTooltip({ content }) {
    const [visible, setVisible] = useState(false);
    const [position, setPosition] = useState("bottom");
    const triggerRef = useRef(null);
    const tooltipRef = useRef(null);

    useEffect(() => {
        if (!visible || !triggerRef.current || !tooltipRef.current) return;

        const triggerRect = triggerRef.current.getBoundingClientRect();
        const tooltipRect = tooltipRef.current.getBoundingClientRect();
        const viewportHeight = window.innerHeight;
        const viewportWidth = window.innerWidth;

        // check if tooltip overflows bottom
        if (triggerRect.bottom + tooltipRect.height + 8 > viewportHeight) {
            setPosition("top");
        } else {
            setPosition("bottom");
        }
    }, [visible]);

    if (!content) return null;

    return (
        <div className="relative inline-flex items-center">
            <button
                ref={triggerRef}
                type="button"
                onMouseEnter={() => setVisible(true)}
                onMouseLeave={() => setVisible(false)}
                onFocus={() => setVisible(true)}
                onBlur={() => setVisible(false)}
                className="inline-flex items-center justify-center w-4 h-4 rounded-full
                           bg-gray-200 dark:bg-gray-600
                           text-gray-500 dark:text-gray-300
                           hover:bg-gray-300 dark:hover:bg-gray-500
                           transition-colors focus:outline-none focus:ring-2
                           focus:ring-[#748DAE] focus:ring-offset-1"
                aria-label="More information"
            >
                <span className="text-[10px] font-bold leading-none">i</span>
            </button>

            {visible && (
                <div
                    ref={tooltipRef}
                    role="tooltip"
                    className={`
                        absolute z-50 left-1/2 -translate-x-1/2
                        w-72 sm:w-80
                        bg-gray-900 dark:bg-gray-700
                        text-white text-xs leading-5
                        rounded-xl shadow-xl
                        px-4 py-3
                        pointer-events-none
                        ${position === "bottom"
                            ? "top-full mt-2"
                            : "bottom-full mb-2"
                        }
                    `}
                >
                    {/* Arrow */}
                    <span
                        className={`
                            absolute left-1/2 -translate-x-1/2
                            w-0 h-0
                            border-x-4 border-x-transparent
                            ${position === "bottom"
                                ? "bottom-full border-b-4 border-b-gray-900 dark:border-b-gray-700"
                                : "top-full border-t-4 border-t-gray-900 dark:border-t-gray-700"
                            }
                        `}
                    />
                    <TooltipContent content={content} />
                </div>
            )}
        </div>
    );
}

function TooltipContent({ content }) {
    // Support structured content: { title, formula, example, note }
    if (typeof content === "object" && content !== null) {
        return (
            <div className="space-y-2">
                {content.title && (
                    <p className="font-semibold text-white text-xs">{content.title}</p>
                )}
                {content.description && (
                    <p className="text-gray-300">{content.description}</p>
                )}
                {content.formula && (
                    <div className="rounded-lg bg-gray-800 dark:bg-gray-600 px-3 py-2">
                        <p className="text-[10px] uppercase tracking-wide text-gray-400 mb-1">Formula</p>
                        <p className="text-gray-100 font-mono text-[11px] leading-4">{content.formula}</p>
                    </div>
                )}
                {content.example && (
                    <div>
                        <p className="text-[10px] uppercase tracking-wide text-gray-400 mb-1">Example</p>
                        <p className="text-gray-300">{content.example}</p>
                    </div>
                )}
                {content.note && (
                    <p className="text-gray-400 italic whitespace-pre-line">{content.note}</p>
                )}
            </div>
        );
    }

    // Plain string fallback
    return <p className="text-gray-200">{content}</p>;
}
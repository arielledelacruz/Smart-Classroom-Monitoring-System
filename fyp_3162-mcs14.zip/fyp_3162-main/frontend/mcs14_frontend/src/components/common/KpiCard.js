import InfoTooltip from "./InfoTooltip";

export default function KPICard({ title, value, accent, tooltip }) {
    return (
        <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl shadow-sm overflow-visible">
            <div className={`h-1 ${accent}`} />

            <div className="p-6">
                <div className="flex items-center gap-2">
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                        {title}
                    </p>
                    <InfoTooltip content={tooltip} />
                </div>

                <h2 className="mt-3 text-4xl font-bold text-gray-900 dark:text-white">
                    {value}
                </h2>
            </div>
        </div>
    );
}

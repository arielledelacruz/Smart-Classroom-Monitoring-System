import InfoTooltip from "./InfoTooltip";

/**
 * StatCard — displays a simple statistic with a title and value
 *
 * @param {string}          title
 * @param {string|number}   value
 * @param {string}          tooltip
 */
export default function StatCard({ title, value, tooltip }) {
    return (
        <div className="bg-white dark:bg-gray-700 p-4 rounded-xl shadow">
            <div className="flex items-center gap-2">
                <p className="text-gray-500 dark:text-gray-400 text-sm">
                    {title}
                </p>

                <InfoTooltip content={tooltip} />
            </div>

            <h2 className="text-xl font-bold mt-1 dark:text-white">
                {value}
            </h2>
        </div>
    );
}

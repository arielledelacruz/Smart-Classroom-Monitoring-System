import {
    LineChart,
    Line,
    XAxis,
    YAxis,
    Tooltip,
    ResponsiveContainer,
    CartesianGrid,
    BarChart,
    Bar,
    Legend,
    Cell,
} from "recharts";
import InfoTooltip from "../common/InfoTooltip";
import { CHART_TOOLTIPS } from "../../constants/dashboardTooltips";

const getWeekSortValue = (week) => {
    const match = String(week).match(/^W(\d+)$/i);
    return match ? Number(match[1]) : Number.MAX_SAFE_INTEGER;
};

const percentFormatter = (v) => `${(v * 100).toFixed(0)}%`;
const percentTooltipFormatter = (value) => `${(value * 100).toFixed(1)}%`;

function ChartInsightSection({ title, category, borderColor, bgColor, unitA, unitB = null }) {
    const filterItems = (unit) => ({
        explanations: (unit?.analyticalExplanations || []).filter(i => i.category === category),
        recommendations: (unit?.recommendations || []).filter(i => i.category === category),
        insights: (unit?.insights || []).filter(i => i.category === category),
    });

    const a = filterItems(unitA);
    const b = unitB ? filterItems(unitB) : null;

    const hasContent =
        a.explanations.length || a.recommendations.length || a.insights.length ||
        (b && (b.explanations.length || b.recommendations.length || b.insights.length));

    if (!hasContent) return null;

    const renderItems = (items, unit) => (
        <div className="space-y-3">
            {unitB && (
                <p className="text-xs font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500">
                    {unit?.unitCode}
                </p>
            )}
            {items.explanations.map((item, i) => (
                <div key={`exp-${i}`} className={`rounded-xl border ${borderColor} ${bgColor} p-4 text-sm leading-6 text-gray-700 dark:text-gray-200`}>
                    <p className="font-semibold mb-1">{title} Analysis</p>
                    <p>{item.message}</p>
                </div>
            ))}
            {items.recommendations.map((item, i) => (
                <div key={`rec-${i}`} className="rounded-xl border border-[#F5CBCB] bg-[#F5CBCB]/20 p-4 text-sm leading-6 text-gray-700 dark:text-gray-200">
                    <p className="font-semibold mb-1">Recommendation</p>
                    <p>{item.message}</p>
                </div>
            ))}
            {items.insights.map((item, i) => (
                <div key={`ins-${i}`} className="rounded-xl border border-[#748DAE] bg-[#748DAE]/10 p-4 text-sm leading-6 text-gray-700 dark:text-gray-200">
                    <p className="font-semibold mb-1">Insight</p>
                    <p>{item.message}</p>
                </div>
            ))}
        </div>
    );

    return (
        <div className="mt-4">
            {b ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {renderItems(a, unitA)}
                    {renderItems(b, unitB)}
                </div>
            ) : (
                renderItems(a, unitA)
            )}
        </div>
    );
}

export default function DashboardCharts({ mode = "single", unitA, unitB = null }) {

    const sortedUnitAWeeklyData = [...(unitA?.weeklyData || [])].sort(
        (a, b) => getWeekSortValue(a.week) - getWeekSortValue(b.week)
    );

    const sortedUnitBWeeklyData = [...(unitB?.weeklyData || [])].sort(
        (a, b) => getWeekSortValue(a.week) - getWeekSortValue(b.week)
    );

    const singleRiskDistribution = [
        { bucket: "Low",    students: unitA?.riskData?.lowRiskCount    ?? 0 },
        { bucket: "Medium", students: unitA?.riskData?.mediumRiskCount ?? 0 },
        { bucket: "High",   students: unitA?.riskData?.highRiskCount   ?? 0 },
    ];

    const allWeeks = Array.from(
        new Set([
            ...sortedUnitAWeeklyData.map((w) => w.week),
            ...sortedUnitBWeeklyData.map((w) => w.week),
        ])
    ).sort((a, b) => getWeekSortValue(a) - getWeekSortValue(b));

    const comparisonWeeklyData = allWeeks.map((week) => {
        const a = sortedUnitAWeeklyData.find((w) => w.week === week) || {};
        const b = sortedUnitBWeeklyData.find((w) => w.week === week) || {};
        return {
            week,
            attendanceA: a.attendance ?? 0,
            attendanceB: b.attendance ?? 0,
            engagementA: a.engagement ?? 0,
            engagementB: b.engagement ?? 0,
            riskA: a.risk ?? 0,
            riskB: b.risk ?? 0,
            lateA: a.late ?? 0,
            lateB: b.late ?? 0,
            earlyA: a.early ?? 0,
            earlyB: b.early ?? 0,
        };
    });

    const comparisonRiskDistribution = [
        { bucket: "Low",    [unitA?.unitCode || "Unit A"]: unitA?.riskData?.lowRiskCount    ?? 0, [unitB?.unitCode || "Unit B"]: unitB?.riskData?.lowRiskCount    ?? 0 },
        { bucket: "Medium", [unitA?.unitCode || "Unit A"]: unitA?.riskData?.mediumRiskCount ?? 0, [unitB?.unitCode || "Unit B"]: unitB?.riskData?.mediumRiskCount ?? 0 },
        { bucket: "High",   [unitA?.unitCode || "Unit A"]: unitA?.riskData?.highRiskCount   ?? 0, [unitB?.unitCode || "Unit B"]: unitB?.riskData?.highRiskCount   ?? 0 },
    ];

    // ─── Shared risk section (single mode) ────────────────────────────────────
    const SingleRiskSection = () => (
        <div className="bg-white dark:bg-gray-700 p-6 rounded-2xl shadow">
            <div className="flex items-center gap-2 mb-4">
                <h2 className="text-lg font-bold dark:text-white">Risk Overview</h2>
                <InfoTooltip content={CHART_TOOLTIPS.riskOverWeeks} />
            </div>

            {/* Two charts side by side */}
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 mb-2">
                {/* Risk Over Weeks */}
                <div>
                    <p className="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-3">
                        Average Risk Over Weeks
                    </p>
                    <ResponsiveContainer width="100%" height={200}>
                        <LineChart data={sortedUnitAWeeklyData}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="week" />
                            <YAxis
                                domain={[0, 1]}
                                tickFormatter={percentFormatter}
                            />
                            <Tooltip formatter={percentTooltipFormatter} />
                            <Line
                                type="monotone"
                                dataKey="risk"
                                stroke="#F5CBCB"
                                strokeWidth={3}
                                dot={false}
                            />
                        </LineChart>
                    </ResponsiveContainer>
                </div>

                {/* Risk Distribution */}
                <div>
                    <p className="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-3">
                        Risk Distribution
                    </p>
                    <ResponsiveContainer width="100%" height={200}>
                        <BarChart data={singleRiskDistribution}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="bucket" />
                            <YAxis allowDecimals={false} />
                            <Tooltip />
                            <Bar dataKey="students" name="Number of Students">
                                <Cell fill="#9ECAD6" />
                                <Cell fill="#748DAE" />
                                <Cell fill="#F5CBCB" />
                            </Bar>
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* Risk insights below both charts */}
            <ChartInsightSection
                title="Risk"
                category="RISK"
                unitA={unitA}
                borderColor="border-[#F5CBCB]"
                bgColor="bg-[#F5CBCB]/10"
            />
            <ChartInsightSection
                title="Risk Distribution"
                category="RISK_DISTRIBUTION"
                unitA={unitA}
                borderColor="border-[#748DAE]"
                bgColor="bg-[#748DAE]/10"
            />
        </div>
    );

    // ─── Shared risk section (comparison mode) ────────────────────────────────
    const ComparisonRiskSection = () => (
        <div className="bg-white dark:bg-gray-700 p-6 rounded-2xl shadow">
            <div className="flex items-center gap-2 mb-4">
                <h2 className="text-lg font-bold dark:text-white">Risk Overview</h2>
                <InfoTooltip content={CHART_TOOLTIPS.riskOverWeeks} />
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 mb-2">
                {/* Risk Over Weeks */}
                <div>
                    <p className="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-3">
                        Risk Over Weeks
                    </p>
                    <ResponsiveContainer width="100%" height={200}>
                        <LineChart data={comparisonWeeklyData}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="week" />
                            <YAxis
                                domain={[0, 1]}
                                tickFormatter={percentFormatter}
                            />
                            <Tooltip formatter={percentTooltipFormatter} />
                            <Legend />
                            <Line type="monotone" dataKey="riskA" name={unitA.unitCode} stroke="#748DAE" strokeWidth={3} dot={false} />
                            <Line type="monotone" dataKey="riskB" name={unitB.unitCode} stroke="#F5CBCB" strokeWidth={3} dot={false} />
                        </LineChart>
                    </ResponsiveContainer>
                </div>

                {/* Risk Distribution */}
                <div>
                    <p className="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-3">
                        Risk Distribution
                    </p>
                    <ResponsiveContainer width="100%" height={200}>
                        <BarChart data={comparisonRiskDistribution}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="bucket" />
                            <YAxis allowDecimals={false} />
                            <Tooltip />
                            <Legend />
                            <Bar dataKey={unitA.unitCode} fill="#9ECAD6" />
                            <Bar dataKey={unitB.unitCode} fill="#748DAE" />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* Risk insights below both charts */}
            <ChartInsightSection
                title="Risk"
                category="RISK"
                unitA={unitA}
                unitB={unitB}
                borderColor="border-[#F5CBCB]"
                bgColor="bg-[#F5CBCB]/10"
            />
        </div>
    );

    // ─── Comparison mode ──────────────────────────────────────────────────────
    if (mode === "comparison" && unitA && unitB) {
        return (
            <div className="space-y-6">
                {/* Attendance */}
                <div className="bg-white dark:bg-gray-700 p-6 rounded-2xl shadow">
                    <div className="flex items-center gap-2 mb-4">
                        <h2 className="text-lg font-bold dark:text-white">Attendance Over Weeks</h2>
                        <InfoTooltip content={CHART_TOOLTIPS.attendanceOverWeeks} />
                    </div>
                    <ResponsiveContainer width="100%" height={200}>
                        <LineChart data={comparisonWeeklyData}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="week" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            <Line type="monotone" dataKey="attendanceA" name={unitA.unitCode} stroke="#F5CBCB" strokeWidth={3} dot={false} />
                            <Line type="monotone" dataKey="attendanceB" name={unitB.unitCode} stroke="#9ECAD6" strokeWidth={3} dot={false} />
                        </LineChart>
                    </ResponsiveContainer>
                    <ChartInsightSection title="Attendance" category="ATTENDANCE" unitA={unitA} unitB={unitB} borderColor="border-[#9ECAD6]" bgColor="bg-[#9ECAD6]/10" />
                </div>

                {/* Engagement */}
                <div className="bg-white dark:bg-gray-700 p-6 rounded-2xl shadow">
                    <div className="flex items-center gap-2 mb-4">
                        <h2 className="text-lg font-bold dark:text-white">Engagement Over Weeks</h2>
                        <InfoTooltip content={CHART_TOOLTIPS.engagementOverWeeks} />
                    </div>
                    <ResponsiveContainer width="100%" height={200}>
                        <LineChart data={comparisonWeeklyData}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="week" />
                            <YAxis
                                domain={[0, 1]}
                                tickFormatter={percentFormatter}
                            />
                            <Tooltip formatter={percentTooltipFormatter} />
                            <Legend />
                            <Line type="monotone" dataKey="engagementA" name={unitA.unitCode} stroke="#9ECAD6" strokeWidth={3} dot={false} />
                            <Line type="monotone" dataKey="engagementB" name={unitB.unitCode} stroke="#748DAE" strokeWidth={3} dot={false} />
                        </LineChart>
                    </ResponsiveContainer>
                    <ChartInsightSection title="Engagement" category="ENGAGEMENT" unitA={unitA} unitB={unitB} borderColor="border-[#748DAE]" bgColor="bg-[#748DAE]/10" />
                </div>

                {/* Risk Overview — line + distribution together */}
                <ComparisonRiskSection />

                {/* Late Arrival vs Early Departure */}
                <div className="bg-white dark:bg-gray-700 p-6 rounded-2xl shadow">
                    <div className="flex items-center gap-2 mb-4">
                        <h2 className="text-lg font-bold dark:text-white">Late Arrival vs Early Departure</h2>
                        <InfoTooltip content={CHART_TOOLTIPS.lateEarlyComparison} />
                    </div>
                    <ResponsiveContainer width="100%" height={200}>
                        <BarChart data={comparisonWeeklyData}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="week" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            <Bar dataKey="earlyA" name={`${unitA.unitCode} Early`} fill="#748DAE" />
                            <Bar dataKey="lateA"  name={`${unitA.unitCode} Late`}  fill="#F5CBCB" />
                            <Bar dataKey="earlyB" name={`${unitB.unitCode} Early`} fill="#9ECAD6" />
                            <Bar dataKey="lateB"  name={`${unitB.unitCode} Late`}  fill="#c0d6e4" />
                        </BarChart>
                    </ResponsiveContainer>
                    <ChartInsightSection title="Attendance Quality" category="ATTENDANCE_QUALITY" unitA={unitA} unitB={unitB} borderColor="border-[#FFEAEA]" bgColor="bg-[#FFEAEA]/30" />
                </div>
            </div>
        );
    }

    // ─── Single mode ──────────────────────────────────────────────────────────
    return (
        <div className="space-y-6">
            {/* Attendance */}
            <div className="bg-white dark:bg-gray-700 p-6 rounded-2xl shadow">
                <div className="flex items-center gap-2 mb-4">
                    <h2 className="text-lg font-bold dark:text-white">Attendance Over Weeks</h2>
                    <InfoTooltip content={CHART_TOOLTIPS.attendanceOverWeeks} />
                </div>
                <ResponsiveContainer width="100%" height={200}>
                    <LineChart data={sortedUnitAWeeklyData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="week" />
                        <YAxis />
                        <Tooltip />
                        <Line type="monotone" dataKey="attendance" stroke="#F5CBCB" strokeWidth={3} dot={false} />
                    </LineChart>
                </ResponsiveContainer>
                <ChartInsightSection title="Attendance" category="ATTENDANCE" unitA={unitA} borderColor="border-[#9ECAD6]" bgColor="bg-[#9ECAD6]/10" />
            </div>

            {/* Engagement */}
            <div className="bg-white dark:bg-gray-700 p-6 rounded-2xl shadow">
                <div className="flex items-center gap-2 mb-4">
                    <h2 className="text-lg font-bold dark:text-white">Engagement Over Weeks</h2>
                    <InfoTooltip content={CHART_TOOLTIPS.engagementOverWeeks} />
                </div>
                <ResponsiveContainer width="100%" height={200}>
                    <LineChart data={sortedUnitAWeeklyData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="week" />
                        <YAxis
                            domain={[0, 1]}
                            tickFormatter={percentFormatter}
                        />
                        <Tooltip formatter={percentTooltipFormatter} />
                        <Line type="monotone" dataKey="engagement" stroke="#9ECAD6" strokeWidth={3} dot={false} />
                    </LineChart>
                </ResponsiveContainer>
                <ChartInsightSection title="Engagement" category="ENGAGEMENT" unitA={unitA} borderColor="border-[#748DAE]" bgColor="bg-[#748DAE]/10" />
            </div>

            {/* Risk Overview — line + distribution together */}
            <SingleRiskSection />

            {/* Late Arrival vs Early Departure */}
            <div className="bg-white dark:bg-gray-700 p-6 rounded-2xl shadow">
                <div className="flex items-center gap-2 mb-4">
                    <h2 className="text-lg font-bold dark:text-white">Late Arrival vs Early Departure</h2>
                    <InfoTooltip content={CHART_TOOLTIPS.lateEarlyComparison} />
                </div>
                <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={sortedUnitAWeeklyData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="week" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="early" fill="#748DAE" />
                        <Bar dataKey="late"  fill="#F5CBCB" />
                    </BarChart>
                </ResponsiveContainer>
                <ChartInsightSection title="Attendance Quality" category="ATTENDANCE_QUALITY" unitA={unitA} borderColor="border-[#FFEAEA]" bgColor="bg-[#FFEAEA]/30" />
            </div>
        </div>
    );
}
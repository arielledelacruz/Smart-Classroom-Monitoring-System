/**
 * DashboardFilters — week range sliders, year input, and semester selector
 *
 * @param {number}    weekStart     - current start week value
 * @param {number}    weekEnd       - current end week value
 * @param {string}    year          - current year value
 * @param {string}    semester      - current semester value
 * @param {Function}  onWeekStartChange
 * @param {Function}  onWeekEndChange
 * @param {Function}  onYearChange
 * @param {Function}  onSemesterChange
 */
export default function DashboardFilters({
    weekStart, weekEnd, year, semester,
    onWeekStartChange, onWeekEndChange, onYearChange, onSemesterChange, onApplyFilter
}) {
    return (
        <div className="space-y-5">

            {/* Week Range */}
            <div className="space-y-3">
                <div className="flex items-center justify-between">
                    <p className="text-xs font-semibold uppercase tracking-widest text-gray-400 dark:text-gray-500">
                        Week Range
                    </p>
                    <span className="text-xs font-medium text-gray-600 dark:text-gray-300
                                     bg-gray-100 dark:bg-gray-700 px-2 py-0.5 rounded-full">
                        {weekStart} – {weekEnd}
                    </span>
                </div>

                <div className="space-y-3">
                    <div>
                        <div className="flex justify-between text-xs text-gray-400 dark:text-gray-500 mb-1">
                            <span>Start</span>
                            <span>W{weekStart}</span>
                        </div>
                        <input
                            type="range" min={1} max={10} value={weekStart}
                            onChange={(e) => {
                                const val = Number(e.target.value);
                                if (val <= weekEnd) onWeekStartChange(val);
                            }}
                            className="w-full accent-blue-500 cursor-pointer"
                        />
                    </div>

                    <div>
                        <div className="flex justify-between text-xs text-gray-400 dark:text-gray-500 mb-1">
                            <span>End</span>
                            <span>W{weekEnd}</span>
                        </div>
                        <input
                            type="range" min={1} max={10} value={weekEnd}
                            onChange={(e) => {
                                const val = Number(e.target.value);
                                if (val >= weekStart) onWeekEndChange(val);
                            }}
                            className="w-full accent-blue-500 cursor-pointer"
                        />
                    </div>
                </div>
            </div>

            {/* Divider */}
            <hr className="border-gray-100 dark:border-gray-700" />

            {/* Year */}
            <div className="space-y-1.5">
                <p className="text-xs font-semibold uppercase tracking-widest text-gray-400 dark:text-gray-500">
                    Year
                </p>
                <input
                    type="text"
                    className="w-full px-3 py-1.5 text-sm rounded-lg
                               border border-gray-200 dark:border-gray-600
                               bg-white dark:bg-gray-900
                               text-gray-800 dark:text-white
                               focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={year}
                    onChange={(e) => onYearChange(e.target.value)}
                />
            </div>

            {/* Semester */}
            <div className="space-y-1.5">
                <p className="text-xs font-semibold uppercase tracking-widest text-gray-400 dark:text-gray-500">
                    Semester
                </p>
                <select
                    className="w-full px-3 py-1.5 text-sm rounded-lg
                               border border-gray-200 dark:border-gray-600
                               bg-white dark:bg-gray-900
                               text-gray-800 dark:text-white
                               focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={semester}
                    onChange={(e) => onSemesterChange(e.target.value)}
                >
                    <option value="S1">Semester 1</option>
                    <option value="S2">Semester 2</option>
                </select>
            </div>
            <button
                onClick={onApplyFilter}
                className="w-full mt-2 px-4 py-2 bg-blue-500 hover:bg-blue-600
                   text-white text-sm font-medium rounded-lg transition"
            >
                Apply Filter
            </button>
        </div>
    );
}

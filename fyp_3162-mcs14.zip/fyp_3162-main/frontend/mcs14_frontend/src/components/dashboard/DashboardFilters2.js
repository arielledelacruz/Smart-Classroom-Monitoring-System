/**
 * DashboardFilters — year input and semester selector
 *
 * @param {string}    year          - current year value
 * @param {string}    semester      - current semester value
 * @param {Function}  onYearChange
 * @param {Function}  onSemesterChange
 * @param {Function}  onApplyFilter
 */
export default function DashboardFilters({
                                             year, semester, onYearChange, onSemesterChange, onApplyFilter
                                         }) {
    return (
        <div className="space-y-5">

            {/* Year */}
            <div className="space-y-1.5">
                <p className="text-xs font-semibold uppercase tracking-widest text-gray-400 dark:text-gray-500">
                    Year
                </p>
                <input
                    type="text"
                    className="w-full px-3 py-1.5 text-sm rounded-lg
                               border border-gray-200 dark:border-gray-600
                               bg-white dark:bg-gray-900
                               text-gray-800 dark:text-white
                               focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={year}
                    onChange={(e) => onYearChange(e.target.value)}
                />
            </div>

            {/* Semester */}
            <div className="space-y-1.5">
                <p className="text-xs font-semibold uppercase tracking-widest text-gray-400 dark:text-gray-500">
                    Semester
                </p>
                <select
                    className="w-full px-3 py-1.5 text-sm rounded-lg
                               border border-gray-200 dark:border-gray-600
                               bg-white dark:bg-gray-900
                               text-gray-800 dark:text-white
                               focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={semester}
                    onChange={(e) => onSemesterChange(e.target.value)}
                >
                    <option value="S1">Semester 1</option>
                    <option value="S2">Semester 2</option>
                </select>
            </div>

            <button
                onClick={onApplyFilter}
                className="w-full mt-2 px-4 py-2 bg-blue-500 hover:bg-blue-600
                           text-white text-sm font-medium rounded-lg transition"
            >
                Apply Filter
            </button>
        </div>
    );
}
import { useState, useEffect } from "react";
import { X, Send, Trash2 } from "lucide-react";
import {
    saveFeedback,
    deleteFeedback,
    getFeedbackByStudentAndUnit,
} from "../../api/controller/StudentFeedbackApi";

const FEEDBACK_TYPES = [
    { label: "General", value: "GENERAL" },
    { label: "Attendance", value: "ATTENDANCE" },
    { label: "Engagement", value: "ENGAGEMENT" },
    { label: "Performance", value: "PERFORMANCE" },
];

export default function StudentFeedbackModal({
    isOpen,
    onClose,
    studentId,
    studentName,
    unitCode,
    lecturerId,
}) {
    const [feedbackContent, setFeedbackContent] = useState("");
    const [feedbackType, setFeedbackType] = useState("GENERAL");
    const [feedbackList, setFeedbackList] = useState([]);
    const [loading, setLoading] = useState(false);
    const [editingId, setEditingId] = useState(null);

    /* ============= Load feedback on mount ============= */
    useEffect(() => {
        if (isOpen && studentId && unitCode) {
            loadFeedback();
        }
    }, [isOpen, studentId, unitCode]);

    /* ============= Fetch feedback for this student/unit ============= */
    const loadFeedback = async () => {
        try {
            setLoading(true);
            const feedback = await getFeedbackByStudentAndUnit(studentId, unitCode);
            setFeedbackList(feedback || []);
        } catch (error) {
            console.error("Failed to load feedback:", error);
        } finally {
            setLoading(false);
        }
    };

    /* ============= Save or update feedback ============= */
    const handleSaveFeedback = async () => {
        if (!feedbackContent.trim()) {
            alert("Please enter feedback content");
            return;
        }

        try {
            setLoading(true);
            const feedback = {
                feedbackId: editingId || null,
                studentId,
                lecturerId,
                unitCode,
                feedbackContent,
                feedbackType,
            };

            const success = await saveFeedback(feedback);
            if (success) {
                setFeedbackContent("");
                setFeedbackType("GENERAL");
                setEditingId(null);
                await loadFeedback();
            } else {
                alert("Failed to save feedback");
            }
        } catch (error) {
            console.error("Error saving feedback:", error);
            alert("Error saving feedback");
        } finally {
            setLoading(false);
        }
    };

    /* ============= Delete feedback ============= */
    const handleDeleteFeedback = async (feedbackId) => {
        if (!window.confirm("Are you sure you want to delete this feedback?")) {
            return;
        }

        try {
            setLoading(true);
            const success = await deleteFeedback(feedbackId);
            if (success) {
                await loadFeedback();
            } else {
                alert("Failed to delete feedback");
            }
        } catch (error) {
            console.error("Error deleting feedback:", error);
            alert("Error deleting feedback");
        } finally {
            setLoading(false);
        }
    };

    /* ============= Edit feedback ============= */
    const handleEditFeedback = (feedback) => {
        setFeedbackContent(feedback.feedbackContent);
        setFeedbackType(feedback.feedbackType);
        setEditingId(feedback.feedbackId);
    };

    /* ============= Format date ============= */
    const formatDate = (dateString) => {
        const date = new Date(dateString);
        return date.toLocaleDateString() + " " + date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
                {/* Header */}
                <div className="sticky top-0 bg-gradient-to-r from-blue-500 to-blue-600 p-6 flex justify-between items-center">
                    <div>
                        <h2 className="text-2xl font-bold text-white">Student Feedback</h2>
                        <p className="text-blue-100 mt-1">{studentName} • {unitCode}</p>
                    </div>
                    <button
                        onClick={onClose}
                        className="text-white hover:bg-blue-700 rounded-full p-2 transition"
                    >
                        <X size={24} />
                    </button>
                </div>

                <div className="p-6 space-y-6">
                    {/* Feedback Input Section */}
                    <div className="bg-gray-50 dark:bg-gray-700 p-5 rounded-lg border border-gray-200 dark:border-gray-600">
                        <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">
                            {editingId ? "Edit Feedback" : "Add New Feedback"}
                        </h3>

                        {/* Feedback Type */}
                        <div className="mb-4">
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                Feedback Type
                            </label>
                            <select
                                value={feedbackType}
                                onChange={(e) => setFeedbackType(e.target.value)}
                                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-600 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                            >
                                {FEEDBACK_TYPES.map((type) => (
                                    <option key={type.value} value={type.value}>
                                        {type.label}
                                    </option>
                                ))}
                            </select>
                        </div>

                        {/* Feedback Content */}
                        <div className="mb-4">
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                Feedback Content
                            </label>
                            <textarea
                                value={feedbackContent}
                                onChange={(e) => setFeedbackContent(e.target.value)}
                                placeholder="Enter your personalized feedback here..."
                                rows="4"
                                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-600 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            />
                        </div>

                        {/* Action Buttons */}
                        <div className="flex justify-end gap-3">
                            {editingId && (
                                <button
                                    onClick={() => {
                                        setFeedbackContent("");
                                        setFeedbackType("GENERAL");
                                        setEditingId(null);
                                    }}
                                    disabled={loading}
                                    className="px-4 py-2 text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-600 transition disabled:opacity-50"
                                >
                                    Cancel
                                </button>
                            )}
                            <button
                                onClick={handleSaveFeedback}
                                disabled={loading}
                                className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg flex items-center gap-2 transition disabled:opacity-50"
                            >
                                <Send size={16} />
                                {editingId ? "Update" : "Save"} Feedback
                            </button>
                        </div>
                    </div>

                    {/* Feedback List */}
                    <div>
                        <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">
                            Previous Feedback ({feedbackList.length})
                        </h3>

                        {loading && <p className="text-center text-gray-500">Loading feedback...</p>}

                        {!loading && feedbackList.length === 0 && (
                            <p className="text-center text-gray-500 dark:text-gray-400 py-8">
                                No feedback yet for this student in this unit.
                            </p>
                        )}

                        <div className="space-y-3">
                            {feedbackList.map((feedback) => (
                                <div
                                    key={feedback.feedbackId}
                                    className="bg-white dark:bg-gray-700 p-4 rounded-lg border border-gray-200 dark:border-gray-600 hover:shadow-md transition"
                                >
                                    <div className="flex justify-between items-start mb-2">
                                        <div className="flex items-center gap-2">
                                            <span className="inline-block px-2 py-1 bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 text-xs font-semibold rounded">
                                                {feedback.feedbackType}
                                            </span>
                                            <p className="text-xs text-gray-500 dark:text-gray-400">
                                                {formatDate(feedback.createdAt)}
                                            </p>
                                        </div>
                                        <div className="flex gap-2">
                                            <button
                                                onClick={() => handleEditFeedback(feedback)}
                                                disabled={loading}
                                                className="text-blue-500 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 transition disabled:opacity-50"
                                            >
                                                Edit
                                            </button>
                                            <button
                                                onClick={() => handleDeleteFeedback(feedback.feedbackId)}
                                                disabled={loading}
                                                className="text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 transition disabled:opacity-50"
                                            >
                                                <Trash2 size={16} />
                                            </button>
                                        </div>
                                    </div>
                                    <p className="text-gray-800 dark:text-gray-200 leading-relaxed">
                                        {feedback.feedbackContent}
                                    </p>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

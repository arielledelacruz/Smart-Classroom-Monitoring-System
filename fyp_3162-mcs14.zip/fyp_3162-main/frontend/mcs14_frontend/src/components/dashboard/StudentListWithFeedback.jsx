import { useState } from "react";
import { MessageCircle } from "lucide-react";
import StudentFeedbackModal from "./StudentFeedbackModal";

export default function StudentListWithFeedback({
    students = [],
    unitCode,
    lecturerId,
}) {
    const [selectedStudent, setSelectedStudent] = useState(null);
    const [feedbackModalOpen, setFeedbackModalOpen] = useState(false);

    const handleOpenFeedback = (student) => {
        setSelectedStudent(student);
        setFeedbackModalOpen(true);
    };

    return (
        <>
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full">
                        <thead className="bg-gray-100 dark:bg-gray-700 border-b border-gray-200 dark:border-gray-600">
                            <tr>
                                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                                    Student ID
                                </th>
                                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                                    Name
                                </th>
                                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                                    Attendance
                                </th>
                                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900 dark:text-white">
                                    Engagement
                                </th>
                                <th className="px-6 py-3 text-center text-sm font-semibold text-gray-900 dark:text-white">
                                    Feedback
                                </th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200 dark:divide-gray-600">
                            {students && students.length > 0 ? (
                                students.map((student) => (
                                    <tr
                                        key={student.studentId}
                                        className="hover:bg-gray-50 dark:hover:bg-gray-700 transition"
                                    >
                                        <td className="px-6 py-4 text-sm text-gray-700 dark:text-gray-300">
                                            {student.studentId}
                                        </td>
                                        <td className="px-6 py-4 text-sm font-medium text-gray-900 dark:text-white">
                                            {student.studentName}
                                        </td>
                                        <td className="px-6 py-4 text-sm text-gray-700 dark:text-gray-300">
                                            {student.attendance ? `${student.attendance}%` : "N/A"}
                                        </td>
                                        <td className="px-6 py-4 text-sm text-gray-700 dark:text-gray-300">
                                            {student.engagement ? `${student.engagement}/10` : "N/A"}
                                        </td>
                                        <td className="px-6 py-4 text-center">
                                            <button
                                                onClick={() => handleOpenFeedback(student)}
                                                className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300 hover:bg-blue-200 dark:hover:bg-blue-800 transition"
                                                title="Add/View Feedback"
                                            >
                                                <MessageCircle size={18} />
                                            </button>
                                        </td>
                                    </tr>
                                ))
                            ) : (
                                <tr>
                                    <td
                                        colSpan="5"
                                        className="px-6 py-8 text-center text-gray-500 dark:text-gray-400"
                                    >
                                        No students found for this unit
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* Feedback Modal */}
            <StudentFeedbackModal
                isOpen={feedbackModalOpen}
                onClose={() => {
                    setFeedbackModalOpen(false);
                    setSelectedStudent(null);
                }}
                studentId={selectedStudent?.studentId}
                studentName={selectedStudent?.studentName}
                unitCode={unitCode}
                lecturerId={lecturerId}
            />
        </>
    );
}

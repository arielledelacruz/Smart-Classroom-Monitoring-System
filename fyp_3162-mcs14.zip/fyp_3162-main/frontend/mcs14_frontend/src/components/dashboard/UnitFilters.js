import { useEffect, useRef, useState } from "react";

/**
 * UnitFilter — dropdown checkbox list to select one or more unit codes
 *
 * @param {string[]}  units
 * @param {string[]}  selectedUnits
 * @param {Function}  onChange
 */
export default function UnitFilter({ units, selectedUnits, onChange }) {
    const [open, setOpen] = useState(false);
    const wrapperRef = useRef(null);

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
                setOpen(false);
            }
        };

        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    const toggleUnit = (unit) => {
        const isSelected = selectedUnits.includes(unit);

        if (isSelected) {
            onChange(selectedUnits.filter((u) => u !== unit));
            return;
        }

        if (selectedUnits.length >= 2) return;

        onChange([...selectedUnits, unit]);
    };

    return (
        <div ref={wrapperRef} className="bg-white dark:bg-gray-700 p-6 rounded-2xl shadow relative">
            <p className="font-semibold mb-2 dark:text-white">Select Unit(s)</p>

            <p className="text-xs mb-4 text-gray-500 dark:text-gray-300">
                {selectedUnits.length === 0 &&
                    "Choose one unit for default view, or choose two units for unit comparison."}
                {selectedUnits.length === 1 && "Single class analytics"}
                {selectedUnits.length === 2 && "Class comparison mode"}
            </p>

            <button
                onClick={() => setOpen((prev) => !prev)}
                className="w-full flex justify-between items-center px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 hover:bg-gray-100 transition dark:bg-gray-600 dark:border-gray-500 dark:text-white"
            >
                <span className="truncate">
                    {selectedUnits.length > 0 ? selectedUnits.join(", ") : "Select unit(s)"}
                </span>
                <span className="text-gray-500 ml-2">▾</span>
            </button>

            {open && (
                <div className="absolute left-0 right-0 mt-2 mx-6 bg-white dark:bg-gray-700 rounded-xl shadow-xl border border-gray-100 dark:border-gray-600 z-50 max-h-60 overflow-y-auto">
                    {units.map((unit) => (
                        <label
                            key={unit}
                            className="flex items-center gap-3 px-4 py-2 hover:bg-blue-50 dark:hover:bg-gray-600 cursor-pointer rounded-lg m-1"
                        >
                            <input
                                type="checkbox"
                                checked={selectedUnits.includes(unit)}
                                disabled={!selectedUnits.includes(unit) && selectedUnits.length >= 2}
                                onChange={() => toggleUnit(unit)}
                            />
                            <span className="dark:text-white">{unit}</span>
                        </label>
                    ))}
                </div>
            )}
        </div>
    );
}

import { useState } from "react";

/**
 * UnitFilter — dropdown to select a single unit code
 *
 * @param {string[]}  units        - all available unit codes
 * @param {string}    selectedUnit - currently selected unit code
 * @param {Function}  onChange     - called with the newly selected unit string
 */
export default function UnitFilter({ units, selectedUnit, onChange }) {
    const [open, setOpen] = useState(false);

    const handleSelect = (unit) => {
        onChange(unit);
        setOpen(false);
    };

    return (
        <div className="bg-white dark:bg-gray-700 p-6 rounded-2xl shadow relative">
            <p className="font-semibold mb-4 dark:text-white">Select Unit</p>

            <button
                onClick={() => setOpen(!open)}
                className="w-full flex justify-between items-center px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 hover:bg-gray-100 transition dark:bg-gray-600 dark:border-gray-500 dark:text-white"
            >
                <span className="truncate">
                    {selectedUnit || "Select a unit"}
                </span>
                <span className="text-gray-500 ml-2">▾</span>
            </button>

            {open && (
                <div className="absolute left-0 right-0 mt-2 mx-6 bg-white dark:bg-gray-700 rounded-xl shadow-xl border border-gray-100 dark:border-gray-600 z-50 max-h-60 overflow-y-auto">
                    {units.map((unit) => (
                        <button
                            key={unit}
                            onClick={() => handleSelect(unit)}
                            className={`w-full text-left px-4 py-2 hover:bg-blue-50 dark:hover:bg-gray-600 cursor-pointer rounded-lg m-1 dark:text-white
                                ${selectedUnit === unit ? "bg-blue-100 dark:bg-blue-800 font-semibold" : ""}`}
                        >
                            {unit}
                        </button>
                    ))}
                </div>
            )}
        </div>
    );
}
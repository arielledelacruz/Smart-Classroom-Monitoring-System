import { useState } from "react";
import Sidebar from "./Sidebar";
import Navbar from "./Navbar";
import { Outlet } from "react-router-dom";

export default function Layout() {
    const [sidebarOpen, setSidebarOpen] = useState(true);

    const toggleSidebar = () => {
        setSidebarOpen(!sidebarOpen);
    };

    return (
        <div className="flex min-h-screen bg-white dark:bg-[#061534]">
            <Sidebar sidebarOpen={sidebarOpen} />

            <div className="flex flex-1 flex-col min-w-0">
                <Navbar toggleSidebar={toggleSidebar} />

                <main className="flex-1">
                    <Outlet />
                </main>
            </div>
        </div>
    );
}

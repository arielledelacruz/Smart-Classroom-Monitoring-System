import { useState, useEffect } from "react";
import { Menu, Moon, Sun } from "lucide-react";
import ThemeModal from "./ThemeModal";
import PrintModal from "./PrintModal";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../api/context/AuthContext";

export default function Navbar({ toggleSidebar, user }) {
    const [dropdown, setDropdown] = useState(false);
    const [themeModal, setThemeModal] = useState(false);
    const [printModal, setPrintModal] = useState(false);
    const [darkMode, setDarkMode] = useState(
        localStorage.getItem("theme") === "dark"
    );

    const { authUser, logout } = useAuth();
    const navigate = useNavigate();

    const defaultAvatar = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0nMTIwJyBoZWlnaHQ9JzEyMCcgeG1sbnM9J2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJz48Y2lyY2xlIGN4PSc2MCcgY3k9JzQwJyByPSczMCcgZmlsbD0nI2Q5ZDlkaScvPjxjaXJjbGUgY3g9JzYwJyBjeT0nMzAnIHI9JzE1JyBmaWxsPScjYzJjMmMyJy8+PHJlY3QgeD0nMzUnIHk9JzY1JyB3aWR0aD0nNTAuNScgaGVpZ2h0PSczNScgcng9JzEwJyBmaWxsPScjYjBiMGIwJy8+PC9zdmc+";

    const [profileImage, setProfileImage] = useState(defaultAvatar);

    useEffect(() => {
        if (authUser?.photoUrl) {
            setProfileImage(authUser.photoUrl);
        }
    }, [authUser]);

    const toggleTheme = () => {
        document.documentElement.classList.toggle("dark");
        const isDark = document.documentElement.classList.contains("dark");
        setDarkMode(isDark);
        localStorage.setItem("theme", isDark ? "dark" : "light");
    };

    const smallText = () => {
        document.documentElement.classList.remove("text-large-mode");
        document.documentElement.classList.add("text-small-mode");
        localStorage.setItem("textSize", "small");
    };

    const normalText = () => {
        document.documentElement.classList.remove("text-large-mode");
        document.documentElement.classList.remove("text-small-mode");
        localStorage.setItem("textSize", "normal");
    };

    const increaseText = () => {
        document.documentElement.classList.remove("text-small-mode");
        document.documentElement.classList.add("text-large-mode");
        localStorage.setItem("textSize", "large");
    };

    useEffect(() => {
        const savedTheme = localStorage.getItem("theme");
        if (savedTheme === "dark") {
            document.documentElement.classList.add("dark");
            setDarkMode(true);
        }

        const textSize = localStorage.getItem("textSize");
        document.documentElement.classList.remove("text-small-mode");
        document.documentElement.classList.remove("text-large-mode");
        if (textSize === "small") document.documentElement.classList.add("text-small-mode");
        else if (textSize === "large") document.documentElement.classList.add("text-large-mode");
    }, []);

    const handleLogout = () => {
        logout();
        navigate("/login", { replace: true });
    };

    return (
        <header className="bg-white dark:bg-gray-700 border-b border-gray-200 dark:border-gray-600 px-6 py-3 flex justify-between items-center relative z-50">

            {/* LEFT */}
            <div className="flex items-center gap-4">
                <button
                    onClick={toggleSidebar}
                    className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-600 transition"
                >
                    <Menu size={22} className="text-gray-700 dark:text-white" />
                </button>
                <h1 className="font-semibold text-lg text-gray-800 dark:text-white tracking-wide">
                    Academic Dashboard
                </h1>
            </div>

            {/* RIGHT */}
            <div className="flex items-center gap-4">

                {/* Theme toggle */}
                <button
                    onClick={toggleTheme}
                    className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-600 transition"
                >
                    {darkMode ? (
                        <Sun size={20} className="text-yellow-400" />
                    ) : (
                        <Moon size={20} className="text-gray-700 dark:text-white" />
                    )}
                </button>

                {/* Profile group */}
                <div className="relative ml-4">
                    <button onClick={() => setDropdown(!dropdown)} className="flex items-center gap-3">
                        <img
                            src={profileImage}
                            alt="profile"
                            className="w-10 h-10 rounded-full border border-gray-200 dark:border-gray-600 hover:opacity-90 transition"
                        />
                        <div className="hidden md:flex flex-col leading-tight">
                            <p className="text-sm font-semibold text-gray-800 dark:text-white">
                                {authUser?.name || "Anonymous"}
                            </p>
                            <p className="text-xs text-gray-500 dark:text-gray-300">
                                {authUser?.email || "anonymous@lec.monash.edu"}
                            </p>
                        </div>
                    </button>

                    {/* Dropdown menu */}
                    {dropdown && (
                        <div className="absolute right-0 mt-3 w-56 bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl shadow-lg overflow-hidden z-50">

                            {/* Text size controls */}
                            <div className="px-4 py-3 border-b border-gray-200 dark:border-gray-600 flex flex-col gap-2">
                                <p className="text-xs text-gray-500 dark:text-gray-400">
                                    Text Size
                                </p>
                                <div className="flex gap-2">
                                    <button
                                        onClick={smallText}
                                        className="flex-1 py-1.5 rounded-md border border-gray-200 dark:border-gray-600 text-sm hover:bg-gray-100 dark:hover:bg-gray-600"
                                    >
                                        A-
                                    </button>
                                    <button
                                        onClick={normalText}
                                        className="flex-1 py-1.5 rounded-md border border-gray-200 dark:border-gray-600 text-sm hover:bg-gray-100 dark:hover:bg-gray-600"
                                    >
                                        A
                                    </button>
                                    <button
                                        onClick={increaseText}
                                        className="flex-1 py-1.5 rounded-md border border-gray-200 dark:border-gray-600 text-sm hover:bg-gray-100 dark:hover:bg-gray-600"
                                    >
                                        A+
                                    </button>
                                </div>
                            </div>

                            {/* Other dropdown options */}
                            <div className="flex flex-col">
                                <button
                                    onClick={() => { setDropdown(false); setPrintModal(true); }}
                                    className="w-full text-left px-4 py-2 text-sm hover:bg-gray-100 dark:hover:bg-gray-600"
                                >
                                    Print Page
                                </button>
                                <Link
                                    to={authUser?.userRole === "STUDENT" ? "/studentProfile" : "/lecturerProfile"}
                                    className="block w-full text-left px-4 py-2 text-sm hover:bg-gray-100 dark:hover:bg-gray-600"
                                >
                                    Profile
                                </Link>
                                <button
                                    onClick={handleLogout}
                                    className="w-full text-left px-4 py-2 text-sm text-red-500 hover:bg-gray-100 dark:hover:bg-gray-600"
                                >
                                    Logout
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            </div>

            {themeModal && <ThemeModal closeModal={() => setThemeModal(false)} />}
            {printModal && (
                <PrintModal
                    onClose={() => setPrintModal(false)}
                    userRole={authUser?.userRole}
                />
            )}
        </header>
    );
}
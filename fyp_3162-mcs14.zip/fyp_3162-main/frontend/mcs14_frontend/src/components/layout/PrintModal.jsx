import { useState, useEffect } from "react";
import { X, Printer } from "lucide-react";

const LECTURER_SECTIONS = [
  { id: "print-kpi",    label: "KPI summary",      desc: "Attendance, engagement, risk scores" },
  { id: "print-stats",  label: "Stat cards",        desc: "Total students, late arrivals, early departures" },
  { id: "print-charts", label: "Weekly charts",     desc: "Attendance, engagement & risk trend lines" },
  { id: "print-risk",   label: "Risk distribution", desc: "High / medium / low risk breakdown" },
];

const STUDENT_SECTIONS = [
  { id: "print-kpi",      label: "KPI summary",  desc: "Overall attendance, engagement & risk scores" },
  { id: "print-units",    label: "Unit cards",   desc: "All enrolled units this semester" },
  { id: "print-overview", label: "Unit overview",desc: "Selected unit stats & insights" },
  { id: "print-charts",   label: "Charts & tabs",desc: "Weekly attendance, engagement & presence quality" },
];

export default function PrintModal({ onClose, userRole }) {
  const sections = userRole === "STUDENT" ? STUDENT_SECTIONS : LECTURER_SECTIONS;

  const [checked, setChecked] = useState(
    Object.fromEntries(sections.map((s, i) => [s.id, i < 3]))
  );
  const [landscape, setLandscape] = useState(false);

  const toggleSection = (id) =>
    setChecked((prev) => ({ ...prev, [id]: !prev[id] }));

  const selectedCount = Object.values(checked).filter(Boolean).length;

  const handlePrint = () => {
    const hideRules = sections
      .filter((s) => !checked[s.id])
      .map((s) => `.${s.id} { display: none !important; }`)
      .join("\n");

    const orientationRule = landscape
      ? "@page { size: landscape; }"
      : "@page { size: portrait; }";

    let style = document.getElementById("print-control");
    if (!style) {
      style = document.createElement("style");
      style.id = "print-control";
      document.head.appendChild(style);
    }
    style.textContent = `${orientationRule}\n@media print {\n${hideRules}\n}`;

    onClose();
    setTimeout(() => window.print(), 100);
  };

  useEffect(() => {
    const handler = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/40"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl w-full max-w-sm mx-4 overflow-hidden">

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center gap-2">
            <Printer size={18} className="text-gray-600 dark:text-gray-300" />
            <h2 className="text-sm font-semibold text-gray-800 dark:text-white">Print options</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition"
          >
            <X size={16} className="text-gray-500 dark:text-gray-400" />
          </button>
        </div>

        {/* Sections */}
        <div className="px-5 py-4 space-y-2">
          <p className="text-xs font-semibold uppercase tracking-widest text-gray-400 dark:text-gray-500 mb-3">
            Select sections
          </p>
          {sections.map((s) => (
            <label
              key={s.id}
              className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition
                ${checked[s.id]
                  ? "border-blue-300 bg-blue-50 dark:border-blue-600 dark:bg-blue-900/20"
                  : "border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50"
                }`}
            >
              <input
                type="checkbox"
                checked={checked[s.id]}
                onChange={() => toggleSection(s.id)}
                className="w-4 h-4 accent-blue-500"
              />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-800 dark:text-white">{s.label}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{s.desc}</p>
              </div>
            </label>
          ))}
        </div>

        {/* Orientation */}
        <div className="px-5 pb-4">
          <p className="text-xs font-semibold uppercase tracking-widest text-gray-400 dark:text-gray-500 mb-2">
            Page orientation
          </p>
          <div className="flex gap-2">
            {[{ label: "Portrait", value: false }, { label: "Landscape", value: true }].map((opt) => (
              <button
                key={opt.label}
                onClick={() => setLandscape(opt.value)}
                className={`flex-1 py-2 text-sm rounded-lg border transition
                  ${landscape === opt.value
                    ? "border-blue-400 bg-blue-50 text-blue-700 dark:border-blue-500 dark:bg-blue-900/20 dark:text-blue-300 font-medium"
                    : "border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700/50"
                  }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-2 px-5 py-3 border-t border-gray-200 dark:border-gray-700">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition"
          >
            Cancel
          </button>
          <button
            onClick={handlePrint}
            disabled={selectedCount === 0}
            className="flex items-center gap-2 px-4 py-2 text-sm bg-blue-500 text-white rounded-lg
                       hover:bg-blue-600 disabled:opacity-40 disabled:cursor-not-allowed transition font-medium"
          >
            <Printer size={15} />
            Print
            <span className="bg-white/25 text-xs rounded-full px-1.5 py-0.5 leading-none">
              {selectedCount}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
}
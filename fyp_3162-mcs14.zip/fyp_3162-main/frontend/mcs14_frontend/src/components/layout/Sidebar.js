import { Link, useLocation } from "react-router-dom";
import { LayoutDashboard, Upload, FileBarChart } from "lucide-react";
import { useAuth } from "../../api/context/AuthContext";

export default function Sidebar({ sidebarOpen }) {
    const location = useLocation();
    const { authUser } = useAuth();

    const isLecturer = authUser?.userRole === "LECTURER";
    const isStudent = authUser?.userRole === "STUDENT";

    const navItem = (path) =>
        `group relative flex items-center gap-3 rounded-xl px-3 py-3 text-sm transition-all duration-200
         ${
             location.pathname === path
                 ? "bg-[#c7ced6] text-[#2f3a45] font-semibold dark:bg-[#1e293b] dark:text-[#f1f5f9]"
                 : "text-[#4b5563] hover:bg-[#d3d9e0] hover:text-[#1f2937] dark:text-[#94a3b8] dark:hover:bg-[#172033] dark:hover:text-[#f1f5f9]"
         }`;

    const iconBox = (path) =>
        `flex h-10 w-10 items-center justify-center rounded-lg transition-all duration-200
         ${
             location.pathname === path
                 ? "bg-[#6b8cae] text-white dark:bg-[#3b82f6] dark:text-white"
                 : "bg-[#cfd6dd] text-[#4b5563] group-hover:bg-[#bfc7cf] dark:bg-[#0f172a] dark:text-[#94a3b8] dark:group-hover:bg-[#1e293b]"
         }`;

    return (
        <aside
            className={`
                ${sidebarOpen ? "w-64" : "w-20"}
                hidden md:flex flex-col
                min-h-screen
                bg-[#dfe3e8] dark:bg-[#020617]
                border-r border-[#cfd6dd] dark:border-[#1e293b]
                px-4 py-5
                transition-all duration-300
            `}
        >
            {/* Brand (KOALA — ALWAYS LIGHT) */}
            <div className="mb-6 flex flex-col items-center justify-center overflow-visible">
                <div
                    className={`transform transition-all duration-300 origin-top
                    ${sidebarOpen ? "scale-100" : "scale-[0.55]"}`}
                >
                    {/* Koala */}
                    <div className="relative flex h-28 w-28 items-center justify-center rounded-full bg-[#eef1f4] dark:bg-[#374151]">
                        {/* leaf */}
                        <div className="absolute top-4 right-4 h-4 w-3 rounded-full bg-green-300 rotate-12" />

                        {/* head */}
                        <div className="relative h-20 w-20 rounded-[24px] bg-[#d1d5db]">
                            {/* ears */}
                            <div className="absolute -top-2 left-1 h-7 w-7 rounded-full bg-[#9ca3af]" />
                            <div className="absolute -top-2 right-1 h-7 w-7 rounded-full bg-[#9ca3af]" />

                            {/* inner ears */}
                            <div className="absolute -top-1 left-3 h-4 w-4 rounded-full bg-[#e5e7eb]" />
                            <div className="absolute -top-1 right-3 h-4 w-4 rounded-full bg-[#e5e7eb]" />

                            {/* eyes */}
                            <div className="absolute top-6 left-5 h-2 w-2 rounded-full bg-gray-700 blink" />
                            <div
                                className="absolute top-6 right-5 h-2 w-2 rounded-full bg-gray-700 blink"
                                style={{ animationDelay: "0.15s" }}
                            />

                            {/* nose */}
                            <div className="absolute top-7 left-1/2 h-5 w-4 -translate-x-1/2 rounded-full bg-gray-800" />

                            {/* smile */}
                            <div className="absolute top-12 left-1/2 h-3 w-5 -translate-x-1/2 rounded-b-full border border-t-0 border-gray-700" />

                            {/* blush */}
                            <div className="absolute top-10 left-3 h-2.5 w-2.5 rounded-full bg-pink-200 opacity-60" />
                            <div className="absolute top-10 right-3 h-2.5 w-2.5 rounded-full bg-pink-200 opacity-60" />
                        </div>
                    </div>
                </div>

                {sidebarOpen && (
                    <h2 className="mt-3 text-lg font-semibold tracking-wide text-[#374151] dark:text-[#e5e7eb]">
                        MCS14
                    </h2>
                )}
            </div>

            {/* Section label */}
            {sidebarOpen && (
                <p className="mb-3 px-2 text-[11px] uppercase tracking-[0.2em] text-[#6b7280] dark:text-[#64748b]">
                    {isLecturer ? "Management" : "Student"}
                </p>
            )}

            {/* Nav */}
            <nav className="flex flex-col gap-2">
                {isLecturer && (
                    <>
                        <Link
                            to="/lecturerDashboard"
                            className={`${navItem("/lecturerDashboard")} ${!sidebarOpen ? "justify-center px-0" : ""}`}
                        >
                            <div className={iconBox("/lecturerDashboard")}>
                                <LayoutDashboard size={18} />
                            </div>
                            {sidebarOpen && <span>Class Dashboard</span>}
                        </Link>

                        <Link
                            to="/studentList"
                            className={`${navItem("/studentList")} ${!sidebarOpen ? "justify-center px-0" : ""}`}
                        >
                            <div className={iconBox("/studentList")}>
                                <FileBarChart size={18} />
                            </div>
                            {sidebarOpen && <span>Student Report</span>}
                        </Link>

                        <Link
                            to="/adminUpload"
                            className={`${navItem("/adminUpload")} ${!sidebarOpen ? "justify-center px-0" : ""}`}
                        >
                            <div className={iconBox("/adminUpload")}>
                                <Upload size={18} />
                            </div>
                            {sidebarOpen && <span>Admin Upload</span>}
                        </Link>
                    </>
                )}

                {isStudent && (
                    <Link
                        to="/studentDashboard"
                        className={`${navItem("/studentDashboard")} ${!sidebarOpen ? "justify-center px-0" : ""}`}
                    >
                        <div className={iconBox("/studentDashboard")}>
                            <LayoutDashboard size={18} />
                        </div>
                        {sidebarOpen && <span>Student Dashboard</span>}
                    </Link>
                )}
            </nav>
        </aside>
    );
}

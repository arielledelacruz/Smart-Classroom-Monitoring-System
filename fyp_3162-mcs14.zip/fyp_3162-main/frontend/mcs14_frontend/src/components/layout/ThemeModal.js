import { useState } from "react";

export default function ThemeModal({ closeModal }) {

    const [theme, setTheme] = useState(localStorage.getItem("theme") || "light");

    const changeTheme = (newTheme) => {
        setTheme(newTheme);
        localStorage.setItem("theme", newTheme);

        document.documentElement.className = newTheme;
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center">

            <div className="bg-white p-6 rounded-2xl shadow-lg w-80">

                <h2 className="text-xl font-bold mb-4">
                    Choose Theme
                </h2>

                <div className="space-y-3">

                    <button
                        onClick={() => changeTheme("light")}
                        className={`w-full p-3 rounded-xl border ${theme === "light" ? "bg-gray-200" : ""}`}
                    >
                        ☀️ Light
                    </button>

                    <button
                        onClick={() => changeTheme("dark")}
                        className={`w-full p-3 rounded-xl border ${theme === "dark" ? "bg-gray-200" : ""}`}
                    >
                        🌙 Dark
                    </button>

                    <button
                        onClick={() => changeTheme("system")}
                        className={`w-full p-3 rounded-xl border ${theme === "system" ? "bg-gray-200" : ""}`}
                    >
                        💻 System
                    </button>

                </div>

                <button
                    onClick={closeModal}
                    className="mt-4 w-full bg-gray-800 text-white p-2 rounded-xl"
                >
                    Close
                </button>

            </div>

        </div>
    );
}
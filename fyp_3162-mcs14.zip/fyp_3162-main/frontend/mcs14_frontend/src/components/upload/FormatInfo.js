export default function FormatInfo({ type }) {
    return (
        <div
            className="mt-5 rounded-xl overflow-hidden text-sm"
            style={{
                border: `1.5px solid ${type.accent}33`,
                background: type.accentLight,
            }}
        >
            {/* Header */}
            <div
                className="flex items-center gap-2 px-4 py-2.5"
                style={{ background: `${type.accent}18`, borderBottom: `1px solid ${type.accent}22` }}
            >
                <svg viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4 shrink-0" style={{ color: type.accent }}>
                    <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                </svg>
                <span className="font-semibold text-xs uppercase tracking-wide" style={{ color: type.accent }}>
                    Expected File Format
                </span>
            </div>

            <div className="px-4 py-3 flex flex-col gap-3">
                {/* Filename */}
                <div>
                    <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">Filename</p>
                    <div className="flex flex-wrap items-center gap-2">
                        <code
                            className="text-xs font-mono px-2.5 py-1 rounded-md font-semibold"
                            style={{ background: `${type.accent}18`, color: type.accent }}
                        >
                            {type.expectedFilename}
                        </code>
                        {type.filenamePattern && (
                            <span className="text-xs text-gray-400 italic">
                                pattern: <span className="font-mono">{type.filenamePattern}</span>
                            </span>
                        )}
                    </div>
                </div>

                {/* Columns */}
                <div>
                    <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Required Columns (Row 1 = Header)</p>
                    <div className="overflow-x-auto rounded-lg" style={{ border: `1px solid ${type.accent}22` }}>
                        <table className="w-full text-xs border-collapse">
                            <thead>
                            <tr style={{ background: `${type.accent}18` }}>
                                <th
                                    className="text-left px-3 py-2 font-semibold"
                                    style={{ color: type.accent, borderBottom: `1px solid ${type.accent}22` }}
                                >
                                    Column Name
                                </th>
                                <th
                                    className="text-left px-3 py-2 font-semibold"
                                    style={{ color: type.accent, borderBottom: `1px solid ${type.accent}22` }}
                                >
                                    Description
                                </th>
                            </tr>
                            </thead>
                            <tbody>
                            {type.columns.map((col, i) => (
                                <tr
                                    key={col}
                                    style={{
                                        background: i % 2 === 0 ? "transparent" : `${type.accent}08`,
                                        borderBottom: i < type.columns.length - 1 ? `1px solid ${type.accent}15` : "none",
                                    }}
                                >
                                    <td className="px-3 py-2">
                                        <code
                                            className="font-mono font-semibold px-1.5 py-0.5 rounded"
                                            style={{ background: `${type.accent}18`, color: type.accent }}
                                        >
                                            {col}
                                        </code>
                                    </td>
                                    <td className="px-3 py-2 text-gray-500">
                                        {type.columnNotes[col] || "—"}
                                    </td>
                                </tr>
                            ))}
                            </tbody>
                        </table>
                    </div>
                </div>

                <p className="text-xs text-gray-400">Columns must appear in this order starting from column A.</p>
            </div>
        </div>
    );
}

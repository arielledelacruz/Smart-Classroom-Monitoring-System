export default function UploadCard({ type, isActive, onClick }) {
    return (
        <button
            onClick={onClick}
            className={`w-full text-left transition-all duration-200 rounded-[14px] px-5 py-4
            border-2
            ${
                isActive
                    ? "bg-[var(--active-bg)] border-[var(--active-border)] shadow-sm"
                    : "bg-white dark:bg-[#111827] border-[#e5e7eb] dark:border-[#334155] hover:bg-[#f9fafb] dark:hover:bg-[#1f2937]"
            }`}
            style={{
                "--active-bg": type.accentLight,
                "--active-border": type.accent,
                boxShadow: isActive
                    ? `0 4px 16px ${type.accent}22`
                    : "0 1px 4px rgba(0,0,0,0.06)",
            }}
        >
            <div className="flex items-center gap-3">
                <span
                    className="transition-colors"
                    style={{ color: isActive ? type.accent : "#9ca3af" }}
                >
                    {type.icon}
                </span>

                <div>
                    <div
                        className="font-semibold text-sm text-[#374151] dark:text-[#e5e7eb]"
                        style={{ color: isActive ? type.accent : undefined }}
                    >
                        {type.label}
                    </div>

                    <div className="text-xs mt-0.5 text-[#9ca3af] dark:text-[#94a3b8]">
                        {type.description}
                    </div>
                </div>

                {isActive && (
                    <span className="ml-auto" style={{ color: type.accent }}>
                        <svg viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5">
                            <path
                                fillRule="evenodd"
                                d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                                clipRule="evenodd"
                            />
                        </svg>
                    </span>
                )}
            </div>
        </button>
    );
}

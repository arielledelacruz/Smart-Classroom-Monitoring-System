import { ApiUrls } from "./apiUrl";

export const UPLOAD_TYPES = [
    {
        id: "attendance",
        label: "Attendance Record",
        icon: (
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-6 h-6">
                <path d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
        ),
        description: "Upload attendance records for student tracking",
        endpoint: ApiUrls.UPLOAD_ATTENDANCE_DATA,
        alertMsg: "Please select attendance data file",
        accent: "#6b8cae",
        accentLight: "#e8eff6",
        expectedFilename: "FIT3077-2025-S1-students.xlsx",
        columns: ["id", "motion_type", "time"],
        columnNotes: {
            id: "Unique student identifier enrolled in this unit",
            motion_type: "Type of motion recorded for attendance",
            time: "Timestamp of the attendance record",
        },
    },
    {
        id: "classList",
        label: "Class List",
        icon: (
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-6 h-6">
                <path d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
        ),
        description: "Register or update list of student enrolled in class",
        endpoint: ApiUrls.UPLOAD_CLASS_LIST_DATA,
        alertMsg: "Please select class list file",
        accent: "#c08a4d",
        accentLight: "#f7ede2",
        expectedFilename: "FIT3077-2025-S1-students.xlsx",
        filenamePattern: null,
        columns: ["studentId"],
        columnNotes: {
            studentId: "Unique identifier",
        },
    },
    {
        id: "lecturer",
        label: "Lecturer Profile",
        icon: (
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-6 h-6">
                <path d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
        ),
        description: "Register or update lecturer profiles",
        endpoint: ApiUrls.UPLOAD_LECTURER_DATA,
        alertMsg: "Please select lecturer profile file",
        accent: "#5f8f7b",
        accentLight: "#e8f3ee",
        expectedFilename: "lecturers.xlsx",
        filenamePattern: null,
        columns: ["id", "name", "email", "phone", "faculty", "office", "researchArea"],
        columnNotes: {
            id: "Unique lecturer identifier",
            name: "Full name",
            email: "Institutional email address",
            phone: "Contact number",
            faculty: "Faculty",
            office: "Office room",
            researchArea: "Comma-separated list of research areas",
        },
    },
    {
        id: "studentProfile",
        label: "Student Profile",
        icon: (
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-6 h-6">
                <path d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
        ),
        description: "Register or update student profile",
        endpoint: ApiUrls.UPLOAD_STUDENT_PROFILE,
        alertMsg: "Please select student profile file",
        accent: "#8a79b8",
        accentLight: "#f0edf7",
        expectedFilename: "students.xlsx",
        filenamePattern: null,
        columns: ["studentId", "email", "name", "faculty", "phone", "enrolledYear"],
        columnNotes: {
            studentId: "Unique identifier",
            email: "Institutional email address",
            name: "Full name",
            faculty: "Faculty",
            phone: "Contact number",
            enrolledYear: "University Enrolled year",
        },
    },
];

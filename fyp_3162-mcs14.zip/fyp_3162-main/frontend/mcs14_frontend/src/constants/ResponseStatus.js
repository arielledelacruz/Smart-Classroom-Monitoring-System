export const ResponseStatus = {
    SUCCESS: "SUCCESS",
    FAIL: "FAIL",
};
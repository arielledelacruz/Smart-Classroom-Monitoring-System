export const UserRoles = {
    LECTURER: "LECTURER",
    STUDENT: "STUDENT",
};
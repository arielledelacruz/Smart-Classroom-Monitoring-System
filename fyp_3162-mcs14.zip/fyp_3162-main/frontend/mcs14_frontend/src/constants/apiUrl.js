const BASE_URL = process.env.REACT_APP_API_BASE_URL;

export const ApiUrls = {

    BASE_URL,

    /**
     * Authentication
     */
    VALIDATE_LOGIN: `${BASE_URL}/auth`,

    /**
     * Lecturer related
     */
    UPLOAD_LECTURER_PROFILE_PHOTO: `${BASE_URL}/navigation/upload_profile_photo_lecturer`,

    /**
     * Student related
     */
    UPLOAD_STUDENT_PROFILE_PHOTO: `${BASE_URL}/navigation/upload_profile_photo_student`,
    QUERY_STUDENT_ENROLLED_UNITS: `${BASE_URL}/student/enrolled-units`,
    QUERY_STUDENT_ATTENDANCE_SUMMARY: `${BASE_URL}/student/attendance/summary`,
    QUERY_UNIT_ATTENDANCE_DETAIL: `${BASE_URL}/student/attendance/unit`,
    QUERY_SESSION_HISTORY: `${BASE_URL}/student/sessions`,
    QUERY_STUDENT_ANALYTICS: `${BASE_URL}/student/analytics`,

    /**
     * Dashboard related
     */
    QUERY_ALL_UNIT_CODE:  `${BASE_URL}/dashboard/query_all_unit_code`,
    QUERY_FILTER_DATA:    `${BASE_URL}/dashboard/query_filter_data`,
    QUERY_STUDENT_LIST:   `${BASE_URL}/dashboard/student_report/get_students_by_unit`,

    /**
     * Student Feedback related
     */
    SAVE_STUDENT_FEEDBACK: `${BASE_URL}/feedback/save`,
    GET_FEEDBACK_BY_ID: `${BASE_URL}/feedback`,
    GET_FEEDBACK_BY_STUDENT_UNIT: `${BASE_URL}/feedback/student`,
    GET_FEEDBACK_BY_STUDENT: `${BASE_URL}/feedback/student`,
    GET_FEEDBACK_BY_UNIT: `${BASE_URL}/feedback/unit`,
    GET_FEEDBACK_BY_LECTURER_UNIT: `${BASE_URL}/feedback/lecturer`,
    DELETE_FEEDBACK: `${BASE_URL}/feedback`,

    /**
     * Admin related
     */
    UPLOAD_LECTURER_DATA: `${BASE_URL}/admin/upload_lecturer_data`,
    UPLOAD_ATTENDANCE_DATA: `${BASE_URL}/admin/upload_attendance_data_excel`,
    UPLOAD_ASSESSMENT_DATA: `${BASE_URL}/admin/upload_unit_semester_student_mark_data`,
    UPLOAD_CLASS_LIST_DATA: `${BASE_URL}/admin/upload_unit_semester_data`,
    UPLOAD_STUDENT_PROFILE: `${BASE_URL}/admin/upload_student_data`,
};


export const KPI_TOOLTIPS = {
    attendanceRate: {
        title: "Avg Attendance Rate",
        description: "Percentage of expected sessions that students attended across the selected week range.",
        formula: "Attended sessions ÷ Total expected sessions",
        example: "8 attended out of 10 sessions = 80%",
        note: "Higher is better.",
    },

    engagementScore: {
        title: "Avg Engagement Score",
        description: "Measures active classroom participation based on detected motion types.",
        formula: "Σ(weight × motion count) ÷ total motions",
        example: "Sitting = 0.2 · Standing = 0.4 · Raising Hand = 1.0",
        note: "Higher scores indicate more active participation.",
    },

    avgRiskScore: {
        title: "Average Risk Score",
        description:
            "A composite indicator that estimates student academic risk based on attendance behavior, engagement, and participation patterns.",

        formula:
            "(1 − attendance)×0.30 + consecutiveAbsence×0.10 + attendanceTrendSlope×0.15 + (1 − presenceQuality)×0.15 + (1 − engagement)×0.25 + attendanceQuality×0.05",

        note:
            "Higher scores indicate higher academic risk and greater need for support.\n\n" +

            "Component definitions:\n" +
            "• Attendance: proportion of sessions attended\n" +
            "• Consecutive absence: repeated missed sessions\n" +
            "• Attendance trend slope: change in attendance over time\n" +
            "• Presence quality: proportion of time actively present in class\n" +
            "• Engagement: participation level during sessions\n" +
            "• Attendance quality: penalties from late arrivals and early departures"
    },

    avgEngagementScore: {
        title: "Avg Engagement Score",
        description: "Average engagement score across both units in the selected week range.",
        formula: "Σ(weight × motion count) ÷ total motions",
        note: "Higher scores indicate more active participation.",
    },

    highRiskRate: {
        title: "% High-Risk Students",
        description: "Proportion of students whose risk score meets or exceeds the high-risk threshold (≥ 0.70).",
        formula: "High-risk students ÷ Total students × 100",
        note: "Lower is better.",
    },
};

export const STAT_TOOLTIPS = {
    totalStudents: {
        title: "Total Students",
        description: "Number of students enrolled in the selected unit for the filtered semester.",
    },

    lateArrivals: {
        title: "Late Arrivals",
        description: "Number of sessions where a student arrived 15+ minutes after the expected start time.",
        note: "Counted across all students and all weeks in the filter range.",
    },

    earlyDepartures: {
        title: "Early Departures",
        description: "Number of sessions where a student left 15+ minutes before the expected end time.",
        note: "Counted across all students and all weeks in the filter range.",
    },

    highRiskCount: {
        title: "High-Risk Count",
        description: "Number of students whose calculated risk score is ≥ 0.70 as of the latest filtered week.",
        note: "Based on the comprehensive risk formula combining all available signals.",
    },
};

export const CHART_TOOLTIPS = {
    weeklyBreakdown: {
        title: "Weekly Breakdown",
        description: "Shows how attendance, engagement, risk, lateness, and early departure change across the selected weeks.",
    },

    weeklyComparison: {
        title: "Weekly Comparison",
        description: "Side-by-side view of two units across the same week range to highlight differences in key metrics.",
    },

    attendanceOverWeeks: {
        title: "Attendance Over Weeks",
        description: "Weekly count of students present in each session.",
        formula: "Present students ÷ Total enrolled × 100",
    },

    engagementOverWeeks: {
        title: "Engagement Over Weeks",
        description: "Average engagement score per week across all present students.",
        note: "Only present students are included in the average.",
    },

    riskOverWeeks: {
        title: "Risk Over Weeks",
        description: "Average comprehensive risk score per week across all students.",
        note: "A rising trend indicates worsening attendance or engagement patterns.",
    },

    riskDistribution: {
        title: "Risk Distribution",
        description: "Breakdown of students by risk category based on their score as of the latest filtered week.",
        example: "Low < 0.40 · Medium 0.40–0.70 · High ≥ 0.70",
    },

    lateEarlyComparison: {
        title: "Late Arrivals vs Early Departures",
        description: "Weekly count of students arriving late or leaving early.",
        note: "High counts may indicate timetable conflicts or session engagement issues.",
    },
};

// import { useState } from "react";
//
// const pct = (v) => `${((v ?? 0) * 100).toFixed(1)}%`;
//
// function buildPrompt(primary, secondary) {
//   return `You are an academic analytics assistant. Provide a meaningful comparative analysis between two units. Focus only on differences, shared patterns, and targeted actions. Do NOT describe each unit in isolation.
//
// Unit A: ${primary.unitCode}
// - Attendance: ${pct(primary.kpiData.attendanceRate)}, Engagement: ${pct(primary.kpiData.engagementScore)}, Risk score: ${pct(primary.kpiData.avgRiskScore)}
// - Students: ${primary.kpiData.totalStudents}, Late: ${primary.kpiData.totalLateArrival}, Early out: ${primary.kpiData.totalEarlyDeparture}
// - Risk breakdown: ${pct(primary.riskData.highRiskRate)} high, ${pct(primary.riskData.mediumRiskRate)} medium, ${pct(primary.riskData.lowRiskRate)} low
//
// Unit B: ${secondary.unitCode}
// - Attendance: ${pct(secondary.kpiData.attendanceRate)}, Engagement: ${pct(secondary.kpiData.engagementScore)}, Risk score: ${pct(secondary.kpiData.avgRiskScore)}
// - Students: ${secondary.kpiData.totalStudents}, Late: ${secondary.kpiData.totalLateArrival}, Early out: ${secondary.kpiData.totalEarlyDeparture}
// - Risk breakdown: ${pct(secondary.riskData.highRiskRate)} high, ${pct(secondary.riskData.mediumRiskRate)} medium, ${pct(secondary.riskData.lowRiskRate)} low
//
// Return ONLY a valid JSON object. Do not include markdown, comments, explanations, or extra text.
// {
//   "keyDifferences": ["string", "string"],
//   "concernUnit": "unit code",
//   "concernReason": "string",
//   "sharedIssues": ["string"],
//   "recommendations": [
//     { "unit": "${primary.unitCode}", "action": "string" },
//     { "unit": "${secondary.unitCode}", "action": "string" },
//     { "unit": "Both", "action": "string" }
//   ]
// }`;
// }
//
// function extractJson(text) {
//   const cleaned = text.replace(/```json|```/g, "").trim();
//   const start = cleaned.indexOf("{");
//   const end = cleaned.lastIndexOf("}");
//
//   if (start === -1 || end === -1) {
//     throw new Error("AI response did not contain JSON");
//   }
//
//   return cleaned.slice(start, end + 1);
// }
//
// export default function AIComparisonInsightPanel({ primary, secondary }) {
//   const [state, setState] = useState("idle");
//   const [parsed, setParsed] = useState(null);
//   const [errorMsg, setErrorMsg] = useState("");
//
//   const generate = async () => {
//     setState("loading");
//     setParsed(null);
//     setErrorMsg("");
//
//     try {
//       const resp = await fetch("http://localhost:8080/api/gemini", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
// body: JSON.stringify({
//   contents: [
//     {
//       parts: [
//         {
//           text: buildPrompt(primary, secondary),
//         },
//       ],
//     },
//   ],
//   generationConfig: {
//     temperature: 0.2,
//     maxOutputTokens: 1000,
//     responseMimeType: "application/json",
//   },
// }),
//       });
//
//       const raw = await resp.text();
//       console.log("RAW GEMINI RESPONSE:", raw);
//
//       if (!resp.ok) {
//         throw new Error(`API error ${resp.status}: ${raw}`);
//       }
//
//       const data = JSON.parse(raw);
//
//       const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
//
//       if (!text) {
//         throw new Error(`Empty AI response. Raw response: ${raw}`);
//       }
//
// console.log("GEMINI TEXT:", text);
//
//       const jsonText = extractJson(text);
//       const result = JSON.parse(jsonText);
//
//       setParsed(result);
//       setState("done");
//     } catch (err) {
//       setErrorMsg(err.message || "Something went wrong");
//       setState("error");
//     }
//   };
//
//   return (
//     <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl shadow-sm p-6">
//       <h2 className="text-xs font-semibold uppercase tracking-widest text-gray-400 dark:text-gray-500 mb-1">
//         Comparison Analysis
//       </h2>
//
//       <span className="inline-flex items-center gap-1 text-[11px] font-medium text-[#748DAE] bg-[#748DAE]/10 border border-[#748DAE]/30 rounded-full px-2 py-0.5 mb-4">
//         ✦ AI-powered
//       </span>
//
//       {state === "idle" && (
//         <div>
//           <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
//             Generate a meaningful cross-unit comparison — not just per-class descriptions.
//           </p>
//
//           <button
//             onClick={generate}
//             className="text-sm font-medium px-4 py-2 rounded-lg border border-gray-200 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
//           >
//             Generate comparative analysis
//           </button>
//         </div>
//       )}
//
//       {state === "loading" && (
//         <p className="text-sm text-gray-400 animate-pulse">
//           Analysing both units together…
//         </p>
//       )}
//
//       {state === "error" && (
//         <div>
//           <p className="text-sm text-red-500 mb-3">Failed: {errorMsg}</p>
//
//           <button
//             onClick={generate}
//             className="text-sm text-gray-500 underline"
//           >
//             Try again
//           </button>
//         </div>
//       )}
//
//       {state === "done" && parsed && (
//         <div className="space-y-5">
//           <div>
//             <h3 className="text-sm font-semibold text-gray-900 dark:text-white mb-3">
//               Key differences
//             </h3>
//
//             <div className="space-y-3">
//               {parsed.keyDifferences?.map((d, i) => (
//                 <div
//                   key={i}
//                   className="rounded-xl border border-[#9ECAD6] bg-[#9ECAD6]/10 p-4 text-sm leading-6 text-gray-700 dark:text-gray-200"
//                 >
//                   {d}
//                 </div>
//               ))}
//             </div>
//           </div>
//
//           {parsed.concernUnit && (
//             <div>
//               <h3 className="text-sm font-semibold text-gray-900 dark:text-white mb-3">
//                 Unit needing more attention
//               </h3>
//
//               <div className="rounded-xl border border-[#F5CBCB] bg-[#F5CBCB]/20 p-4 text-sm leading-6 text-gray-700 dark:text-gray-200">
//                 <span className="font-semibold">{parsed.concernUnit}</span> —{" "}
//                 {parsed.concernReason}
//               </div>
//             </div>
//           )}
//
//           {parsed.sharedIssues?.length > 0 && (
//             <div>
//               <h3 className="text-sm font-semibold text-gray-900 dark:text-white mb-3">
//                 Shared challenges
//               </h3>
//
//               <div className="space-y-3">
//                 {parsed.sharedIssues.map((s, i) => (
//                   <div
//                     key={i}
//                     className="rounded-xl border border-[#748DAE] bg-[#748DAE]/10 p-4 text-sm leading-6 text-gray-700 dark:text-gray-200"
//                   >
//                     {s}
//                   </div>
//                 ))}
//               </div>
//             </div>
//           )}
//
//           {parsed.recommendations?.length > 0 && (
//             <div>
//               <h3 className="text-sm font-semibold text-gray-900 dark:text-white mb-3">
//                 Targeted recommendations
//               </h3>
//
//               <div className="space-y-3">
//                 {parsed.recommendations.map((rec, i) => {
//                   const isA = rec.unit === primary.unitCode;
//                   const isBoth = rec.unit === "Both";
//                   const accent = isA ? "#9ECAD6" : isBoth ? "#aaa" : "#748DAE";
//
//                   return (
//                     <div
//                       key={i}
//                       className="rounded-xl p-4 text-sm leading-6 text-gray-700 dark:text-gray-200"
//                       style={{
//                         border: `1px solid ${accent}40`,
//                         background: `${accent}12`,
//                       }}
//                     >
//                       <span
//                         className="block text-[11px] font-semibold uppercase tracking-wide mb-1"
//                         style={{ color: accent }}
//                       >
//                         {rec.unit}
//                       </span>
//
//                       {rec.action}
//                     </div>
//                   );
//                 })}
//               </div>
//             </div>
//           )}
//
//           <button
//             onClick={generate}
//             className="text-xs text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 underline transition-colors"
//           >
//             Regenerate
//           </button>
//         </div>
//       )}
//     </div>
//   );
// }

import { useState } from "react";
import { UPLOAD_TYPES } from "../constants/ExcelType";
import FormatInfo from "../components/upload/FormatInfo";
import UploadCard from "../components/upload/UploadCard";

export default function AdminUpload() {
    const [selectedType, setSelectedType] = useState(null);
    const [file, setFile] = useState(null);
    const [message, setMessage] = useState("");
    const [isError, setIsError] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [dragOver, setDragOver] = useState(false);

    const active = UPLOAD_TYPES.find((t) => t.id === selectedType);

    const handleSelect = (id) => {
        setSelectedType(id);
        setFile(null);
        setMessage("");
        setIsError(false);
    };

    const handleFileChange = (e) => {
        const f = e.target.files[0];
        if (f) {
            setFile(f);
            setMessage("");
            setIsError(false);
        }
    };

    const handleDrop = (e) => {
        e.preventDefault();
        setDragOver(false);
        const f = e.dataTransfer.files[0];
        if (f && (f.name.endsWith(".xlsx") || f.name.endsWith(".xls"))) {
            setFile(f);
            setMessage("");
            setIsError(false);
        }
    };

    const handleUpload = async () => {
        if (!active) return;
        if (!file) {
            alert(active.alertMsg);
            return;
        }

        const formData = new FormData();
        formData.append("file", file);
        setIsLoading(true);
        setMessage("");

        try {
            const response = await fetch(active.endpoint, {
                method: "POST",
                body: formData,
            });
            const data = await response.json();
            setMessage(data.message || "Upload successful");
            setIsError(false);
        } catch (error) {
            console.error(error);
            setMessage("Upload failed. Please try again.");
            setIsError(true);
        } finally {
            setIsLoading(false);
        }
    };

    const clearFile = () => {
        setFile(null);
        setMessage("");
        setIsError(false);
    };

    return (
        <div className="min-h-screen bg-[#f5f6f8] dark:bg-[#0f172a] px-6 py-8 md:px-10 md:py-10">
            <div className="mx-auto max-w-4xl">
                {/* Page header */}
                <div className="mb-10">
                    <div className="inline-flex items-center rounded-full bg-[#e8edf3] dark:bg-[#1e293b] px-3 py-1 text-xs font-medium text-[#5f748b] dark:text-[#93a8bf]">
                        Admin Upload
                    </div>

                    <h1 className="mt-4 text-3xl font-bold tracking-tight text-[#374151] dark:text-[#e5e7eb]">
                        Upload Data Files
                    </h1>

                    <p className="mt-2 max-w-2xl text-sm leading-6 text-[#6b7280] dark:text-[#94a3b8]">
                        Choose the dataset type, check the expected file naming format,
                        and upload your Excel file in one flow.
                    </p>
                </div>

                {/* Main canvas */}
                <div className="rounded-[32px] overflow-hidden border border-[#e5e7eb] dark:border-[#0f172a] bg-white dark:bg-[#1e293b] shadow-[0_20px_50px_rgba(0,0,0,0.05)]">
                    <div className="grid gap-0 lg:grid-cols-[1.1fr_0.9fr]">
                        {/* Left side */}
                        <section className="p-6 md:p-8">
                            <div className="mb-6 flex items-center gap-3">
                                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#e8edf3] dark:bg-[#334155] text-sm font-bold text-[#5f748b] dark:text-[#cbd5e1]">
                                    1
                                </div>
                                <div>
                                    <h2 className="text-sm font-semibold text-[#374151] dark:text-[#e5e7eb]">
                                        Choose upload type
                                    </h2>
                                    <p className="text-xs text-[#9ca3af] dark:text-[#94a3b8]">
                                        Select the data category before uploading
                                    </p>
                                </div>
                            </div>

                            <div className="space-y-3">
                                {UPLOAD_TYPES.map((type) => (
                                    <UploadCard
                                        key={type.id}
                                        type={type}
                                        isActive={selectedType === type.id}
                                        onClick={() => handleSelect(type.id)}
                                    />
                                ))}
                            </div>

                            {active && (
                                <div className="mt-5">
                                    <FormatInfo type={active} />
                                </div>
                            )}
                        </section>

                        {/* Right side */}
                        <section
                            className="border-t border-[#eef1f4] dark:border-[#334155] bg-[#fafbfc] dark:bg-[#111827] p-6 md:p-8 lg:border-l lg:border-t-0"
                            style={{
                                opacity: active ? 1 : 0.58,
                                pointerEvents: active ? "auto" : "none",
                            }}
                        >
                            <div className="mb-6 flex items-center gap-3">
                                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#e8edf3] dark:bg-[#334155] text-sm font-bold text-[#5f748b] dark:text-[#cbd5e1]">
                                    2
                                </div>
                                <div>
                                    <h2 className="text-sm font-semibold text-[#374151] dark:text-[#e5e7eb]">
                                        {active ? `Upload ${active.label} file` : "Upload your file"}
                                    </h2>
                                    <p className="text-xs text-[#9ca3af] dark:text-[#94a3b8]">
                                        Drag and drop or browse from your device
                                    </p>
                                </div>
                            </div>

                            {active && (
                                <div
                                    className="mb-4 rounded-2xl px-4 py-3 text-xs"
                                    style={{
                                        background: `${active.accent}10`,
                                        border: `1px dashed ${active.accent}55`,
                                        color: active.accent,
                                    }}
                                >
                                    <div className="flex items-start gap-2">
                                        <svg
                                            viewBox="0 0 20 20"
                                            fill="currentColor"
                                            className="mt-0.5 h-3.5 w-3.5 shrink-0"
                                        >
                                            <path
                                                fillRule="evenodd"
                                                d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z"
                                                clipRule="evenodd"
                                            />
                                        </svg>
                                        <span>
                                            Expected filename:{" "}
                                            <code className="font-mono font-semibold">
                                                {active.expectedFilename}
                                            </code>
                                            {active.filenamePattern && (
                                                <span className="ml-1 text-[#9ca3af] dark:text-[#94a3b8]">
                                                    — replace placeholders with actual values
                                                </span>
                                            )}
                                        </span>
                                    </div>
                                </div>
                            )}

                            {!file ? (
                                <label
                                    htmlFor="file-input"
                                    onDragOver={(e) => {
                                        e.preventDefault();
                                        setDragOver(true);
                                    }}
                                    onDragLeave={() => setDragOver(false)}
                                    onDrop={handleDrop}
                                    style={{
                                        border: `2px dashed ${dragOver && active ? active.accent : "#d1d5db"}`,
                                        background:
                                            dragOver && active
                                                ? active.accentLight
                                                : undefined,
                                        transition: "all 0.15s",
                                        cursor: active ? "pointer" : "default",
                                    }}
                                    className="flex min-h-[250px] flex-col items-center justify-center gap-3 rounded-[28px] border-[#d1d5db] bg-white dark:bg-[#0f172a] px-6 py-10"
                                >
                                    <svg
                                        viewBox="0 0 24 24"
                                        fill="none"
                                        stroke={active?.accent || "#9ca3af"}
                                        strokeWidth={1.5}
                                        className="h-10 w-10"
                                    >
                                        <path
                                            d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                                            strokeLinecap="round"
                                            strokeLinejoin="round"
                                        />
                                    </svg>

                                    <span className="text-center text-sm font-medium text-[#4b5563] dark:text-[#cbd5e1]">
                                        Drag & drop your Excel file here, or{" "}
                                        <span
                                            style={{ color: active?.accent || "#6b8cae" }}
                                            className="font-semibold"
                                        >
                                            browse
                                        </span>
                                    </span>

                                    <span className="text-xs text-[#9ca3af] dark:text-[#94a3b8]">
                                        .xlsx files only
                                    </span>

                                    <input
                                        id="file-input"
                                        type="file"
                                        accept=".xlsx,.xls"
                                        onChange={handleFileChange}
                                        className="hidden"
                                    />
                                </label>
                            ) : (
                                <div
                                    style={{
                                        border: `1.5px solid ${active?.accent || "#6366f1"}22`,
                                        background: active?.accentLight || "#eef2ff",
                                    }}
                                    className="flex items-center justify-between rounded-[24px] px-4 py-4 dark:bg-[#1e293b]"
                                >
                                    <div className="flex items-center gap-3">
                                        <svg
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            stroke={active?.accent || "#6366f1"}
                                            strokeWidth={1.8}
                                            className="h-7 w-7 shrink-0"
                                        >
                                            <path
                                                d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                                                strokeLinecap="round"
                                                strokeLinejoin="round"
                                            />
                                        </svg>

                                        <div>
                                            <div className="max-w-xs truncate text-sm font-semibold text-[#374151] dark:text-[#e5e7eb]">
                                                {file.name}
                                            </div>
                                            <div className="text-xs text-[#9ca3af] dark:text-[#94a3b8]">
                                                {(file.size / 1024).toFixed(1)} KB
                                            </div>
                                        </div>
                                    </div>

                                    <button
                                        onClick={clearFile}
                                        className="ml-4 text-[#9ca3af] transition-colors hover:text-red-500"
                                    >
                                        <svg viewBox="0 0 20 20" fill="currentColor" className="h-5 w-5">
                                            <path
                                                fillRule="evenodd"
                                                d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                                clipRule="evenodd"
                                            />
                                        </svg>
                                    </button>
                                </div>
                            )}

                            <button
                                onClick={handleUpload}
                                disabled={!file || isLoading}
                                className="mt-5 flex w-full items-center justify-center gap-2 rounded-2xl py-3 text-sm font-semibold text-white transition-all duration-200"
                                style={{
                                    background: file && !isLoading ? (active?.accent || "#6366f1") : "#d1d5db",
                                    cursor: file && !isLoading ? "pointer" : "not-allowed",
                                    boxShadow:
                                        file && !isLoading
                                            ? `0 6px 18px ${active?.accent || "#6366f1"}33`
                                            : "none",
                                }}
                            >
                                {isLoading ? (
                                    <>
                                        <svg
                                            className="h-4 w-4 animate-spin"
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            stroke="currentColor"
                                            strokeWidth={2}
                                        >
                                            <path
                                                d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"
                                                strokeLinecap="round"
                                            />
                                        </svg>
                                        Uploading...
                                    </>
                                ) : (
                                    <>
                                        <svg
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            stroke="currentColor"
                                            strokeWidth={2}
                                            className="h-4 w-4"
                                        >
                                            <path
                                                d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"
                                                strokeLinecap="round"
                                                strokeLinejoin="round"
                                            />
                                        </svg>
                                        Upload File
                                    </>
                                )}
                            </button>

                            {message && (
                                <div
                                    className="mt-4 flex items-center gap-2 rounded-2xl px-4 py-3 text-sm font-medium"
                                    style={{
                                        background: isError ? "#fef2f2" : "#f0fdf4",
                                        color: isError ? "#dc2626" : "#16a34a",
                                        border: `1px solid ${isError ? "#fecaca" : "#bbf7d0"}`,
                                    }}
                                >
                                    {isError ? (
                                        <svg viewBox="0 0 20 20" fill="currentColor" className="h-4 w-4 shrink-0">
                                            <path
                                                fillRule="evenodd"
                                                d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z"
                                                clipRule="evenodd"
                                            />
                                        </svg>
                                    ) : (
                                        <svg viewBox="0 0 20 20" fill="currentColor" className="h-4 w-4 shrink-0">
                                            <path
                                                fillRule="evenodd"
                                                d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                                                clipRule="evenodd"
                                            />
                                        </svg>
                                    )}
                                    {message}
                                </div>
                            )}
                        </section>
                    </div>
                </div>
            </div>
        </div>
    );
}

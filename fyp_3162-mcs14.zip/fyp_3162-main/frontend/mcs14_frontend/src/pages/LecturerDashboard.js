import { useEffect, useState } from "react";
import { queryAllUnitCodes, queryFilterData } from "../api/controller/DashboardApi";
import UnitFilter from "../components/dashboard/UnitFilters";
import DashboardFilters from "../components/dashboard/DashboardFilters";
import DashboardCharts from "../components/dashboard/DashboardCharts";
import KPICard from "../components/common/KpiCard";
import StatCard from "../components/common/StatCard";
import ComparisonKPICard from "../components/common/ComparisonKpiCard";
import UnitComparisonInsightsPanel from "../pages/UnitComparisonInsightsPanel";
import { useAuth } from "../api/context/AuthContext";
import {
    KPI_TOOLTIPS,
    STAT_TOOLTIPS,
    CHART_TOOLTIPS,
} from "../constants/dashboardTooltips";
import InfoTooltip from "../components/common/InfoTooltip";


const DEFAULT_KPI = {
    attendanceRate: 0,
    engagementScore: 0,
    totalStudents: 0,
    avgRiskScore: 0,
    highRiskCount: 0,
    totalLateArrival: 0,
    totalEarlyDeparture: 0,
};

const DEFAULT_RISK_DISTRIBUTION = {
    highRiskCount: 0,
    highRiskRate: 0,
    lowRiskCount: 0,
    lowRiskRate: 0,
    mediumRiskCount: 0,
    mediumRiskRate: 0,
};

const normalizeSummary = (summary, fallbackUnitCode = "") => ({
    unitCode: summary?.unitCode || fallbackUnitCode,

    weeklyData: (summary?.weeklyData || []).map((w) => ({
        week: w?.week ?? "",
        attendanceRate: w?.attendanceRate ?? 0,
        engagement: w?.avgEngagementScore ?? 0,
        absent: w?.totalAbsence ?? 0,
        attendance: w?.totalAttendance ?? 0,
        early: w?.totalEarlyDeparture ?? 0,
        late: w?.totalLateArrival ?? 0,
        risk: w?.avgRiskScore ?? 0,
    })),

    kpiData: {
        attendanceRate: summary?.kpi?.avgAttendanceRate ?? 0,
        engagementScore: summary?.kpi?.avgEngagementScore ?? 0,
        totalStudents: summary?.kpi?.totalStudents ?? 0,
        avgRiskScore: summary?.kpi?.avgRiskScore ?? 0,
        highRiskCount: summary?.kpi?.highRiskCount ?? 0,
        totalLateArrival: summary?.kpi?.totalLateArrival ?? 0,
        totalEarlyDeparture: summary?.kpi?.totalEarlyDeparture ?? 0,
    },

    riskData: {
        highRiskCount: summary?.riskDistribution?.highRiskCount ?? 0,
        highRiskRate: summary?.riskDistribution?.highRiskRate ?? 0,
        lowRiskCount: summary?.riskDistribution?.lowRiskCount ?? 0,
        lowRiskRate: summary?.riskDistribution?.lowRiskRate ?? 0,
        mediumRiskCount: summary?.riskDistribution?.mediumRiskCount ?? 0,
        mediumRiskRate: summary?.riskDistribution?.mediumRiskRate ?? 0,
    },

    analyticalExplanations:
        summary?.analyticalExplanations?.map(item => ({
            category: item.category,
            message: item.message,
        })) || [],

    recommendations:
        summary?.recommendations?.map(item => ({
            category: item.category,
            message: item.message,
        })) || [],

    insights:
        summary?.insights?.map(item => ({
            category: item.category,
            message: item.message,
        })) || [],
});


export default function LecturerDashboard() {
    const { dashboardState, setDashboardState } = useAuth();

    const [units, setUnits] = useState(dashboardState?.units || []);
    const [selectedUnits, setSelectedUnits] = useState(dashboardState?.selectedUnits || []);
    const [appliedUnits, setAppliedUnits] = useState(dashboardState?.appliedUnits || []);
    const [comparisonData, setComparisonData] = useState(dashboardState?.comparisonData || []);
    const [weekStart, setWeekStart] = useState(dashboardState?.weekStart ?? 1);
    const [weekEnd, setWeekEnd] = useState(dashboardState?.weekEnd ?? 10);
    const [year, setYear] = useState(dashboardState?.year || "2025");
    const [semester, setSemester] = useState(dashboardState?.semester || "S1");
    const [loading, setLoading] = useState(false);

    const isComparisonMode = appliedUnits.length === 2 && comparisonData.length >= 2;

    const primary = comparisonData[0] || {
        unitCode: appliedUnits[0] || "",
        weeklyData: [],
        kpiData: DEFAULT_KPI,
        riskData: DEFAULT_RISK_DISTRIBUTION,
        analyticalExplanations: [],
        recommendations: [],
        insights: [],
    };

    const secondary = comparisonData[1] || {
        unitCode: appliedUnits[1] || "",
        weeklyData: [],
        kpiData: DEFAULT_KPI,
        riskData: DEFAULT_RISK_DISTRIBUTION,
        analyticalExplanations: [],
        recommendations: [],
        insights: [],
    };

    console.log(primary);

    useEffect(() => {
        if (dashboardState?.units?.length > 0) return;

        queryAllUnitCodes()
            .then((unitArray) => {
                const fetchedUnits = unitArray || [];
                setUnits(fetchedUnits);

                if (fetchedUnits.length > 0 && selectedUnits.length === 0) {
                    setSelectedUnits([fetchedUnits[0]]);
                }
            })
            .catch((err) => console.error("Failed to fetch units:", err));
    }, []);

    useEffect(() => {
        setDashboardState({
            units,
            selectedUnits,
            appliedUnits,
            comparisonData,
            weekStart,
            weekEnd,
            year,
            semester,
        });
    }, [
        units,
        selectedUnits,
        appliedUnits,
        comparisonData,
        weekStart,
        weekEnd,
        year,
        semester,
        setDashboardState,
    ]);

    const orderSummaryList = (summaryList, chosenUnits) => {
        if (!Array.isArray(summaryList)) return [];

        const usedIndexes = new Set();
        const ordered = [];

        chosenUnits.forEach((unit) => {
            const index = summaryList.findIndex(
                (summary, i) =>
                    !usedIndexes.has(i) &&
                    (summary?.unitCode === unit || summary?.unit?.code === unit)
            );

            if (index !== -1) {
                usedIndexes.add(index);
                ordered.push(summaryList[index]);
            }
        });

        summaryList.forEach((summary, i) => {
            if (!usedIndexes.has(i)) ordered.push(summary);
        });

        return ordered;
    };

    const fetchDashboardData = async (unitsToQuery = selectedUnits) => {
        if (!unitsToQuery || unitsToQuery.length === 0) {
            setComparisonData([]);
            return;
        }

        try {
            setLoading(true);

            const body = await queryFilterData({
                unitCodeList: unitsToQuery,
                weekStart,
                weekEnd,
                year,
                semester,
            });

            console.log("Dashboard query result", {
                selectedUnits: unitsToQuery,
                weekStart,
                weekEnd,
                year,
                semester,
                body,
            });

            const rawSummaryList = body?.unitOverviewList || [];

            if (rawSummaryList.length === 0) {
                setComparisonData([]);
                return;
            }

            const orderedSummaryList = orderSummaryList(rawSummaryList, unitsToQuery);

            const mapped = orderedSummaryList.slice(0, 2).map((summary, index) =>
                normalizeSummary(summary, unitsToQuery[index] || `Unit ${index + 1}`)
            );

            setComparisonData(mapped);
        } catch (err) {
            console.error("Failed to fetch dashboard data:", err);
            setComparisonData([]);
        } finally {
            setLoading(false);
        }
    };

    const handleApplyFilter = () => {
        setAppliedUnits([...selectedUnits]);
        fetchDashboardData(selectedUnits);
    };

    return (
        <main className="min-h-screen bg-gray-50 dark:bg-gray-900">
            <div className="flex">
                <aside
                    className="print-hide hidden md:flex flex-col w-56 shrink-0 min-h-screen
                               bg-white dark:bg-gray-800
                               border-r border-gray-200 dark:border-gray-700
                               px-4 py-8 gap-6"
                >
                    <p className="text-xs font-semibold uppercase tracking-widest text-gray-400 dark:text-gray-500">
                        Filters
                    </p>

                    <UnitFilter
                        units={units}
                        selectedUnits={selectedUnits}
                        onChange={setSelectedUnits}
                    />

                    <DashboardFilters
                        weekStart={weekStart}
                        weekEnd={weekEnd}
                        year={year}
                        semester={semester}
                        onWeekStartChange={setWeekStart}
                        onWeekEndChange={setWeekEnd}
                        onYearChange={setYear}
                        onSemesterChange={setSemester}
                        onApplyFilter={handleApplyFilter}
                    />
                </aside>

                <div className="flex-1 px-6 py-8 min-w-0">
                    <div className="mb-8">
                        <h1 className="text-2xl font-semibold text-gray-900 dark:text-white tracking-tight">
                            Class Overview
                        </h1>

                        {appliedUnits.length > 0 && (
                            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                                {appliedUnits.length === 2
                                    ? `${appliedUnits[0]} vs ${appliedUnits[1]}`
                                    : appliedUnits[0]}
                            </p>
                        )}
                    </div>

                    {loading && (
                        <div className="print-hide">
                            <div className="mb-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
                                {[...Array(4)].map((_, i) => (
                                    <div
                                        key={i}
                                        className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow animate-pulse"
                                    >
                                        <div className="h-3 w-24 bg-gray-200 dark:bg-gray-700 rounded mb-4"></div>
                                        <div className="h-8 w-20 bg-gray-300 dark:bg-gray-600 rounded"></div>
                                    </div>
                                ))}
                            </div>

                            <div className="mb-8 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                                {[...Array(4)].map((_, i) => (
                                    <div
                                        key={i}
                                        className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow animate-pulse"
                                    >
                                        <div className="h-3 w-20 bg-gray-200 dark:bg-gray-700 rounded mb-3"></div>
                                        <div className="h-5 w-12 bg-gray-300 dark:bg-gray-600 rounded"></div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {!loading && comparisonData.length === 0 && (
                        <div
                            className="bg-white dark:bg-gray-800 border border-gray-200
                                       dark:border-gray-700 rounded-xl px-4 py-6 text-sm
                                       text-gray-500 dark:text-gray-300"
                        >
                            No dashboard data found for the selected filter.
                        </div>
                    )}

                    {!loading && comparisonData.length > 0 && !isComparisonMode && (
                        <>
                            <div className="print-kpi mb-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <KPICard
                                    title="Avg Attendance Rate"
                                    value={`${((primary.kpiData?.attendanceRate ?? 0) * 100).toFixed(1)}%`}
                                    accent="bg-[#9ECAD6]"
                                    tooltip={KPI_TOOLTIPS.attendanceRate}
                                />
                                <KPICard
                                    title="Avg Engagement Score"
                                    value={`${((primary.kpiData?.engagementScore ?? 0) * 100).toFixed(1)}%`}
                                    accent="bg-[#748DAE]"
                                    tooltip={KPI_TOOLTIPS.engagementScore}
                                />
                                <KPICard
                                    title="Avg Risk Score"
                                    value={`${((primary.kpiData?.avgRiskScore ?? 0) * 100).toFixed(1)}%`}
                                    accent="bg-[#F5CBCB]"
                                    tooltip={KPI_TOOLTIPS.avgRiskScore}
                                />
                                <KPICard
                                    title="% High-Risk Students"
                                    value={`${((primary.riskData?.highRiskRate ?? 0) * 100).toFixed(1)}%`}
                                    accent="bg-[#FFEAEA]"
                                    tooltip={KPI_TOOLTIPS.highRiskRate}
                                />
                            </div>

                            <div className="print-stats mb-8 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                            <StatCard
                                title="Total Students"
                                value={primary.kpiData?.totalStudents ?? 0}
                                tooltip={STAT_TOOLTIPS.totalStudents}
                            />

                            <StatCard
                                title="Late Arrivals"
                                value={primary.kpiData?.totalLateArrival ?? 0}
                                tooltip={STAT_TOOLTIPS.lateArrivals}
                            />

                            <StatCard
                                title="Early Departures"
                                value={primary.kpiData?.totalEarlyDeparture ?? 0}
                                tooltip={STAT_TOOLTIPS.earlyDepartures}
                            />

                            <StatCard
                                title="High-Risk Count"
                                value={primary.riskData?.highRiskCount ?? 0}
                                tooltip={STAT_TOOLTIPS.highRiskCount}
                            />
                            </div>

                            <div
                                className="print-charts bg-white dark:bg-gray-800
                                           border border-gray-200 dark:border-gray-700
                                           rounded-xl shadow-sm p-6"
                            >
                            <div className="flex items-center gap-2 mb-6">
                                <h2 className="text-xs font-semibold uppercase tracking-widest text-gray-400 dark:text-gray-500">
                                    Weekly Breakdown
                                </h2>
                                <InfoTooltip content={CHART_TOOLTIPS.weeklyBreakdown} />
                            </div>
                                <DashboardCharts mode="single" unitA={primary} />
                            </div>

                        </>
                    )}

                    {!loading && isComparisonMode && (
                        <>
                            <div className="print-kpi mb-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <ComparisonKPICard
                                    title="Avg Attendance Rate"
                                    leftLabel={primary.unitCode}
                                    leftValue={`${((primary.kpiData?.attendanceRate ?? 0) * 100).toFixed(1)}%`}
                                    rightLabel={secondary.unitCode}
                                    rightValue={`${((secondary.kpiData?.attendanceRate ?? 0) * 100).toFixed(1)}%`}
                                    accent="bg-[#9ECAD6]"
                                    tooltip={KPI_TOOLTIPS.attendanceRate}
                                />
                                <ComparisonKPICard
                                    title="Avg Engagement Score"
                                    leftLabel={primary.unitCode}
                                    leftValue={`${((primary.kpiData?.engagementScore ?? 0) * 100).toFixed(1)}%`}
                                    rightLabel={secondary.unitCode}
                                    rightValue={`${((secondary.kpiData?.engagementScore ?? 0) * 100).toFixed(1)}%`}
                                    accent="bg-[#748DAE]"
                                    tooltip={KPI_TOOLTIPS.avgEngagementScore}
                                />
                                <ComparisonKPICard
                                    title="Avg Risk Score"
                                    leftLabel={primary.unitCode}
                                    leftValue={`${((primary.kpiData?.avgRiskScore ?? 0) * 100).toFixed(1)}%`}
                                    rightLabel={secondary.unitCode}
                                    rightValue={`${((secondary.kpiData?.avgRiskScore ?? 0) * 100).toFixed(1)}%`}
                                    accent="bg-[#F5CBCB]"
                                    tooltip={KPI_TOOLTIPS.avgRiskScore}
                                />
                                <ComparisonKPICard
                                    title="% High-Risk Students"
                                    leftLabel={primary.unitCode}
                                    leftValue={`${((primary.riskData?.highRiskRate ?? 0) * 100).toFixed(1)}%`}
                                    rightLabel={secondary.unitCode}
                                    rightValue={`${((secondary.riskData?.highRiskRate ?? 0) * 100).toFixed(1)}%`}
                                    accent="bg-[#FFEAEA]"
                                    tooltip={KPI_TOOLTIPS.highRiskRate}
                                />
                            </div>

                            <div className="print-stats mb-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                                <ComparisonKPICard
                                    title="Total Students"
                                    leftLabel={primary.unitCode}
                                    leftValue={primary.kpiData?.totalStudents ?? 0}
                                    rightLabel={secondary.unitCode}
                                    rightValue={secondary.kpiData?.totalStudents ?? 0}
                                    tooltip={STAT_TOOLTIPS.totalStudents}
                                />
                                <ComparisonKPICard
                                    title="Late Arrivals"
                                    leftLabel={primary.unitCode}
                                    leftValue={primary.kpiData?.totalLateArrival ?? 0}
                                    rightLabel={secondary.unitCode}
                                    rightValue={secondary.kpiData?.totalLateArrival ?? 0}
                                    tooltip={STAT_TOOLTIPS.lateArrivals}
                                />
                                <ComparisonKPICard
                                    title="Early Departures"
                                    leftLabel={primary.unitCode}
                                    leftValue={primary.kpiData?.totalEarlyDeparture ?? 0}
                                    rightLabel={secondary.unitCode}
                                    rightValue={secondary.kpiData?.totalEarlyDeparture ?? 0}
                                    tooltip={STAT_TOOLTIPS.earlyDepartures}
                                />
                                <ComparisonKPICard
                                    title="High-Risk Count"
                                    leftLabel={primary.unitCode}
                                    leftValue={primary.riskData?.highRiskCount ?? 0}
                                    rightLabel={secondary.unitCode}
                                    rightValue={secondary.riskData?.highRiskCount ?? 0}
                                    tooltip={STAT_TOOLTIPS.highRiskCount}
                                />
                            </div>

                            <div
                                className="print-charts bg-white dark:bg-gray-800
                                           border border-gray-200 dark:border-gray-700
                                           rounded-xl shadow-sm p-6"
                            >
                                <h2 className="text-xs font-semibold uppercase tracking-widest text-gray-400 dark:text-gray-500 mb-6">
                                    Weekly Comparison
                                </h2>

                                <DashboardCharts
                                    mode="comparison"
                                    unitA={primary}
                                    unitB={secondary}
                                />
                            </div>
                            <div className="xl:col-span-2">
                                <UnitComparisonInsightsPanel primary={primary} secondary={secondary} />
                            </div>

                        </>
                    )}
                </div>
            </div>
        </main>
    );
}

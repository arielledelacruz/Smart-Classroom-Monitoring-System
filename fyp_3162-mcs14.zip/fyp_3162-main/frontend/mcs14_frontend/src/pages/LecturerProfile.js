import { useState, useEffect } from "react";
import { Camera } from "lucide-react";
import { useAuth } from "../api/context/AuthContext";
import { uploadProfilePhoto } from "../api/controller/LecturerProfileApi";

export default function LecturerProfile() {
    const { authUser } = useAuth();

    const defaultAvatar =
        "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0nMTIwJyBoZWlnaHQ9JzEyMCcgeG1sbnM9J2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJz48Y2lyY2xlIGN4PSc2MCcgY3k9JzQwJyByPSczMCcgZmlsbD0nI2Q5ZDlkaScvPjxjaXJjbGUgY3g9JzYwJyBjeT0nMzAnIHI9JzE1JyBmaWxsPScjYzJjMmMyJy8+PHJlY3QgeD0nMzUnIHk9JzY1JyB3aWR0aD0nNTAuNScgaGVpZ2h0PSczNScgcng9JzEwJyBmaWxsPScjYjBiMGIwJy8+PC9zdmc+";

    const [profileImage, setProfileImage] = useState(defaultAvatar);

    useEffect(() => {
        if (authUser?.photoUrl) {
            setProfileImage(authUser.photoUrl);
        }
    }, [authUser]);

    const handleImageChange = (e) => {
        const file = e.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = () => setProfileImage(reader.result);
        reader.readAsDataURL(file);

        uploadProfilePhoto(authUser?.id, file);
    };

    return (
        <div className="min-h-screen bg-[#f5f6f8] dark:bg-[#0f172a] px-6 py-10">
            <div className="max-w-4xl mx-auto">
                <div className="bg-white dark:bg-[#1e293b] border border-[#e5e7eb] dark:border-[#0f172a] rounded-2xl shadow-sm">

                    <div className="p-8">
                        {/* Header */}
                        <div className="flex flex-col md:flex-row md:items-center gap-6 pb-8 border-b border-[#e5e7eb] dark:border-[#334155]">

                            <div className="relative w-fit mx-auto md:mx-0">
                                <img
                                    src={profileImage}
                                    alt="Profile"
                                    className="w-28 h-28 rounded-full object-cover border-4 border-[#e8edf3] dark:border-[#334155]"
                                />

                                <label className="absolute bottom-0 right-0 flex items-center justify-center w-9 h-9 rounded-full bg-[#5f748b] hover:bg-[#4b5f73] text-white cursor-pointer transition">
                                    <Camera size={16} />
                                    <input
                                        type="file"
                                        accept="image/*"
                                        className="hidden"
                                        onChange={handleImageChange}
                                    />
                                </label>
                            </div>

                            <div className="flex-1 text-center md:text-left">
                                <h1 className="text-2xl font-semibold text-[#374151] dark:text-[#e5e7eb]">
                                    {authUser?.name || "-"}
                                </h1>

                                <p className="mt-1 text-[#6b7280] dark:text-[#94a3b8]">
                                    {authUser?.faculty || "-"}
                                </p>

                                <p className="mt-1 text-sm text-[#5f748b] dark:text-[#93a8bf] font-medium">
                                    {authUser?.userRole || "-"}
                                </p>
                            </div>
                        </div>

                        {/* Info Section */}
                        <div className="pt-8">
                            <h2 className="text-lg font-semibold text-[#374151] dark:text-[#e5e7eb] mb-6">
                                Profile Information
                            </h2>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

                                <div>
                                    <p className="text-sm text-[#9ca3af] dark:text-[#94a3b8]">Email</p>
                                    <p className="mt-1 text-base text-[#374151] dark:text-[#e5e7eb] break-words">
                                        {authUser?.email || "-"}
                                    </p>
                                </div>

                                <div>
                                    <p className="text-sm text-[#9ca3af] dark:text-[#94a3b8]">Office</p>
                                    <p className="mt-1 text-base text-[#374151] dark:text-[#e5e7eb]">
                                        {authUser?.office || "-"}
                                    </p>
                                </div>

                                <div>
                                    <p className="text-sm text-[#9ca3af] dark:text-[#94a3b8]">Phone</p>
                                    <p className="mt-1 text-base text-[#374151] dark:text-[#e5e7eb]">
                                        {authUser?.phone || "-"}
                                    </p>
                                </div>

                                <div>
                                    <p className="text-sm text-[#9ca3af] dark:text-[#94a3b8]">Research Area</p>
                                    <p className="mt-1 text-base text-[#374151] dark:text-[#e5e7eb]">
                                        {authUser?.researchArea || "-"}
                                    </p>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    );
}

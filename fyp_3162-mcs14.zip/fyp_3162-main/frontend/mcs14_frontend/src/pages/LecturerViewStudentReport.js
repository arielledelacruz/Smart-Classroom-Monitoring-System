import { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { MessageCircle } from "lucide-react";
import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    Tooltip,
    CartesianGrid,
    ResponsiveContainer,
    Legend,
    LineChart,
    Line,
} from "recharts";
import {
    getUnitAttendanceDetail,
    getStudentAnalytics,
} from "../api/controller/StudentApi";
import { fetchAllUnitCodesForStudentReport } from "../api/controller/StudentReportApi";
import { useAuth } from "../api/context/AuthContext";
import StudentFeedbackModal from "../components/dashboard/StudentFeedbackModal";

export default function LecturerViewStudentReport() {
    const navigate = useNavigate();
    const { state } = useLocation();
    const { authUser } = useAuth();

    const [feedbackModalOpen, setFeedbackModalOpen] = useState(false);
    const [feedbackUnitCode, setFeedbackUnitCode] = useState("");

    const studentId = state?.studentId || "";
    const studentName = state?.name || "Student";
    const profilePhotoUrl = state?.profilePhotoUrl || null;

    const initialMode = state?.mode === "compare" ? "compare" : "single";
    const initialUnitCode = state?.unitCode || state?.selectedUnit || "";
    const initialYear = state?.year || "2025";
    const initialSemester = state?.semester || "S1";

    const [mode, setMode] = useState(initialMode);
    const [year, setYear] = useState(initialYear);
    const [semester, setSemester] = useState(initialSemester);

    const [availableUnits, setAvailableUnits] = useState(state?.availableUnits || []);
    const [singleUnit, setSingleUnit] = useState(initialUnitCode);

    const [compareUnitA, setCompareUnitA] = useState(
        state?.compareUnitA || initialUnitCode || ""
    );
    const [compareUnitB, setCompareUnitB] = useState(
        state?.compareUnitB ||
            (state?.availableUnits || []).find((u) => u !== initialUnitCode) ||
            ""
    );

    const [singleAttendanceDetail, setSingleAttendanceDetail] = useState(null);
    const [singleAnalytics, setSingleAnalytics] = useState(null);

    const [compareReportA, setCompareReportA] = useState({
        attendanceDetail: null,
        analytics: null,
    });
    const [compareReportB, setCompareReportB] = useState({
        attendanceDetail: null,
        analytics: null,
    });

    const [loading, setLoading] = useState(true);
    const [compareLoading, setCompareLoading] = useState(false);
    const [error, setError] = useState("");

    useEffect(() => {
        const loadUnits = async () => {
            if ((state?.availableUnits || []).length > 0) return;

            try {
                const unitArray = await fetchAllUnitCodesForStudentReport();
                const safeUnits = unitArray || [];
                setAvailableUnits(safeUnits);

                if (!singleUnit && safeUnits.length > 0) {
                    setSingleUnit(initialUnitCode || safeUnits[0]);
                }

                if (!compareUnitA && safeUnits.length > 0) {
                    setCompareUnitA(initialUnitCode || safeUnits[0]);
                }

                if (!compareUnitB && safeUnits.length > 1) {
                    const other = safeUnits.find((u) => u !== (initialUnitCode || safeUnits[0])) || "";
                    setCompareUnitB(other);
                }
            } catch (err) {
                console.error("Failed to load units:", err);
            }
        };

        loadUnits();
    }, [state, singleUnit, compareUnitA, compareUnitB, initialUnitCode]);

    useEffect(() => {
        const fetchSingleData = async () => {
            if (mode !== "single") return;

            if (!studentId || !singleUnit || !year || !semester) {
                setError("Missing student or unit information.");
                setLoading(false);
                return;
            }

            try {
                setLoading(true);
                setError("");

                const [attendanceRes, analyticsRes] = await Promise.all([
                    getUnitAttendanceDetail(studentId, singleUnit, year, semester),
                    getStudentAnalytics(studentId, singleUnit, year, semester),
                ]);

                setSingleAttendanceDetail(attendanceRes || null);
                setSingleAnalytics(analyticsRes || null);
            } catch (err) {
                console.error("Failed to load student report:", err);
                setError("Failed to load student report.");
            } finally {
                setLoading(false);
            }
        };

        fetchSingleData();
    }, [mode, studentId, singleUnit, year, semester]);

    useEffect(() => {
        const fetchCompareData = async () => {
            if (mode !== "compare") return;

            if (!studentId || !compareUnitA || !compareUnitB || !year || !semester) {
                setError("Missing comparison information.");
                setCompareLoading(false);
                return;
            }

            if (compareUnitA === compareUnitB) {
                setError("Please choose two different units for comparison.");
                setCompareLoading(false);
                return;
            }

            try {
                setCompareLoading(true);
                setError("");

                const [
                    attendanceA,
                    analyticsA,
                    attendanceB,
                    analyticsB,
                ] = await Promise.all([
                    getUnitAttendanceDetail(studentId, compareUnitA, year, semester),
                    getStudentAnalytics(studentId, compareUnitA, year, semester),
                    getUnitAttendanceDetail(studentId, compareUnitB, year, semester),
                    getStudentAnalytics(studentId, compareUnitB, year, semester),
                ]);

                setCompareReportA({
                    attendanceDetail: attendanceA || null,
                    analytics: analyticsA || null,
                });

                setCompareReportB({
                    attendanceDetail: attendanceB || null,
                    analytics: analyticsB || null,
                });
            } catch (err) {
                console.error("Failed to load comparison report:", err);
                setError("Failed to load comparison report.");
            } finally {
                setCompareLoading(false);
            }
        };

        fetchCompareData();
    }, [mode, studentId, compareUnitA, compareUnitB, year, semester]);

    const student = useMemo(() => {
        return {
            id: studentId || "-",
            name: studentName,
            profilePhotoUrl,
            year: year || "-",
            semester: semester || "-",
        };
    }, [studentId, studentName, profilePhotoUrl, year, semester]);

    const buildSummary = (attendanceDetail, analytics, fallbackUnit) => {
        const attendanceRate = Number(
            analytics?.attendanceRate ?? attendanceDetail?.attendanceRate ?? 0
        );
        const engagementScore = Number(
            analytics?.engagementScore ?? attendanceDetail?.engagementScore ?? 0
        );
        const effectivePresence = Number(analytics?.effectivePresence ?? 0);
        const consecutiveAbsences = Number(
            analytics?.consecutiveAbsences ??
                attendanceDetail?.consecutiveAbsences ??
                0
        );
        const riskScore = Number(
            analytics?.riskScore ?? attendanceDetail?.riskScore ?? 0
        );
        const clusterLabel =
            analytics?.clusterLabel ?? attendanceDetail?.clusterLabel ?? "-";
        const trend = attendanceDetail?.trend ?? "-";
        const unitCode = attendanceDetail?.unitCode || fallbackUnit || "-";

        return {
            unitCode,
            attendanceRate,
            engagementScore,
            effectivePresence,
            consecutiveAbsences,
            riskScore,
            clusterLabel,
            trend,
        };
    };

    const singleSummary = useMemo(() => {
        return buildSummary(singleAttendanceDetail, singleAnalytics, singleUnit);
    }, [singleAttendanceDetail, singleAnalytics, singleUnit]);

    const summaryA = useMemo(() => {
        return buildSummary(
            compareReportA.attendanceDetail,
            compareReportA.analytics,
            compareUnitA
        );
    }, [compareReportA, compareUnitA]);

    const summaryB = useMemo(() => {
        return buildSummary(
            compareReportB.attendanceDetail,
            compareReportB.analytics,
            compareUnitB
        );
    }, [compareReportB, compareUnitB]);

    const normalizeWeeklyChart = (attendanceDetail) => {
        return (attendanceDetail?.weeklyBreakdown || [])
            .map((w, index) => ({
                week: w?.week || `W${index + 1}`,
                present: w?.present ? "Yes" : "No",
                lateArrival: w?.lateArrival ? "Yes" : "No",
                earlyDeparture: w?.earlyDeparture ? "Yes" : "No",
                attendance: w?.present ? 1 : 0,
                engagementScore: Number(((w?.engagementScore ?? 0) * 100).toFixed(2)),
                presenceQuality: Number(((w?.presenceQuality ?? 0) * 100).toFixed(2)),
            }))
            .sort((a, b) => {
                const numA = parseInt(String(a.week).replace(/[^\d]/g, ""), 10) || 0;
                const numB = parseInt(String(b.week).replace(/[^\d]/g, ""), 10) || 0;
                return numA - numB;
            });
    };

    const singleWeeklyChart = useMemo(() => {
        return normalizeWeeklyChart(singleAttendanceDetail);
    }, [singleAttendanceDetail]);

    const weeklyChartA = useMemo(() => {
        return normalizeWeeklyChart(compareReportA.attendanceDetail);
    }, [compareReportA]);

    const weeklyChartB = useMemo(() => {
        return normalizeWeeklyChart(compareReportB.attendanceDetail);
    }, [compareReportB]);

    const singleInsights = singleAnalytics?.insights || [];
    const insightsA = compareReportA?.analytics?.insights || [];
    const insightsB = compareReportB?.analytics?.insights || [];

    const comparisonMetricRows = useMemo(() => {
        return [
            {
                label: "Attendance Rate",
                a: summaryA.attendanceRate,
                b: summaryB.attendanceRate,
                diff: summaryA.attendanceRate - summaryB.attendanceRate,
                format: "decimal3",
            },
            {
                label: "Engagement Score",
                a: summaryA.engagementScore,
                b: summaryB.engagementScore,
                diff: summaryA.engagementScore - summaryB.engagementScore,
                format: "decimal3",
            },
            {
                label: "Effective Presence %",
                a: summaryA.effectivePresence * 100,
                b: summaryB.effectivePresence * 100,
                diff: summaryA.effectivePresence * 100 - summaryB.effectivePresence * 100,
                format: "percent2raw",
            },
            {
                label: "Consecutive Absences",
                a: summaryA.consecutiveAbsences,
                b: summaryB.consecutiveAbsences,
                diff: summaryA.consecutiveAbsences - summaryB.consecutiveAbsences,
                format: "int",
            },
            {
                label: "Risk Score %",
                a: summaryA.riskScore * 100,
                b: summaryB.riskScore * 100,
                diff: summaryA.riskScore * 100 - summaryB.riskScore * 100,
                format: "percent2raw",
            },
        ];
    }, [summaryA, summaryB]);

    const comparisonChartData = useMemo(() => {
        return [
            {
                metric: "Attendance",
                [summaryA.unitCode]: Number((summaryA.attendanceRate * 100).toFixed(2)),
                [summaryB.unitCode]: Number((summaryB.attendanceRate * 100).toFixed(2)),
            },
            {
                metric: "Engagement",
                [summaryA.unitCode]: Number((summaryA.engagementScore * 100).toFixed(2)),
                [summaryB.unitCode]: Number((summaryB.engagementScore * 100).toFixed(2)),
            },
            {
                metric: "Presence",
                [summaryA.unitCode]: Number((summaryA.effectivePresence * 100).toFixed(2)),
                [summaryB.unitCode]: Number((summaryB.effectivePresence * 100).toFixed(2)),
            },
            {
                metric: "Risk",
                [summaryA.unitCode]: Number((summaryA.riskScore * 100).toFixed(2)),
                [summaryB.unitCode]: Number((summaryB.riskScore * 100).toFixed(2)),
            },
        ];
    }, [summaryA, summaryB]);

    const mergedWeeklyComparison = useMemo(() => {
        const map = new Map();

        weeklyChartA.forEach((w) => {
            map.set(w.week, {
                week: w.week,
                [`${summaryA.unitCode}_attendance`]: w.attendance,
                [`${summaryA.unitCode}_engagement`]: w.engagementScore,
                [`${summaryA.unitCode}_presence`]: w.presenceQuality,
                [`${summaryA.unitCode}_lateArrival`]: w.lateArrival,
                [`${summaryA.unitCode}_earlyDeparture`]: w.earlyDeparture,
            });
        });

        weeklyChartB.forEach((w) => {
            const existing = map.get(w.week) || { week: w.week };
            map.set(w.week, {
                ...existing,
                [`${summaryB.unitCode}_attendance`]: w.attendance,
                [`${summaryB.unitCode}_engagement`]: w.engagementScore,
                [`${summaryB.unitCode}_presence`]: w.presenceQuality,
                [`${summaryB.unitCode}_lateArrival`]: w.lateArrival,
                [`${summaryB.unitCode}_earlyDeparture`]: w.earlyDeparture,
            });
        });

        return Array.from(map.values()).sort((a, b) => {
            const numA = parseInt(String(a.week).replace(/[^\d]/g, ""), 10) || 0;
            const numB = parseInt(String(b.week).replace(/[^\d]/g, ""), 10) || 0;
            return numA - numB;
        });
    }, [weeklyChartA, weeklyChartB, summaryA.unitCode, summaryB.unitCode]);

    const handlePrint = () => {
        window.print();
    };

    const formatMetric = (value, format) => {
        if (format === "decimal3") return Number(value ?? 0).toFixed(3);
        if (format === "percent2raw") return Number(value ?? 0).toFixed(2);
        if (format === "int") return String(Number(value ?? 0));
        return String(value ?? "-");
    };

    const renderStudentCard = () => (
        <div className="bg-white dark:bg-gray-700 rounded-2xl shadow p-6">
            <div className="flex items-center gap-4 mb-4">
                {student.profilePhotoUrl ? (
                    <img
                        src={student.profilePhotoUrl}
                        alt={student.name}
                        className="w-16 h-16 rounded-full object-cover"
                    />
                ) : (
                    <div className="w-16 h-16 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center text-2xl font-bold text-blue-600 dark:text-blue-300">
                        {student.name?.charAt(0) || "S"}
                    </div>
                )}

                <div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Student</p>
                    <p className="text-lg font-semibold dark:text-white">{student.name}</p>
                </div>
            </div>

            <div className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
                <div><span className="font-semibold">Student ID:</span> {student.id}</div>
                <div><span className="font-semibold">Semester:</span> {student.semester}</div>
                <div><span className="font-semibold">Year:</span> {student.year}</div>
                <div><span className="font-semibold">Mode:</span> {mode === "single" ? "Single Report" : "Compare Units"}</div>
            </div>
        </div>
    );

    const renderModeControl = () => (
        <div className="bg-white dark:bg-gray-700 rounded-2xl shadow p-4 mb-6">
            <div className="flex flex-col lg:flex-row lg:items-end gap-4">
                <div>
                    <p className="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-2">
                        Report Mode
                    </p>
                    <div className="inline-flex rounded-xl overflow-hidden border border-gray-200 dark:border-gray-600">
                        <button
                            type="button"
                            onClick={() => setMode("single")}
                            className={`px-4 py-2 text-sm font-medium ${
                                mode === "single"
                                    ? "bg-blue-600 text-white"
                                    : "bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200"
                            }`}
                        >
                            Single Report
                        </button>
                        <button
                            type="button"
                            onClick={() => setMode("compare")}
                            className={`px-4 py-2 text-sm font-medium ${
                                mode === "compare"
                                    ? "bg-blue-600 text-white"
                                    : "bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200"
                            }`}
                        >
                            Compare Units
                        </button>
                    </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 flex-1">
                    <div>
                        <label className="block text-sm text-gray-500 dark:text-gray-400 mb-1">
                            Year
                        </label>
                        <input
                            type="text"
                            value={year}
                            onChange={(e) => setYear(e.target.value)}
                            className="w-full px-3 py-2 rounded-xl border border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-100"
                        />
                    </div>

                    <div>
                        <label className="block text-sm text-gray-500 dark:text-gray-400 mb-1">
                            Semester
                        </label>
                        <select
                            value={semester}
                            onChange={(e) => setSemester(e.target.value)}
                            className="w-full px-3 py-2 rounded-xl border border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-100"
                        >
                            <option value="S1">S1</option>
                            <option value="S2">S2</option>
                            <option value="Summer">Summer</option>
                        </select>
                    </div>

                    {mode === "single" ? (
                        <div className="sm:col-span-2">
                            <label className="block text-sm text-gray-500 dark:text-gray-400 mb-1">
                                Unit
                            </label>
                            <select
                                value={singleUnit}
                                onChange={(e) => setSingleUnit(e.target.value)}
                                className="w-full px-3 py-2 rounded-xl border border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-100"
                            >
                                {availableUnits.map((u) => (
                                    <option key={u} value={u}>
                                        {u}
                                    </option>
                                ))}
                            </select>
                        </div>
                    ) : (
                        <>
                            <div>
                                <label className="block text-sm text-gray-500 dark:text-gray-400 mb-1">
                                    Unit A
                                </label>
                                <select
                                    value={compareUnitA}
                                    onChange={(e) => setCompareUnitA(e.target.value)}
                                    className="w-full px-3 py-2 rounded-xl border border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-100"
                                >
                                    {availableUnits.map((u) => (
                                        <option key={u} value={u}>
                                            {u}
                                        </option>
                                    ))}
                                </select>
                            </div>

                            <div>
                                <label className="block text-sm text-gray-500 dark:text-gray-400 mb-1">
                                    Unit B
                                </label>
                                <select
                                    value={compareUnitB}
                                    onChange={(e) => setCompareUnitB(e.target.value)}
                                    className="w-full px-3 py-2 rounded-xl border border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-100"
                                >
                                    {availableUnits.map((u) => (
                                        <option key={u} value={u}>
                                            {u}
                                        </option>
                                    ))}
                                </select>
                            </div>
                        </>
                    )}
                </div>
            </div>
        </div>
    );

    const renderSingleSummaryCards = () => (
        <div className="lg:col-span-3 grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
                {
                    title: "Attendance Rate",
                    value: `${singleSummary.attendanceRate.toFixed(3)}`,
                },
                {
                    title: "Engagement Score",
                    value: `${singleSummary.engagementScore.toFixed(3)}`,
                },
                {
                    title: "Risk Status",
                    value: singleSummary.clusterLabel,
                    highlight: singleSummary.clusterLabel === "At Risk",
                },
            ].map((card) => (
                <div
                    key={card.title}
                    className={`rounded-2xl shadow p-6 ${
                        card.highlight
                            ? "bg-red-50 dark:bg-red-900/20"
                            : "bg-white dark:bg-gray-700"
                    }`}
                >
                    <p className={`text-sm ${card.highlight ? "text-red-600 dark:text-red-300" : "text-gray-500 dark:text-gray-400"}`}>
                        {card.title}
                    </p>
                    <p className={`text-2xl font-semibold mt-2 ${card.highlight ? "text-red-600 dark:text-red-300" : "dark:text-white"}`}>
                        {card.value}
                    </p>
                </div>
            ))}
        </div>
    );

    const formatPercent = (value) => `${(Number(value ?? 0) * 100).toFixed(1)}%`;

    const renderRiskBreakdownAndExplanations = (analytics, unitCode = "") => (
      <div className="bg-white dark:bg-gray-700 rounded-2xl shadow p-6 mt-6">
        <h2 className="text-xl font-semibold dark:text-white mb-4">
          Risk Breakdown & Lecturer Recommendations {unitCode ? `— ${unitCode}` : ""}
        </h2>

        <div className="space-y-6">
          {analytics?.riskBreakdown && (
            <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl p-4">
              <p className="text-sm font-semibold text-red-800 dark:text-red-200 mb-3">
                Risk Breakdown
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {Object.entries(analytics.riskBreakdown).map(([key, value]) => (
                  <div
                    key={key}
                    className="flex justify-between rounded-lg bg-white dark:bg-gray-800 px-3 py-2"
                  >
                    <span className="text-sm capitalize text-gray-600 dark:text-gray-300">
                      {key.replace(/([A-Z])/g, " $1")}
                    </span>
                    <span className="text-sm font-semibold text-gray-900 dark:text-white">
                      {formatPercent(value)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {analytics?.explanations?.length > 0 && (
            <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-xl p-4">
              <p className="text-sm font-semibold text-blue-800 dark:text-blue-200 mb-3">
                Explanation & Lecturer Action
              </p>

              <div className="space-y-4">
                {analytics.explanations.map((item, index) => (
                  <div
                    key={index}
                    className="rounded-xl border border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 p-4"
                  >
                    <div className="flex items-start justify-between gap-3 mb-3">
                      <div>
                        <h3 className="font-semibold text-gray-900 dark:text-white">
                          {item.metricName}
                        </h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Value:{" "}
                          {typeof item.value === "number" && item.value <= 1
                            ? formatPercent(item.value)
                            : item.value}
                        </p>
                      </div>

                      <span className="px-3 py-1 rounded-full text-xs font-semibold bg-gray-100 text-gray-700 dark:bg-gray-600 dark:text-gray-200">
                        {item.status}
                      </span>
                    </div>

                    {item.meaning && (
                      <p className="text-sm text-gray-700 dark:text-gray-300 mb-3">
                        {item.meaning}
                      </p>
                    )}

                    {item.contributingFactor && (
                      <div className="mb-3 rounded-lg bg-gray-50 dark:bg-gray-700/50 p-3">
                        <p className="text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                          Contributing Factor
                        </p>
                        <p className="mt-1 text-sm text-gray-700 dark:text-gray-300">
                          {item.contributingFactor}
                        </p>
                      </div>
                    )}

                    {item.recommendationForLecturer && (
                      <div className="rounded-lg bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800 p-3">
                        <p className="text-xs font-semibold uppercase tracking-wide text-emerald-700 dark:text-emerald-300">
                          Lecturer Recommendation
                        </p>
                        <p className="mt-1 text-sm text-gray-700 dark:text-gray-300">
                          {item.recommendationForLecturer}
                        </p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    );

    const renderSingleView = () => {
        if (loading) {
            return (
                <div className="bg-white dark:bg-gray-700 rounded-2xl shadow p-6">
                    <p className="text-gray-700 dark:text-gray-200">Loading student report...</p>
                </div>
            );
        }

        return (
            <>
                <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-6">
                    {renderStudentCard()}

                    {renderSingleSummaryCards()}
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                    <div className="bg-white dark:bg-gray-700 rounded-2xl shadow p-6">
                        <div className="flex items-center justify-between mb-4">
                            <h2 className="text-xl font-semibold dark:text-white">Attendance Pattern</h2>
                            <span className="text-sm text-gray-500 dark:text-gray-400">
                                Weekly overview
                            </span>
                        </div>
                        <div className="h-72">
                            <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={singleWeeklyChart}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="week" />
                                    <YAxis allowDecimals={false} domain={[0, 1]} />
                                    <Tooltip />
                                    <Legend />
                                    <Bar dataKey="attendance" name="Present" fill="#2563eb" />
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                    </div>

                    <div className="bg-white dark:bg-gray-700 rounded-2xl shadow p-6">
                        <h2 className="text-xl font-semibold dark:text-white mb-4">Engagement Trend</h2>
                        <div className="h-72">
                            <ResponsiveContainer width="100%" height="100%">
                                <LineChart data={singleWeeklyChart}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="week" />
                                    <YAxis domain={[0, 100]} />
                                    <Tooltip />
                                    <Line
                                        type="monotone"
                                        dataKey="engagementScore"
                                        stroke="#ef4444"
                                        strokeWidth={3}
                                        dot={false}
                                    />
                                </LineChart>
                            </ResponsiveContainer>
                        </div>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div className="bg-white dark:bg-gray-700 rounded-2xl shadow p-6">
                        <h2 className="text-xl font-semibold dark:text-white mb-4">Presence Quality</h2>
                        <div className="h-72">
                            <ResponsiveContainer width="100%" height="100%">
                                <LineChart data={singleWeeklyChart}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="week" />
                                    <YAxis domain={[0, 100]} />
                                    <Tooltip />
                                    <Line
                                        type="monotone"
                                        dataKey="presenceQuality"
                                        stroke="#f59e0b"
                                        strokeWidth={3}
                                        dot={false}
                                    />
                                </LineChart>
                            </ResponsiveContainer>
                        </div>
                    </div>

                    <div className="bg-white dark:bg-gray-700 rounded-2xl shadow p-6">
                        <h2 className="text-xl font-semibold dark:text-white mb-4">
                            Arrival & Departure Issues
                        </h2>
                        <div className="space-y-2">
                            {singleWeeklyChart.length === 0 ? (
                                <p className="text-gray-500 dark:text-gray-400">
                                    No weekly data available.
                                </p>
                            ) : (
                                singleWeeklyChart.map((w, i) => (
                                    <div
                                        key={i}
                                        className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-600 rounded-lg"
                                    >
                                        <span className="text-sm font-medium dark:text-white">
                                            {w.week}
                                        </span>
                                        <div className="flex gap-2">
                                            {w.lateArrival === "Yes" && (
                                                <span className="px-2 py-1 text-xs bg-yellow-100 text-yellow-800 rounded dark:bg-yellow-900 dark:text-yellow-200">
                                                    Late
                                                </span>
                                            )}
                                            {w.earlyDeparture === "Yes" && (
                                                <span className="px-2 py-1 text-xs bg-orange-100 text-orange-800 rounded dark:bg-orange-900 dark:text-orange-200">
                                                    Early Dep.
                                                </span>
                                            )}
                                            {w.lateArrival === "No" && w.earlyDeparture === "No" && (
                                                <span className="px-2 py-1 text-xs bg-green-100 text-green-800 rounded dark:bg-green-900 dark:text-green-200">
                                                    On Time
                                                </span>
                                            )}
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                </div>

                <div className="bg-white dark:bg-gray-700 rounded-2xl shadow p-6 mt-6">
                    <h2 className="text-xl font-semibold dark:text-white mb-4">Session Summary</h2>
                    <table className="w-full text-sm">
                        <thead>
                            <tr className="text-left text-gray-500 dark:text-gray-400 border-b dark:border-gray-600">
                                <th className="pb-3">Week</th>
                                <th className="pb-3">Present?</th>
                                <th className="pb-3">Early Departure?</th>
                                <th className="pb-3">Late Arrival?</th>
                                <th className="pb-3">Engagement Score</th>
                            </tr>
                        </thead>
                        <tbody>
                            {singleWeeklyChart.map((w, i) => (
                                <tr key={i} className="border-b dark:border-gray-600 last:border-0">
                                    <td className="py-3 dark:text-white">{w.week}</td>
                                    <td className="py-3 dark:text-white">{w.present}</td>
                                    <td className="py-3 dark:text-white">{w.earlyDeparture}</td>
                                    <td className="py-3 dark:text-white">{w.lateArrival}</td>
                                    <td className="py-3 dark:text-white">{w.engagementScore}%</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>

                <div className="bg-white dark:bg-gray-700 rounded-2xl shadow p-6 mt-6">
                    <h2 className="text-xl font-semibold dark:text-white mb-4">Analytics Summary</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-xl p-4">
                            <p className="text-sm font-semibold text-yellow-800 dark:text-yellow-200 mb-1">
                                Attendance Trend
                            </p>
                            <p className="text-gray-700 dark:text-gray-300">
                                Trend: {singleSummary.trend}
                            </p>
                        </div>

                        <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-xl p-4">
                            <p className="text-sm font-semibold text-green-800 dark:text-green-200 mb-1">
                                Effective Presence %
                            </p>
                            <p className="text-gray-700 dark:text-gray-300">
                                {(singleSummary.effectivePresence * 100).toFixed(2)}
                            </p>
                        </div>

                        <div className="bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800 rounded-xl p-4">
                            <p className="text-sm font-semibold text-orange-800 dark:text-orange-200 mb-1">
                                Consecutive Absences
                            </p>
                            <p className="text-gray-700 dark:text-gray-300">
                                {singleSummary.consecutiveAbsences}
                            </p>
                        </div>

                        <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl p-4">
                            <p className="text-sm font-semibold text-red-800 dark:text-red-200 mb-1">
                                Risk Score %
                            </p>
                            <p className="text-gray-700 dark:text-gray-300">
                                {(singleSummary.riskScore * 100).toFixed(2)}
                            </p>
                        </div>
                    </div>
                </div>

                {renderRiskBreakdownAndExplanations(singleAnalytics, singleSummary.unitCode)}

                <div className="bg-white dark:bg-gray-700 rounded-2xl shadow p-6 mt-6">
                    <h2 className="text-xl font-semibold dark:text-white mb-4">Personalized Insights</h2>
                    <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-xl p-4">
                        {singleInsights.length > 0 ? (
                            <ul className="list-disc pl-5 space-y-2 text-gray-700 dark:text-gray-300">
                                {singleInsights.map((item, index) => (
                                    <li key={index}>{item}</li>
                                ))}
                            </ul>
                        ) : (
                            <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
                                No personalized notes available for this student yet.
                            </p>
                        )}
                    </div>
                </div>
            </>
        );
    };

    const renderCompareSummaryCards = () => (
        <div className="lg:col-span-3 grid grid-cols-1 md:grid-cols-2 gap-4">
            {[summaryA, summaryB].map((item) => (
                <div
                    key={item.unitCode}
                    className={`rounded-2xl shadow p-6 ${
                        item.clusterLabel === "At Risk"
                            ? "bg-red-50 dark:bg-red-900/20"
                            : "bg-white dark:bg-gray-700"
                    }`}
                >
                    <div className="flex items-center justify-between gap-4">
                        <div>
                            <p className="text-sm text-gray-500 dark:text-gray-400">Unit</p>
                            <p className="text-2xl font-semibold dark:text-white">{item.unitCode}</p>
                        </div>
                        <div
                            className={`px-3 py-1 rounded-full text-xs font-semibold ${
                                item.clusterLabel === "At Risk"
                                    ? "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300"
                                    : "bg-gray-100 text-gray-700 dark:bg-gray-600 dark:text-gray-200"
                            }`}
                        >
                            {item.clusterLabel}
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mt-5 text-sm">
                        <div className="bg-gray-50 dark:bg-gray-600 rounded-xl p-3">
                            <p className="text-gray-500 dark:text-gray-300">Attendance</p>
                            <p className="font-semibold text-gray-900 dark:text-white">
                                {item.attendanceRate.toFixed(3)}
                            </p>
                        </div>
                        <div className="bg-gray-50 dark:bg-gray-600 rounded-xl p-3">
                            <p className="text-gray-500 dark:text-gray-300">Engagement</p>
                            <p className="font-semibold text-gray-900 dark:text-white">
                                {item.engagementScore.toFixed(3)}
                            </p>
                        </div>
                        <div className="bg-gray-50 dark:bg-gray-600 rounded-xl p-3">
                            <p className="text-gray-500 dark:text-gray-300">Presence %</p>
                            <p className="font-semibold text-gray-900 dark:text-white">
                                {(item.effectivePresence * 100).toFixed(2)}
                            </p>
                        </div>
                        <div className="bg-gray-50 dark:bg-gray-600 rounded-xl p-3">
                            <p className="text-gray-500 dark:text-gray-300">Risk %</p>
                            <p className="font-semibold text-gray-900 dark:text-white">
                                {(item.riskScore * 100).toFixed(2)}
                            </p>
                        </div>
                    </div>
                </div>
            ))}
        </div>
    );

    const renderCompareView = () => {
        if (compareLoading) {
            return (
                <div className="bg-white dark:bg-gray-700 rounded-2xl shadow p-6">
                    <p className="text-gray-700 dark:text-gray-200">Loading comparison report...</p>
                </div>
            );
        }

        return (
            <>
                <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-6">
                    {renderStudentCard()}
                    {renderCompareSummaryCards()}
                </div>

                <div className="bg-white dark:bg-gray-700 rounded-2xl shadow p-6 mb-6">
                    <h2 className="text-xl font-semibold dark:text-white mb-4">
                        Comparison Metrics
                    </h2>

                    <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead>
                                <tr className="text-left text-gray-500 dark:text-gray-400 border-b dark:border-gray-600">
                                    <th className="pb-3">Metric</th>
                                    <th className="pb-3">{summaryA.unitCode}</th>
                                    <th className="pb-3">{summaryB.unitCode}</th>
                                    <th className="pb-3">Difference</th>
                                </tr>
                            </thead>
                            <tbody>
                                {comparisonMetricRows.map((row) => (
                                    <tr key={row.label} className="border-b dark:border-gray-600 last:border-0">
                                        <td className="py-3 dark:text-white font-medium">{row.label}</td>
                                        <td className="py-3 dark:text-white">{formatMetric(row.a, row.format)}</td>
                                        <td className="py-3 dark:text-white">{formatMetric(row.b, row.format)}</td>
                                        <td
                                            className={`py-3 font-semibold ${
                                                row.diff > 0
                                                    ? "text-emerald-600 dark:text-emerald-300"
                                                    : row.diff < 0
                                                    ? "text-red-600 dark:text-red-300"
                                                    : "text-gray-700 dark:text-gray-300"
                                            }`}
                                        >
                                            {row.diff > 0 ? "+" : ""}
                                            {formatMetric(row.diff, row.format)}
                                        </td>
                                    </tr>
                                ))}
                                <tr className="border-b dark:border-gray-600 last:border-0">
                                    <td className="py-3 dark:text-white font-medium">Risk Status</td>
                                    <td className="py-3 dark:text-white">{summaryA.clusterLabel}</td>
                                    <td className="py-3 dark:text-white">{summaryB.clusterLabel}</td>
                                    <td className="py-3 dark:text-white">—</td>
                                </tr>
                                <tr className="last:border-0">
                                    <td className="py-3 dark:text-white font-medium">Trend</td>
                                    <td className="py-3 dark:text-white">{summaryA.trend}</td>
                                    <td className="py-3 dark:text-white">{summaryB.trend}</td>
                                    <td className="py-3 dark:text-white">—</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                    <div className="bg-white dark:bg-gray-700 rounded-2xl shadow p-6">
                        <h2 className="text-xl font-semibold dark:text-white mb-4">
                            Summary Comparison
                        </h2>
                        <div className="h-80">
                            <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={comparisonChartData}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="metric" />
                                    <YAxis domain={[0, 100]} />
                                    <Tooltip />
                                    <Legend />
                                    <Bar dataKey={summaryA.unitCode} fill="#2563eb" />
                                    <Bar dataKey={summaryB.unitCode} fill="#f59e0b" />
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                    </div>

                    <div className="bg-white dark:bg-gray-700 rounded-2xl shadow p-6">
                        <h2 className="text-xl font-semibold dark:text-white mb-4">
                            Weekly Engagement Comparison
                        </h2>
                        <div className="h-80">
                            <ResponsiveContainer width="100%" height="100%">
                                <LineChart data={mergedWeeklyComparison}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="week" />
                                    <YAxis domain={[0, 100]} />
                                    <Tooltip />
                                    <Legend />
                                    <Line
                                        type="monotone"
                                        dataKey={`${summaryA.unitCode}_engagement`}
                                        name={`${summaryA.unitCode} Engagement`}
                                        stroke="#2563eb"
                                        strokeWidth={3}
                                    />
                                    <Line
                                        type="monotone"
                                        dataKey={`${summaryB.unitCode}_engagement`}
                                        name={`${summaryB.unitCode} Engagement`}
                                        stroke="#f59e0b"
                                        strokeWidth={3}
                                    />
                                </LineChart>
                            </ResponsiveContainer>
                        </div>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                    <div className="bg-white dark:bg-gray-700 rounded-2xl shadow p-6">
                        <h2 className="text-xl font-semibold dark:text-white mb-4">
                            Weekly Presence Quality Comparison
                        </h2>
                        <div className="h-80">
                            <ResponsiveContainer width="100%" height="100%">
                                <LineChart data={mergedWeeklyComparison}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="week" />
                                    <YAxis domain={[0, 100]} />
                                    <Tooltip />
                                    <Legend />
                                    <Line
                                        type="monotone"
                                        dataKey={`${summaryA.unitCode}_presence`}
                                        name={`${summaryA.unitCode} Presence`}
                                        stroke="#10b981"
                                        strokeWidth={3}
                                    />
                                    <Line
                                        type="monotone"
                                        dataKey={`${summaryB.unitCode}_presence`}
                                        name={`${summaryB.unitCode} Presence`}
                                        stroke="#ef4444"
                                        strokeWidth={3}
                                    />
                                </LineChart>
                            </ResponsiveContainer>
                        </div>
                    </div>

                    <div className="bg-white dark:bg-gray-700 rounded-2xl shadow p-6">
                        <h2 className="text-xl font-semibold dark:text-white mb-4">
                            Weekly Attendance Comparison
                        </h2>
                        <div className="h-80">
                            <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={mergedWeeklyComparison}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="week" />
                                    <YAxis domain={[0, 1]} allowDecimals={false} />
                                    <Tooltip />
                                    <Legend />
                                    <Bar
                                        dataKey={`${summaryA.unitCode}_attendance`}
                                        name={`${summaryA.unitCode} Present`}
                                        fill="#2563eb"
                                    />
                                    <Bar
                                        dataKey={`${summaryB.unitCode}_attendance`}
                                        name={`${summaryB.unitCode} Present`}
                                        fill="#f59e0b"
                                    />
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                    </div>
                </div>

                <div className="bg-white dark:bg-gray-700 rounded-2xl shadow p-6 mb-6">
                    <h2 className="text-xl font-semibold dark:text-white mb-4">
                        Weekly Comparison Table
                    </h2>

                    <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead>
                                <tr className="text-left text-gray-500 dark:text-gray-400 border-b dark:border-gray-600">
                                    <th className="pb-3">Week</th>
                                    <th className="pb-3">{summaryA.unitCode} Attendance</th>
                                    <th className="pb-3">{summaryB.unitCode} Attendance</th>
                                    <th className="pb-3">{summaryA.unitCode} Engagement</th>
                                    <th className="pb-3">{summaryB.unitCode} Engagement</th>
                                    <th className="pb-3">{summaryA.unitCode} Presence</th>
                                    <th className="pb-3">{summaryB.unitCode} Presence</th>
                                </tr>
                            </thead>
                            <tbody>
                                {mergedWeeklyComparison.map((row, i) => (
                                    <tr key={i} className="border-b dark:border-gray-600 last:border-0">
                                        <td className="py-3 dark:text-white">{row.week}</td>
                                        <td className="py-3 dark:text-white">
                                            {row[`${summaryA.unitCode}_attendance`] === 1 ? "Yes" : "No"}
                                        </td>
                                        <td className="py-3 dark:text-white">
                                            {row[`${summaryB.unitCode}_attendance`] === 1 ? "Yes" : "No"}
                                        </td>
                                        <td className="py-3 dark:text-white">
                                            {Number(row[`${summaryA.unitCode}_engagement`] ?? 0).toFixed(2)}%
                                        </td>
                                        <td className="py-3 dark:text-white">
                                            {Number(row[`${summaryB.unitCode}_engagement`] ?? 0).toFixed(2)}%
                                        </td>
                                        <td className="py-3 dark:text-white">
                                            {Number(row[`${summaryA.unitCode}_presence`] ?? 0).toFixed(2)}%
                                        </td>
                                        <td className="py-3 dark:text-white">
                                            {Number(row[`${summaryB.unitCode}_presence`] ?? 0).toFixed(2)}%
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                    {renderRiskBreakdownAndExplanations(compareReportA.analytics, summaryA.unitCode)}

                    {renderRiskBreakdownAndExplanations(compareReportB.analytics, summaryB.unitCode)}
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div className="bg-white dark:bg-gray-700 rounded-2xl shadow p-6">
                        <h2 className="text-xl font-semibold dark:text-white mb-4">
                            Insights — {summaryA.unitCode}
                        </h2>
                        <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-xl p-4">
                            {insightsA.length > 0 ? (
                                <ul className="list-disc pl-5 space-y-2 text-gray-700 dark:text-gray-300">
                                    {insightsA.map((item, index) => (
                                        <li key={index}>{item}</li>
                                    ))}
                                </ul>
                            ) : (
                                <p className="text-gray-700 dark:text-gray-300">
                                    No personalized notes available for this unit.
                                </p>
                            )}
                        </div>
                    </div>

                    <div className="bg-white dark:bg-gray-700 rounded-2xl shadow p-6">
                        <h2 className="text-xl font-semibold dark:text-white mb-4">
                            Insights — {summaryB.unitCode}
                        </h2>
                        <div className="bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800 rounded-xl p-4">
                            {insightsB.length > 0 ? (
                                <ul className="list-disc pl-5 space-y-2 text-gray-700 dark:text-gray-300">
                                    {insightsB.map((item, index) => (
                                        <li key={index}>{item}</li>
                                    ))}
                                </ul>
                            ) : (
                                <p className="text-gray-700 dark:text-gray-300">
                                    No personalized notes available for this unit.
                                </p>
                            )}
                        </div>
                    </div>
                </div>
            </>
        );
    };

    if (!studentId) {
        return (
            <div className="p-6 bg-gray-100 dark:bg-gray-800 min-h-screen">
                <div className="bg-white dark:bg-gray-700 rounded-2xl shadow p-6">
                    <button
                        type="button"
                        onClick={() => navigate(-1)}
                        className="mb-4 text-sm px-4 py-2 rounded-xl bg-gray-200 dark:bg-gray-600 text-gray-700 dark:text-gray-200"
                    >
                        ← Back
                    </button>
                    <p className="text-red-600 dark:text-red-300">
                        Missing student information. Please open this page from the student list.
                    </p>
                </div>
            </div>
        );
    }

    return (
        <div className="p-6 bg-gray-100 dark:bg-gray-800 min-h-screen">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
                <div>
                    <button
                        type="button"
                        onClick={() => navigate(-1)}
                        className="text-sm px-4 py-2 rounded-xl bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 shadow-sm"
                    >
                        ← Back to list
                    </button>
                </div>

                <div className="space-y-2 text-right">
                    <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
                        Student Report
                    </h1>
                    <p className="text-gray-500 dark:text-gray-400">
                        {student.name} • {student.id} • {student.year} {student.semester}
                    </p>
                </div>

                <button
                    type="button"
                    onClick={() => {
                        setFeedbackUnitCode(mode === "single" ? singleUnit : singleUnit || compareUnitA);
                        setFeedbackModalOpen(true);
                    }}
                    className="inline-flex items-center gap-2 justify-center px-5 py-3 rounded-xl bg-emerald-600 text-white hover:bg-emerald-700 shadow-sm"
                >
                    <MessageCircle size={18} />
                    Notes
                </button>

                <button
                    type="button"
                    onClick={handlePrint}
                    className="inline-flex items-center justify-center px-5 py-3 rounded-xl bg-blue-600 text-white hover:bg-blue-700 shadow-sm"
                >
                    Print / Save PDF
                </button>
            </div>

            {renderModeControl()}

            {error ? (
                <div className="bg-white dark:bg-gray-700 rounded-2xl shadow p-6">
                    <p className="text-red-600 dark:text-red-300">{error}</p>
                </div>
            ) : mode === "single" ? (
                renderSingleView()
            ) : (
                renderCompareView()
            )}

            {/* Personalised notes/feedback modal */}
            <StudentFeedbackModal
                isOpen={feedbackModalOpen}
                onClose={() => setFeedbackModalOpen(false)}
                studentId={studentId}
                studentName={studentName}
                unitCode={feedbackUnitCode}
                lecturerId={authUser?.userId || authUser?.id || ""}
            />
        </div>
    );
}

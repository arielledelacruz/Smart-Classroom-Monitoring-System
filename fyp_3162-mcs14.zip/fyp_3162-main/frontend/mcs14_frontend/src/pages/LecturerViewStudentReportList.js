import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { MessageCircle } from "lucide-react";
import {
    fetchAllUnitCodesForStudentReport,
    fetchStudentsByUnitSemester,
} from "../api/controller/StudentReportApi";
import UnitFilter from "../components/dashboard/UnitFilters2";
import DashboardFilters from "../components/dashboard/DashboardFilters2";
import { useAuth } from "../api/context/AuthContext";
import StudentFeedbackModal from "../components/dashboard/StudentFeedbackModal";

export default function StudentReportList() {
    const navigate = useNavigate();
    const { authUser, studentState, setStudentState } = useAuth();

    const [feedbackStudent, setFeedbackStudent] = useState(null);
    const [feedbackModalOpen, setFeedbackModalOpen] = useState(false);

    const handleOpenFeedback = (student) => {
        setFeedbackStudent(student);
        setFeedbackModalOpen(true);
    };

    const [units, setUnits] = useState(studentState?.units || []);
    const [selectedUnit, setSelectedUnit] = useState(studentState?.selectedUnit || "");
    const [students, setStudents] = useState(studentState?.students || []);
    const [year, setYear] = useState(studentState?.year || "2025");
    const [semester, setSemester] = useState(studentState?.semester || "S1");

    const [search, setSearch] = useState("");
    const [sortField, setSortField] = useState("studentId");
    const [sortAsc, setSortAsc] = useState(true);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (studentState?.units?.length > 0) return;

        fetchAllUnitCodesForStudentReport()
            .then((unitArray) => {
                setUnits(unitArray || []);
                if ((unitArray || []).length > 0) {
                    setSelectedUnit(unitArray[0]);
                }
            })
            .catch((err) => {
                console.error("Failed to fetch units:", err);
            });
    }, [studentState]);

    useEffect(() => {
        setStudentState({
            units,
            selectedUnit,
            students,
            year,
            semester,
        });
    }, [units, selectedUnit, students, year, semester, setStudentState]);

    const handleApplyFilter = () => {
        fetchStudentData();
    };

    const fetchStudentData = async () => {
        if (!selectedUnit || !year || !semester) return;

        try {
            setLoading(true);

            const body = await fetchStudentsByUnitSemester({
                unitCode: selectedUnit,
                year: Number(year),
                semester,
            });

            const studentList = (body?.students || []).map((s) => ({
                studentId: s?.id || "",
                name: s?.name || "Unknown Student",
                profilePhotoUrl: s?.profilePhotoUrl || null,
                engagementScore: Number(s?.engagementScore ?? 0),
                attendanceRate: Number(s?.attendanceRate ?? 0),
            }));

            setStudents(studentList);
        } catch (err) {
            console.error("Failed to fetch student data:", err);
            setStudents([]);
        } finally {
            setLoading(false);
        }
    };

    const displayed = useMemo(() => {
        return [...students]
            .filter((s) => {
                const keyword = search.toLowerCase();
                return (
                    (s.studentId || "").toLowerCase().includes(keyword) ||
                    (s.name || "").toLowerCase().includes(keyword)
                );
            })
            .sort((a, b) => {
                const va = a?.[sortField];
                const vb = b?.[sortField];

                if (typeof va === "string" || typeof vb === "string") {
                    const sa = String(va ?? "");
                    const sb = String(vb ?? "");
                    return sortAsc ? sa.localeCompare(sb) : sb.localeCompare(sa);
                }

                const na = Number(va ?? 0);
                const nb = Number(vb ?? 0);
                return sortAsc ? na - nb : nb - na;
            });
    }, [students, search, sortField, sortAsc]);

    const toggleSort = (field) => {
        if (sortField === field) {
            setSortAsc((prev) => !prev);
        } else {
            setSortField(field);
            setSortAsc(true);
        }
    };

    const SortIcon = ({ field }) =>
        sortField !== field ? (
            <span className="text-gray-300 dark:text-gray-600 ml-1">↕</span>
        ) : (
            <span className="text-blue-500 ml-1">{sortAsc ? "↑" : "↓"}</span>
        );

    const badgeColor = (rate) => {
        if (rate >= 0.8) {
            return "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-400";
        }
        if (rate >= 0.6) {
            return "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/40 dark:text-yellow-400";
        }
        return "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-400";
    };

    const buildStatePayload = (student) => ({
        studentId: student.studentId,
        name: student.name,
        profilePhotoUrl: student.profilePhotoUrl,
        unitCode: selectedUnit,
        year,
        semester,
        availableUnits: units,
    });

    const handleViewDetail = (student) => {
        navigate("/lecturerViewStudentReport", {
            state: {
                ...buildStatePayload(student),
                mode: "single",
            },
        });
    };

    const handleCompare = (student) => {
        const fallbackUnitB =
            units.find((u) => u !== selectedUnit) || "";

        navigate("/lecturerViewStudentReport", {
            state: {
                ...buildStatePayload(student),
                mode: "compare",
                compareUnitA: selectedUnit,
                compareUnitB: fallbackUnitB,
            },
        });
    };

    return (
        <div className="flex min-h-screen bg-gray-50 dark:bg-gray-900">
            <aside
                className="hidden md:flex flex-col w-56 shrink-0 min-h-screen
                           bg-white dark:bg-gray-800
                           border-r border-gray-200 dark:border-gray-700
                           px-4 py-8 gap-6"
            >
                <p
                    className="text-xs font-semibold uppercase tracking-widest
                               text-gray-400 dark:text-gray-500"
                >
                    Filters
                </p>

                <UnitFilter
                    units={units}
                    selectedUnit={selectedUnit}
                    onChange={setSelectedUnit}
                />

                <DashboardFilters
                    year={year}
                    semester={semester}
                    onYearChange={setYear}
                    onSemesterChange={setSemester}
                    onApplyFilter={handleApplyFilter}
                />
            </aside>

            <div className="flex-1 px-6 py-8 min-w-0">
                <div className="mb-6">
                    <h1 className="text-2xl font-semibold text-gray-900 dark:text-white tracking-tight">
                        Student List
                    </h1>
                    {selectedUnit && (
                        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                            {selectedUnit} • {year} • {semester}
                        </p>
                    )}
                </div>

                <div className="mb-4 flex flex-col sm:flex-row sm:items-center gap-3">
                    <div className="relative flex-1 max-w-md">
                        <span className="absolute inset-y-0 left-3 flex items-center text-gray-400 pointer-events-none">
                            🔍
                        </span>
                        <input
                            type="text"
                            placeholder="Search by Student ID or Name…"
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                            className="w-full pl-9 pr-4 py-2 text-sm rounded-lg
                                       border border-gray-200 dark:border-gray-700
                                       bg-white dark:bg-gray-800
                                       text-gray-800 dark:text-gray-100
                                       placeholder-gray-400 dark:placeholder-gray-500
                                       focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                    </div>

                    <span className="text-sm text-gray-400 dark:text-gray-500 whitespace-nowrap">
                        {displayed.length} student{displayed.length !== 1 ? "s" : ""}
                    </span>
                </div>

                <div
                    className="bg-white dark:bg-gray-800
                               border border-gray-200 dark:border-gray-700
                               rounded-xl shadow-sm overflow-hidden"
                >
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead>
                                <tr
                                    className="border-b border-gray-200 dark:border-gray-700
                                               bg-gray-50 dark:bg-gray-700/50"
                                >
                                    {[
                                        { label: "Student ID", field: "studentId" },
                                        { label: "Name", field: "name" },
                                        { label: "Attendance Rate", field: "attendanceRate" },
                                        { label: "Engagement Score", field: "engagementScore" },
                                    ].map(({ label, field }) => (
                                        <th
                                            key={field}
                                            onClick={() => toggleSort(field)}
                                            className="text-left px-5 py-3 font-semibold text-gray-500
                                                       dark:text-gray-400 cursor-pointer select-none
                                                       hover:text-gray-700 dark:hover:text-gray-200 whitespace-nowrap"
                                        >
                                            {label} <SortIcon field={field} />
                                        </th>
                                    ))}

                                    <th
                                        className="text-left px-5 py-3 font-semibold text-gray-500
                                                   dark:text-gray-400 whitespace-nowrap"
                                    >
                                        Actions
                                    </th>
                                </tr>
                            </thead>

                            <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                                {loading ? (
                                    <tr>
                                        <td
                                            colSpan={5}
                                            className="text-center py-16 text-gray-400 dark:text-gray-500"
                                        >
                                            Loading students...
                                        </td>
                                    </tr>
                                ) : displayed.length === 0 ? (
                                    <tr>
                                        <td
                                            colSpan={5}
                                            className="text-center py-16 text-gray-400 dark:text-gray-500"
                                        >
                                            {students.length === 0
                                                ? "Select filters and click Apply to load students."
                                                : "No students match your search."}
                                        </td>
                                    </tr>
                                ) : (
                                    displayed.map((s) => (
                                        <tr
                                            key={s.studentId}
                                            className="hover:bg-gray-50 dark:hover:bg-gray-700/40 transition-colors"
                                        >
                                            <td
                                                className="px-5 py-3 font-mono font-medium
                                                           text-gray-800 dark:text-gray-100"
                                            >
                                                {s.studentId}
                                            </td>

                                            <td className="px-5 py-3 text-gray-700 dark:text-gray-300">
                                                {s.name}
                                            </td>

                                            <td className="px-5 py-3">
                                                <span
                                                    className={`inline-flex items-center px-2.5 py-0.5
                                                                rounded-full text-xs font-semibold
                                                                ${badgeColor(Number(s.attendanceRate ?? 0))}`}
                                                >
                                                    {Number(s.attendanceRate ?? 0).toFixed(3)}
                                                </span>
                                            </td>

                                            <td className="px-5 py-3 text-gray-700 dark:text-gray-300">
                                                {Number(s.engagementScore ?? 0).toFixed(3)}
                                            </td>

                                            <td className="px-5 py-3">
                                                <div className="flex flex-wrap gap-2">
                                                    <button
                                                        onClick={() => handleViewDetail(s)}
                                                        className="text-xs font-medium px-3 py-1.5 rounded-lg
                                                                   bg-blue-50 text-blue-600
                                                                   dark:bg-blue-900/30 dark:text-blue-300
                                                                   hover:bg-blue-100 dark:hover:bg-blue-900/50"
                                                    >
                                                        View report
                                                    </button>

                                                    <button
                                                        onClick={() => handleCompare(s)}
                                                        disabled={units.length < 2}
                                                        className={`text-xs font-medium px-3 py-1.5 rounded-lg
                                                            ${
                                                                units.length < 2
                                                                    ? "bg-gray-100 text-gray-400 cursor-not-allowed dark:bg-gray-700 dark:text-gray-500"
                                                                    : "bg-purple-50 text-purple-600 dark:bg-purple-900/30 dark:text-purple-300 hover:bg-purple-100 dark:hover:bg-purple-900/50"
                                                            }`}
                                                    >
                                                        Compare units
                                                    </button>

                                                    <button
                                                        onClick={() => handleOpenFeedback(s)}
                                                        title="Add / view notes"
                                                        className="inline-flex items-center gap-1 text-xs font-medium px-3 py-1.5 rounded-lg
                                                                   bg-emerald-50 text-emerald-600
                                                                   dark:bg-emerald-900/30 dark:text-emerald-300
                                                                   hover:bg-emerald-100 dark:hover:bg-emerald-900/50"
                                                    >
                                                        <MessageCircle size={13} />
                                                        Notes
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            {/* Personalised notes/feedback modal */}
            <StudentFeedbackModal
                isOpen={feedbackModalOpen}
                onClose={() => {
                    setFeedbackModalOpen(false);
                    setFeedbackStudent(null);
                }}
                studentId={feedbackStudent?.studentId}
                studentName={feedbackStudent?.name}
                unitCode={selectedUnit}
                lecturerId={authUser?.userId || authUser?.id || ""}
            />
        </div>
    );
}

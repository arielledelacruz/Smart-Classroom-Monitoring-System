import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../api/context/AuthContext";
import { validateLogin } from "../api/controller/AuthApi";
import { ResponseStatus } from "../constants/ResponseStatus";

export default function Login() {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);

    const { login } = useAuth();
    const navigate = useNavigate();

    const handleLogin = async (e) => {
        e.preventDefault();
        setError("");
        setLoading(true);

        try {
            const data = await validateLogin(email, password);

            if (data.responseStatus === ResponseStatus.SUCCESS) {
                login(data.responseBody);
                const destination =
                    data.responseBody?.userRole === "STUDENT"
                        ? "/studentDashboard"
                        : "/lecturerDashboard";
                navigate(destination, { replace: true });
            } else {
                setError("Invalid email or password.");
            }
        } catch (err) {
            console.error("Login error:", err);
            setError("Something went wrong. Please try again.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-[#f5f6f8] flex items-center justify-center px-4">
            <div className="w-full max-w-4xl rounded-[36px] overflow-hidden shadow-[0_20px_60px_rgba(0,0,0,0.08)] border border-gray-200 bg-white grid md:grid-cols-2">

                {/* LEFT SIDE (Koala panel) */}
                <div className="flex flex-col items-center justify-center px-8 py-10 bg-[#f9fafb] relative">
                    <h1 className="text-4xl font-bold text-gray-700">
                        MCS14
                    </h1>

                    <div className="mt-8 relative flex h-44 w-44 items-center justify-center rounded-full bg-[#eef1f4]">

                        {/* leaf */}
                        <div className="absolute top-6 right-6 h-6 w-4 bg-green-300 rounded-full rotate-12" />

                        {/* head */}
                        <div className="relative h-28 w-28 rounded-[32px] bg-[#d1d5db] transition-transform hover:scale-105">

                            {/* ears */}
                            <div className="absolute -top-3 left-2 h-10 w-10 rounded-full bg-[#9ca3af]" />
                            <div className="absolute -top-3 right-2 h-10 w-10 rounded-full bg-[#9ca3af]" />

                            {/* inner ears */}
                            <div className="absolute -top-1 left-4 h-6 w-6 rounded-full bg-[#e5e7eb]" />
                            <div className="absolute -top-1 right-4 h-6 w-6 rounded-full bg-[#e5e7eb]" />

                            {/* eyes */}
                            <div className="absolute top-10 left-7 h-2.5 w-2.5 rounded-full bg-gray-700 blink" />
                            <div className="absolute top-10 right-7 h-2.5 w-2.5 rounded-full bg-gray-700 blink" style={{ animationDelay: "0.15s" }} />

                            {/* nose */}
                            <div className="absolute top-11 left-1/2 h-7 w-6 -translate-x-1/2 rounded-full bg-gray-800" />

                            {/* smile */}
                            <div className="absolute top-[64px] left-1/2 h-5 w-8 -translate-x-1/2 rounded-b-full border-2 border-t-0 border-gray-700" />

                            {/* blush */}
                            <div className="absolute top-14 left-4 h-3 w-3 rounded-full bg-pink-200 opacity-60" />
                            <div className="absolute top-14 right-4 h-3 w-3 rounded-full bg-pink-200 opacity-60" />
                        </div>

                        {/* speech bubble */}
                        <div className="absolute -left-5 top-16 rounded-full bg-white px-3 py-2 text-sm font-semibold text-gray-600 shadow">
                            hi!
                        </div>
                    </div>

                    <p className="mt-8 text-sm text-gray-500 text-center">
                        Welcome back! <br />
                        Log in to continue 🌿
                    </p>
                </div>

                {/* RIGHT SIDE (Form) */}
                <div className="flex items-center justify-center px-8 py-10">
                    <div className="w-full max-w-sm">

                        <h2 className="text-2xl font-bold text-center text-gray-700">
                            Log in
                        </h2>

                        <form onSubmit={handleLogin} className="mt-8 space-y-5">

                            <input
                                type="email"
                                placeholder="Email address"
                                className="w-full rounded-full bg-gray-100 px-5 py-3.5 text-sm text-gray-700 placeholder:text-gray-400 outline-none focus:bg-white focus:ring-2 focus:ring-[#6b8cae]"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                required
                            />

                            <input
                                type="password"
                                placeholder="Password"
                                className="w-full rounded-full border border-gray-200 px-5 py-3.5 text-sm text-gray-700 placeholder:text-gray-400 outline-none focus:border-[#6b8cae] focus:ring-2 focus:ring-[#6b8cae]"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                required
                            />

                            {error && (
                                <div className="text-sm text-red-500 text-center">
                                    {error}
                                </div>
                            )}

                            <button
                                type="submit"
                                disabled={loading}
                                className="w-full rounded-full bg-[#6b8cae] py-3.5 text-sm font-semibold tracking-[0.2em] text-white hover:bg-[#5a7996] active:scale-[0.98] transition disabled:opacity-50"
                            >
                                {loading ? "LOGGING IN..." : "LOGIN"}
                            </button>

                        </form>

                        <p className="mt-6 text-center text-xs text-gray-400">
                            Secure login for students & lecturers
                        </p>
                    </div>
                </div>

            </div>
        </div>
    );
}

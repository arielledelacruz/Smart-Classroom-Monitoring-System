export default function Settings() {
    return (
        <main className="p-6 bg-gray-100 dark:bg-gray-800 min-h-screen">
            <h1 className="text-2xl font-bold dark:text-white">Settings</h1>
            <p className="mt-4 text-gray-600 dark:text-gray-300">Placeholder for user settings (theme, accessibility, etc.).</p>
        </main>
    );
}
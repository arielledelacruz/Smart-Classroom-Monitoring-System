import { useEffect, useMemo, useState } from "react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer,
  Legend,
} from "recharts";
import {
  getEnrolledUnits,
  getAttendanceSummary,
  getUnitAttendanceDetail,
  getSessionHistory,
  getStudentAnalytics,
} from "../api/controller/StudentApi";
import { useAuth } from "../api/context/AuthContext";
import { getFeedbackByStudentAndUnit } from "../api/controller/StudentFeedbackApi";

const statusColor = {
  // ── attendance / engagement / presence ───────────────────────
  Good:             "bg-[#9ECAD6]/20 text-[#3d6f7a] border-[#9ECAD6]",
  Moderate:         "bg-[#FFF0E0] text-[#a06030] border-[#f0b070]",
  Low:              "bg-[#F5CBCB]/30 text-[#a96b6b] border-[#F5CBCB]",

  // ── trend ────────────────────────────────────────────────────
  Improving:        "bg-[#9ECAD6]/20 text-[#3d6f7a] border-[#9ECAD6]",
  Stable:           "bg-gray-100 text-gray-600 border-gray-200",
  Declining:        "bg-[#F5CBCB]/30 text-[#a96b6b] border-[#F5CBCB]",

  // ── risk ─────────────────────────────────────────────────────
  "Low Risk":       "bg-[#9ECAD6]/20 text-[#3d6f7a] border-[#9ECAD6]",
  "Medium Risk":    "bg-[#FFF0E0] text-[#a06030] border-[#f0b070]",
  "High Risk":      "bg-[#F5CBCB]/30 text-[#a96b6b] border-[#F5CBCB]",

  // ── existing (attendance table / unit cards) ──────────────────
  Present:          "bg-[#9ECAD6]/20 text-[#3d6f7a] border-[#9ECAD6]",
  Absent:           "bg-[#F5CBCB]/30 text-[#a96b6b] border-[#F5CBCB]",
  Late:             "bg-[#FFF0E0] text-[#a06030] border-[#f0b070]",
  "Early Departure":"bg-[#FFF0E0] text-[#a06030] border-[#f0b070]",
  "At Risk":        "bg-[#F5CBCB]/30 text-[#a96b6b] border-[#F5CBCB]",
  Passive:          "bg-[#FFF0E0] text-[#a06030] border-[#f0b070]",
  Engaged:          "bg-[#9ECAD6]/20 text-[#3d6f7a] border-[#9ECAD6]",
  Independent:      "bg-[#748DAE]/20 text-[#556b86] border-[#748DAE]",
  IMPROVING:        "bg-[#9ECAD6]/20 text-[#3d6f7a] border-[#9ECAD6]",
  STABLE:           "bg-gray-100 text-gray-600 border-gray-200",
  DECLINING:        "bg-[#F5CBCB]/30 text-[#a96b6b] border-[#F5CBCB]",
  N_A:              "bg-gray-100 text-gray-600 border-gray-200",
};

function Badge({ label }) {
  const safeLabel = label || "N/A";
  const colorClass =
    statusColor[safeLabel] ||
    statusColor[safeLabel.replace("/", "_")] ||
    "bg-gray-100 text-gray-700 border-gray-200";

  return (
    <span
      className={`inline-flex items-center rounded-full border px-3 py-1 text-xs font-semibold ${colorClass}`}
    >
      {safeLabel}
    </span>
  );
}

function SectionCard({ title, subtitle, action, children, className = "" }) {
  return (
    <section
      className={`rounded-xl border border-gray-200 bg-white p-5 shadow-sm dark:border-gray-700 dark:bg-gray-800 ${className}`}
    >
      <div className="mb-4 flex items-start justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
            {title}
          </h2>
          {subtitle && (
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
              {subtitle}
            </p>
          )}
        </div>
        {action}
      </div>
      {children}
    </section>
  );
}

function StatCard({ title, value, hint }) {
  return (
    <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm dark:border-gray-700 dark:bg-gray-800">
      <p className="text-sm text-gray-500 dark:text-gray-400">{title}</p>
      <div className="mt-2 flex items-end justify-between gap-3">
        <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
          {value ?? "-"}
        </h3>
        {hint && <span className="text-xs text-gray-400">{hint}</span>}
      </div>
    </div>
  );
}

function EmptyState({ title, message }) {
  return (
    <div className="rounded-xl border border-dashed border-gray-300 px-6 py-10 text-center dark:border-gray-600">
      <h3 className="text-base font-semibold text-gray-900 dark:text-white">
        {title}
      </h3>
      <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">{message}</p>
    </div>
  );
}

function LoadingBlock({ label = "Loading data..." }) {
  return (
    <div className="rounded-xl border border-gray-200 bg-white p-8 text-center text-sm text-gray-500 shadow-sm dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400">
      {label}
    </div>
  );
}

export default function StudentInterface() {
  const { authUser } = useAuth();
  const studentId = authUser?.id;
  console.log(studentId)

  const [draftFilter, setDraftFilter] = useState({ year: "2025", semester: "S1" });
  const [appliedFilter, setAppliedFilter] = useState({ year: "2025", semester: "S1" });

  const [activeTab, setActiveTab] = useState("overview");
  const [selectedUnit, setSelectedUnit] = useState(null);

  const [enrolledUnits, setEnrolledUnits] = useState([]);
  const [attendanceSummary, setAttendanceSummary] = useState(null);
  const [unitDetail, setUnitDetail] = useState(null);
  const [sessionHistory, setSessionHistory] = useState(null);
  const [analytics, setAnalytics] = useState(null);
  const [feedbackList, setFeedbackList] = useState([]);

  const [pageLoading, setPageLoading] = useState(false);
  const [detailLoading, setDetailLoading] = useState(false);
  const [error, setError] = useState("");

  const tabs = ["overview", "attendance", "engagement", "charts", "feedback"];

  const weeklyChartData = useMemo(() => {
    return (unitDetail?.weeklyBreakdown || [])
      .map((w) => ({
        week: w.week,
        attendance: w.present ? 1 : 0,
        absent: w.present ? 0 : 1,
        engagementScore: Number(((w.engagementScore || 0) * 100).toFixed(1)),
        presenceQuality: Number(((w.presenceQuality || 0) * 100).toFixed(1)),
        lateArrival: w.lateArrival ? "Yes" : "No",
        earlyDeparture: w.earlyDeparture ? "Yes" : "No",
      }))
      .sort((a, b) => {
        const numA = parseInt(String(a.week).replace("W", ""), 10);
        const numB = parseInt(String(b.week).replace("W", ""), 10);
        return numA - numB;
      });
  }, [unitDetail]);

  const selectedUnitLabel = selectedUnit
    ? `${selectedUnit.unitCode}${selectedUnit.unitName ? ` • ${selectedUnit.unitName}` : ""}`
    : "No unit selected";

  const fetchPageData = async (filter) => {
    if (!studentId) return;

    setPageLoading(true);
    setError("");
    setSelectedUnit(null);
    setEnrolledUnits([]);
    setAttendanceSummary(null);
    setUnitDetail(null);
    setSessionHistory(null);
    setAnalytics(null);
    setFeedbackList([]);

    try {
      const [unitsData, summaryData] = await Promise.all([
        getEnrolledUnits(studentId, filter.year, filter.semester),
        getAttendanceSummary(studentId, filter.year, filter.semester),
      ]);


      console.log("unitsData", unitsData);
      console.log("summaryData", summaryData);

      const units = unitsData?.enrolledUnits || [];
      setEnrolledUnits(units);
      setAttendanceSummary(summaryData);
      setSelectedUnit(units[0] || null);
    } catch (err) {
      console.error(err);
      setError("Failed to load your semester data. Please try again.");
    } finally {
      setPageLoading(false);
    }
  };

  const fetchSelectedUnitData = async () => {
    if (!studentId || !selectedUnit) return;

    setDetailLoading(true);
    setError("");

    try {
      const [detailData, sessionData, analyticsData, feedbackData] = await Promise.all([
        getUnitAttendanceDetail(
          studentId,
          selectedUnit.unitCode,
          appliedFilter.year,
          appliedFilter.semester
        ),
        getSessionHistory(
          studentId,
          selectedUnit.unitCode,
          appliedFilter.year,
          appliedFilter.semester
        ),
        getStudentAnalytics(
          studentId,
          selectedUnit.unitCode,
          appliedFilter.year,
          appliedFilter.semester
        ),
        getFeedbackByStudentAndUnit(studentId, selectedUnit.unitCode),
      ]);

      console.log("detailData", detailData);
      console.log("sessionData", sessionData);
      console.log("analyticsData", analyticsData);

      setUnitDetail(detailData);
      setSessionHistory(sessionData);
      setAnalytics(analyticsData);
      setFeedbackList(feedbackData || []);
    } catch (err) {
      console.error(err);
      setError("Failed to load the selected unit details. Please try again.");
    } finally {
      setDetailLoading(false);
    }
  };

  const handleApplyFilter = async () => {
    setAppliedFilter(draftFilter);
    await fetchPageData(draftFilter);
  };

  useEffect(() => {
    if (!studentId) return;
    fetchPageData(appliedFilter);
  }, [studentId]);

  useEffect(() => {
    if (!studentId || !selectedUnit) return;
    fetchSelectedUnitData();
  }, [studentId, selectedUnit, appliedFilter]);

  console.log("ehlo");
  console.log(analytics);

  return (
    <div className="min-h-screen bg-gray-50 p-4 md:p-6 dark:bg-gray-900">
      <div className="mx-auto max-w-7xl space-y-6">

        {/* Profile header — always visible, not a print section */}
        <section className="overflow-hidden rounded-xl border border-gray-200 bg-white p-6 shadow-sm dark:border-gray-700 dark:bg-gray-800">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex items-center gap-4">
              <div>
                <h1 className="text-2xl font-bold text-gray-900 md:text-3xl dark:text-white">
                  {authUser?.name || "Student"}
                </h1>
                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                  {authUser?.email || "No email available"}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3 lg:min-w-[420px]">
              <div className="rounded-xl bg-[#9ECAD6]/20 p-4">
                <p className="text-xs uppercase tracking-wide text-gray-500">Year</p>
                <p className="mt-1 text-lg font-semibold text-gray-900 dark:text-white">
                  {appliedFilter.year}
                </p>
              </div>
              <div className="rounded-xl bg-[#748DAE]/15 p-4">
                <p className="text-xs uppercase tracking-wide text-gray-500">Semester</p>
                <p className="mt-1 text-lg font-semibold text-gray-900 dark:text-white">
                  {appliedFilter.semester}
                </p>
              </div>
              <div className="rounded-xl bg-[#F5CBCB]/20 p-4">
                <p className="text-xs uppercase tracking-wide text-gray-500">Units</p>
                <p className="mt-1 text-lg font-semibold text-gray-900 dark:text-white">
                  {attendanceSummary?.unitSummaryList?.length ?? 0}
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Filters — hidden on print */}
        <div className="print-hide">
          <SectionCard
            title="Filters"
            subtitle="Choose the year and semester you want to view."
            action={
              <button
                onClick={handleApplyFilter}
                className="rounded-xl bg-[#748DAE] px-4 py-2 text-sm font-semibold text-white transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-50"
                disabled={pageLoading || !studentId}
              >
                {pageLoading ? "Applying..." : "Apply Filters"}
              </button>
            }
          >
            <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
              <div>
                <label className="mb-2 block text-sm font-medium text-gray-600 dark:text-gray-300">
                  Year
                </label>
                <select
                  className="w-full rounded-xl border border-gray-300 bg-white px-4 py-3 text-sm outline-none transition focus:border-[#748DAE] dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                  value={draftFilter.year}
                  onChange={(e) =>
                    setDraftFilter((prev) => ({ ...prev, year: e.target.value }))
                  }
                >
                  <option value="2024">2024</option>
                  <option value="2025">2025</option>
                </select>
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-gray-600 dark:text-gray-300">
                  Semester
                </label>
                <select
                  className="w-full rounded-xl border border-gray-300 bg-white px-4 py-3 text-sm outline-none transition focus:border-[#748DAE] dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                  value={draftFilter.semester}
                  onChange={(e) =>
                    setDraftFilter((prev) => ({ ...prev, semester: e.target.value }))
                  }
                >
                  <option value="S1">S1</option>
                  <option value="S2">S2</option>
                </select>
              </div>
            </div>
          </SectionCard>
        </div>

        {error && (
          <div className="rounded-xl border border-[#F5CBCB] bg-[#FFEAEA] px-4 py-3 text-sm text-[#a96b6b] dark:border-[#F5CBCB]/40 dark:bg-[#F5CBCB]/10 dark:text-[#f0c7c7]">
            {error}
          </div>
        )}

        {pageLoading ? (
          <LoadingBlock label="Loading semester summary..." />
        ) : !attendanceSummary ? (
          <EmptyState
            title="No semester data"
            message="Try another year or semester, then press Apply Filters to refresh the dashboard."
          />
        ) : (
          <>
            {/* PRINT SECTION: KPI summary */}
            <div className="print-kpi grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
              <StatCard
                title="Overall Attendance"
                value={`${((attendanceSummary.overallAttendanceRate || 0) * 100).toFixed(1)}%`}
              />
              <StatCard
                title="Overall Engagement"
                value={`${((attendanceSummary.overallEngagementScore || 0) * 100).toFixed(1)}%`}
              />
              <StatCard
                title="Overall Risk Score"
                value={`${((attendanceSummary.overallRiskScore || 0) * 100).toFixed(1)}%`}
              />
              <StatCard
                title="Total Units"
                value={attendanceSummary?.unitSummaryList?.length ?? 0}
              />
            </div>

            {/* PRINT SECTION: Unit cards */}
            <SectionCard
              title="All Units This Semester"
              subtitle="Choose a unit to see the analytics."
              className="print-units"
            >
              {!attendanceSummary?.unitSummaryList?.length ? (
                <EmptyState
                  title="No units found"
                  message="No enrolled units are available for the selected semester."
                />
              ) : (
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
                  {attendanceSummary.unitSummaryList.map((unit) => {
                    const isActive = selectedUnit?.unitCode === unit.unitCode;

                    return (
                      <button
                        key={unit.unitSemesterId}
                        onClick={() => {
                          const found = enrolledUnits.find(
                            (u) => u.unitCode === unit.unitCode
                          );
                          setSelectedUnit(found || null);
                        }}
                        className={`rounded-xl border p-4 text-left transition ${
                          isActive
                            ? "border-[#748DAE] bg-[#9ECAD6]/15 shadow-sm dark:border-[#9ECAD6] dark:bg-[#748DAE]/20"
                            : "border-gray-200 bg-gray-50 hover:border-gray-300 hover:bg-white dark:border-gray-700 dark:bg-gray-700/40 dark:hover:bg-gray-700"
                        }`}
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <p className="text-base font-semibold text-gray-900 dark:text-white">
                              {unit.unitCode}
                            </p>
                          </div>
                          <Badge label={unit.clusterLabel || "N/A"} />
                        </div>

                        <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                          <div className="rounded-xl bg-white p-3 dark:bg-gray-800">
                            <p className="text-gray-500 dark:text-gray-400">Attendance</p>
                            <p className="mt-1 font-semibold text-gray-900 dark:text-white">
                              {((unit.attendanceRate || 0) * 100).toFixed(1)}%
                            </p>
                          </div>
                          <div className="rounded-xl bg-white p-3 dark:bg-gray-800">
                            <p className="text-gray-500 dark:text-gray-400">Engagement</p>
                            <p className="mt-1 font-semibold text-gray-900 dark:text-white">
                              {((unit.engagementScore || 0) * 100).toFixed(1)}%
                            </p>
                          </div>
                        </div>

                        <div className="mt-3 flex flex-wrap gap-2">
                          <Badge label={unit.trend || "STABLE"} />
                          <Badge label={unit.riskScore >= 0.7 ? "At Risk" : "Engaged"} />
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </SectionCard>

            {!selectedUnit ? (
              <EmptyState
                title="No unit selected"
                message="Select a unit above to view its snapshot, insights, and detailed analytics."
              />
            ) : (
              <>
                {/* PRINT SECTION: Unit overview — compact full-width row */}
                <div className="print-overview space-y-6">
                  <SectionCard
                    title="Unit Overview"
                    subtitle={selectedUnitLabel}
                    action={analytics?.clusterLabel ? <Badge label={analytics.clusterLabel} /> : null}
                  >
                    {detailLoading ? (
                      <LoadingBlock label="Loading unit details..." />
                    ) : (
                      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 xl:grid-cols-5">
                        <StatCard
                          title="Attendance Rate"
                          value={`${((unitDetail?.attendanceRate || 0) * 100).toFixed(1)}%`}
                        />
                        <StatCard
                          title="Engagement Score"
                          value={`${((unitDetail?.engagementScore || 0) * 100).toFixed(1)}%`}
                        />
                        <StatCard
                          title="Risk Score"
                          value={`${((unitDetail?.riskScore || 0) * 100).toFixed(1)}%`}
                        />
                        <StatCard
                          title="Consecutive Absences"
                          value={
                            analytics?.consecutiveAbsences ??
                            unitDetail?.consecutiveAbsences ??
                            "-"
                          }
                        />
                        <StatCard title="Trend" value={unitDetail?.trend || "-"} />
                      </div>
                    )}
                  </SectionCard>

                  <SectionCard
                    title="Risk Reasoning & Insights"
                    subtitle="Explanation generated by the backend based on attendance, engagement, trend, risk score, and absence patterns."
                  >
  {detailLoading ? (
    <LoadingBlock label="Loading risk reasoning and insights..." />
  ) : (
    <div className="space-y-4">
      {analytics?.riskBreakdown && (
        <div className="rounded-xl border border-[#F5CBCB] bg-[#F5CBCB]/20 p-4">
          <h3 className="mb-3 text-sm font-semibold text-[#a96b6b]">
            Risk Breakdown
          </h3>

          <div className="grid grid-cols-2 gap-2 text-sm sm:grid-cols-3 xl:grid-cols-6">
            {Object.entries(analytics.riskBreakdown).map(([key, value]) => (
              <div
                key={key}
                className="flex flex-col gap-1 rounded-lg bg-white px-3 py-2 dark:bg-gray-800"
              >
                <span className="capitalize text-gray-600 dark:text-gray-300">
                  {key.replace(/([A-Z])/g, " $1")}
                </span>
                <span className="font-semibold text-gray-900 dark:text-white">
                  {(Number(value) * 100).toFixed(1)}%
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

{analytics?.explanations?.length > 0 && (
  <div className="rounded-xl border border-[#9ECAD6] bg-[#9ECAD6]/10 p-4">
    <h3 className="mb-3 text-sm font-semibold text-[#5f7f89]">
      Insight Explanation
    </h3>

    <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
      {analytics.explanations.map((item, i) => (
        <div
          key={i}
          className="rounded-xl border border-gray-200 bg-white p-4 dark:border-gray-700 dark:bg-gray-800"
        >
          {/* Header */}
          <div className="mb-3 flex items-center justify-between gap-3">
            <div>
              <h4 className="font-semibold text-gray-900 dark:text-white">
                {item.metricName}
              </h4>

              <p className="text-sm text-gray-500 dark:text-gray-400">
                Value:{" "}
                {typeof item.value === "number"
                  ? item.value <= 1
                    ? `${(item.value * 100).toFixed(1)}%`
                    : item.value
                  : item.value}
              </p>
            </div>

            <Badge label={item.status} />
          </div>

          {/* Meaning */}
          <div className="mb-3">
            <p className="text-sm text-gray-700 dark:text-gray-200">
              {item.meaning}
            </p>
          </div>

          {/* Contributing factor */}
          {item.contributingFactor && (
            <div className="mb-3 rounded-lg bg-gray-50 p-3 dark:bg-gray-700/40">
              <p className="text-xs font-semibold uppercase tracking-wide text-gray-500">
                Contributing Factor
              </p>

              <p className="mt-1 text-sm text-gray-700 dark:text-gray-200">
                {item.contributingFactor}
              </p>
            </div>
          )}

          {/* Recommendation */}
          {item.recommendationForStudent && (
            <div className="rounded-lg border border-[#9ECAD6] bg-[#9ECAD6]/10 p-3 dark:border-[#748DAE] dark:bg-[#748DAE]/10">
              <p className="text-xs font-semibold uppercase tracking-wide text-[#5f7f89]">
                Recommendation
              </p>

              <p className="mt-1 text-sm text-gray-700 dark:text-gray-200">
                {item.recommendationForStudent}
              </p>
            </div>
          )}
        </div>
      ))}
    </div>
  </div>
)}

      {analytics?.insights?.length > 0 ? (
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-gray-900 dark:text-white">
            Personalised Insights
          </h3>

          {analytics.insights.map((insight, i) => (
            <div
              key={i}
              className="rounded-xl border border-[#9ECAD6] bg-[#9ECAD6]/10 p-4 text-sm leading-6 text-gray-700 dark:border-[#748DAE] dark:bg-[#748DAE]/10 dark:text-gray-200"
            >
              {insight}
            </div>
          ))}
        </div>
      ) : (
        <EmptyState
          title="No insights available"
          message="Risk reasoning and insight explanations will appear here when available."
        />
      )}
    </div>
  )}
                  </SectionCard>
                </div>

                {/* Tab buttons — hidden on print */}
                <div className="print-hide flex flex-wrap gap-2">
                  {tabs.map((tab) => (
                    <button
                      key={tab}
                      onClick={() => setActiveTab(tab)}
                      className={`rounded-xl px-4 py-2 text-sm font-semibold capitalize transition ${
                        activeTab === tab
                          ? "bg-[#748DAE] text-white"
                          : "bg-white text-gray-600 hover:bg-gray-100 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700"
                      }`}
                    >
                      {tab}
                    </button>
                  ))}
                </div>

                {/* PRINT SECTION: Charts & tabs */}
                <div className="print-charts">
                  {activeTab === "overview" && (
                    <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
                      <SectionCard
                        title="Weekly Attendance"
                        subtitle="Quick look at weekly presence for the unit."
                      >
                        <div className="h-72">
                          <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={weeklyChartData}>
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="week" />
                              <YAxis allowDecimals={false} />
                              <Tooltip />
                              <Legend />
                              <Bar dataKey="attendance" name="Present" fill="#9ECAD6" radius={[6, 6, 0, 0]} />
                              <Bar dataKey="absent" name="Absent" fill="#F5CBCB" radius={[6, 6, 0, 0]} />
                            </BarChart>
                          </ResponsiveContainer>
                        </div>
                      </SectionCard>

                      <SectionCard
                        title="Weekly Engagement"
                        subtitle="Quick look at engagement trend across the semester."
                      >
                        <div className="h-72">
                          <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={weeklyChartData}>
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="week" />
                              <YAxis />
                              <Tooltip />
                              <Line type="monotone" dataKey="engagementScore" stroke="#748DAE" strokeWidth={3} dot={false} />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>
                      </SectionCard>
                    </div>
                  )}

                  {activeTab === "attendance" && (
                    <div className="space-y-6">
                      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                        <StatCard title="Attendance Rate" value={`${((unitDetail?.attendanceRate || 0) * 100).toFixed(1)}%`} />
                        <StatCard title="Late Arrivals" value={unitDetail?.totalLateArrival ?? "-"} />
                        <StatCard title="Early Departures" value={unitDetail?.totalEarlyDeparture ?? "-"} />
                      </div>

                      <SectionCard title="Attendance Pattern" subtitle="Weekly presence across the selected unit.">
                        <div className="h-72">
                          <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={weeklyChartData}>
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="week" />
                              <YAxis allowDecimals={false} />
                              <Tooltip />
                              <Legend />
                              <Bar dataKey="attendance" name="Present" fill="#9ECAD6" radius={[6, 6, 0, 0]} />
                              <Bar dataKey="absent" name="Absent" fill="#F5CBCB" radius={[6, 6, 0, 0]} />
                            </BarChart>
                          </ResponsiveContainer>
                        </div>
                      </SectionCard>

                      <SectionCard title="Session History" subtitle="Detailed attendance records by session.">
                        <div className="overflow-x-auto">
                          <table className="min-w-full text-sm">
                            <thead>
                              <tr className="border-b border-gray-200 text-left text-gray-500 dark:border-gray-700 dark:text-gray-400">
                                <th className="pb-3 pr-4">Week</th>
                                <th className="pb-3 pr-4">Class Type</th>
                                <th className="pb-3 pr-4">Status</th>
                                <th className="pb-3 pr-4">Late</th>
                                <th className="pb-3 pr-4">Early Departure</th>
                              </tr>
                            </thead>
                            <tbody>
                              {(sessionHistory?.sessions || []).map((s, i) => (
                                <tr key={i} className="border-b border-gray-100 dark:border-gray-700/60">
                                  <td className="py-3 pr-4 font-medium text-gray-900 dark:text-white">{s.week}</td>
                                  <td className="py-3 pr-4 text-gray-700 dark:text-gray-300">{s.classType}</td>
                                  <td className="py-3 pr-4"><Badge label={s.present ? "Present" : "Absent"} /></td>
                                  <td className="py-3 pr-4">{s.lateArrival ? <Badge label="Late" /> : <span className="text-gray-400">-</span>}</td>
                                  <td className="py-3 pr-4">{s.earlyDeparture ? <Badge label="Early Departure" /> : <span className="text-gray-400">-</span>}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </SectionCard>
                    </div>
                  )}

                  {activeTab === "engagement" && (
                    <div className="space-y-6">
                      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                        <StatCard title="Average Engagement" value={`${((unitDetail?.engagementScore || 0) * 100).toFixed(1)}%`} />
                        <StatCard title="Consecutive Absences" value={analytics?.consecutiveAbsences ?? "-"} />
                        <StatCard title="Trend" value={unitDetail?.trend || "-"} />
                      </div>

                      <SectionCard title="Engagement Trend" subtitle="Weekly engagement score over time.">
                        <div className="h-72">
                          <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={weeklyChartData}>
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="week" />
                              <YAxis />
                              <Tooltip />
                              <Line type="monotone" dataKey="engagementScore" stroke="#748DAE" strokeWidth={3} dot={false} />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>
                      </SectionCard>

                      <SectionCard title="Presence Quality" subtitle="How consistently you stayed engaged during attended sessions.">
                        <div className="h-72">
                          <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={weeklyChartData}>
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="week" />
                              <YAxis />
                              <Tooltip />
                              <Line type="monotone" dataKey="presenceQuality" stroke="#9ECAD6" strokeWidth={3} dot={false} />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>
                      </SectionCard>
                    </div>
                  )}

                  {activeTab === "charts" && (
                    <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
                      <SectionCard title="Weekly Attendance">
                        <div className="h-72">
                          <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={weeklyChartData}>
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="week" />
                              <YAxis allowDecimals={false} />
                              <Tooltip />
                              <Legend />
                              <Bar dataKey="attendance" name="Present" fill="#9ECAD6" radius={[6, 6, 0, 0]} />
                              <Bar dataKey="absent" name="Absent" fill="#F5CBCB" radius={[6, 6, 0, 0]} />
                            </BarChart>
                          </ResponsiveContainer>
                        </div>
                      </SectionCard>

                      <SectionCard title="Engagement Trend">
                        <div className="h-72">
                          <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={weeklyChartData}>
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="week" />
                              <YAxis />
                              <Tooltip />
                              <Line type="monotone" dataKey="engagementScore" stroke="#748DAE" strokeWidth={3} dot={false} />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>
                      </SectionCard>

                      <SectionCard title="Presence Quality">
                        <div className="h-72">
                          <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={weeklyChartData}>
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="week" />
                              <YAxis />
                              <Tooltip />
                              <Line type="monotone" dataKey="presenceQuality" stroke="#9ECAD6" strokeWidth={3} dot={false} />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>
                      </SectionCard>

                      <SectionCard title="Arrival and Departure Alerts">
                        <div className="space-y-3">
                          {weeklyChartData.map((w, i) => (
                            <div
                              key={i}
                              className="flex items-center justify-between rounded-xl border border-gray-200 bg-gray-50 px-4 py-3 dark:border-gray-700 dark:bg-gray-700/40"
                            >
                              <span className="font-medium text-gray-900 dark:text-white">{w.week}</span>
                              <div className="flex flex-wrap gap-2">
                                {w.lateArrival === "Yes" && <Badge label="Late" />}
                                {w.earlyDeparture === "Yes" && <Badge label="Early Departure" />}
                                {w.lateArrival === "No" && w.earlyDeparture === "No" && <Badge label="Present" />}
                              </div>
                            </div>
                          ))}
                        </div>
                      </SectionCard>
                    </div>
                  )}
                  {activeTab === "feedback" && (
                    <SectionCard
                      title="Personalised Feedback"
                      subtitle="Feedback left for you by your lecturer for this unit."
                    >
                      {detailLoading ? (
                        <LoadingBlock label="Loading feedback..." />
                      ) : feedbackList.length === 0 ? (
                        <EmptyState
                          title="No feedback yet"
                          message="Your lecturer hasn't left any personalised feedback for this unit."
                        />
                      ) : (
                        <div className="space-y-4">
                          {feedbackList.map((fb) => (
                            <div
                              key={fb.feedbackId}
                              className="rounded-xl border border-[#9ECAD6] bg-[#9ECAD6]/10 p-4 dark:border-[#748DAE] dark:bg-[#748DAE]/10"
                            >
                              <div className="mb-2 flex items-center justify-between gap-3">
                                <span className="inline-flex items-center rounded-full border border-[#748DAE] px-3 py-1 text-xs font-semibold text-[#5f7f89] dark:text-[#93a8bf]">
                                  {fb.feedbackType}
                                </span>
                                <span className="text-xs text-gray-400">
                                  {fb.updatedAt
                                    ? new Date(fb.updatedAt).toLocaleDateString() + " " + new Date(fb.updatedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
                                    : fb.createdAt
                                    ? new Date(fb.createdAt).toLocaleDateString() + " " + new Date(fb.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
                                    : ""}
                                </span>
                              </div>
                              <p className="text-sm leading-6 text-gray-700 dark:text-gray-200">
                                {fb.feedbackContent}
                              </p>
                            </div>
                          ))}
                        </div>
                      )}
                    </SectionCard>
                  )}
                </div>
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
}

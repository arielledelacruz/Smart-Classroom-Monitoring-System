
import { useMemo } from "react";

const pct = (v) => `${((v ?? 0) * 100).toFixed(1)}%`;

const diffPct = (a, b) => Math.abs(((a ?? 0) - (b ?? 0)) * 100).toFixed(1);

function higherUnit(primary, secondary, path) {
  const a = path(primary);
  const b = path(secondary);

  if (a > b) return primary.unitCode;
  if (b > a) return secondary.unitCode;
  return "Both";
}

function buildRuleBasedInsight(primary, secondary) {
  const a = primary;
  const b = secondary;

  const aAttendance = a.kpiData?.attendanceRate ?? 0;
  const bAttendance = b.kpiData?.attendanceRate ?? 0;

  const aEngagement = a.kpiData?.engagementScore ?? 0;
  const bEngagement = b.kpiData?.engagementScore ?? 0;

  const aRisk = a.kpiData?.avgRiskScore ?? 0;
  const bRisk = b.kpiData?.avgRiskScore ?? 0;

  const aHighRisk = a.riskData?.highRiskRate ?? 0;
  const bHighRisk = b.riskData?.highRiskRate ?? 0;

  const aLate = a.kpiData?.totalLateArrival ?? 0;
  const bLate = b.kpiData?.totalLateArrival ?? 0;

  const aEarly = a.kpiData?.totalEarlyDeparture ?? 0;
  const bEarly = b.kpiData?.totalEarlyDeparture ?? 0;

  const keyDifferences = [];

  if (Math.abs(aAttendance - bAttendance) >= 0.03) {
    const stronger = aAttendance > bAttendance ? a : b;
    const weaker = aAttendance > bAttendance ? b : a;

    keyDifferences.push(
      `${stronger.unitCode} shows stronger attendance at ${pct(
        Math.max(aAttendance, bAttendance)
      )}, which is ${diffPct(aAttendance, bAttendance)} percentage points higher than ${
        weaker.unitCode
      }. This suggests better consistency in class participation.`
    );
  } else {
    keyDifferences.push(
      `Both units have very similar attendance levels, with only a ${diffPct(
        aAttendance,
        bAttendance
      )} percentage point difference. This suggests attendance behaviour is broadly consistent across both classes.`
    );
  }

  if (Math.abs(aEngagement - bEngagement) >= 0.03) {
    const stronger = aEngagement > bEngagement ? a : b;
    const weaker = aEngagement > bEngagement ? b : a;

    keyDifferences.push(
      `${stronger.unitCode} has better engagement at ${pct(
        Math.max(aEngagement, bEngagement)
      )}, compared with ${weaker.unitCode}. The lower engagement in ${
        weaker.unitCode
      } may need closer monitoring, especially if attendance is also weaker.`
    );
  } else {
    keyDifferences.push(
      `Engagement levels are close between both units, meaning neither class shows a major advantage in participation quality.`
    );
  }

  if (Math.abs(aRisk - bRisk) >= 0.03 || Math.abs(aHighRisk - bHighRisk) >= 0.03) {
    const riskier = aRisk + aHighRisk > bRisk + bHighRisk ? a : b;

    keyDifferences.push(
      `${riskier.unitCode} appears to carry higher academic risk, based on its combined risk score and high-risk student percentage. This unit should be reviewed more carefully for early intervention.`
    );
  }

  const concernUnit =
    aRisk + aHighRisk + (1 - aAttendance) + (1 - aEngagement) >
    bRisk + bHighRisk + (1 - bAttendance) + (1 - bEngagement)
      ? a.unitCode
      : b.unitCode;

  const concernReason =
    concernUnit === a.unitCode
      ? `${a.unitCode} shows a relatively weaker overall profile when considering attendance, engagement, average risk score, and high-risk student rate together.`
      : `${b.unitCode} shows a relatively weaker overall profile when considering attendance, engagement, average risk score, and high-risk student rate together.`;

  const sharedIssues = [];

  if (aAttendance < 0.75 && bAttendance < 0.75) {
    sharedIssues.push(
      `Both units have attendance below 75%, suggesting that class participation may be a common issue across the selected units.`
    );
  }

  if (aEngagement < 0.7 && bEngagement < 0.7) {
    sharedIssues.push(
      `Both units show engagement below 70%, which may indicate that students are attending but not consistently participating or performing strongly.`
    );
  }

  if (aHighRisk > 0.2 && bHighRisk > 0.2) {
    sharedIssues.push(
      `Both units have a noticeable proportion of high-risk students, so early support actions should be applied across both classes rather than only one.`
    );
  }

  if (aLate > 0 && bLate > 0) {
    sharedIssues.push(
      `Late arrivals are present in both units, which may affect learning continuity and should be monitored alongside attendance trends.`
    );
  }

  if (sharedIssues.length === 0) {
    sharedIssues.push(
      `There is no major shared concern across both units. The main focus should be on the specific differences between their attendance, engagement, and risk patterns.`
    );
  }

  const weakerAttendanceUnit = higherUnit(a, b, (u) => 1 - (u.kpiData?.attendanceRate ?? 0));
  const weakerEngagementUnit = higherUnit(a, b, (u) => 1 - (u.kpiData?.engagementScore ?? 0));
  const higherRiskUnit = higherUnit(a, b, (u) => u.kpiData?.avgRiskScore ?? 0);

  const recommendations = [
    {
      unit: weakerAttendanceUnit,
      action:
        weakerAttendanceUnit === "Both"
          ? "Maintain attendance monitoring for both units and identify weeks where attendance drops."
          : `Focus on improving attendance consistency in ${weakerAttendanceUnit}, especially during weeks with visible attendance dips.`,
    },
    {
      unit: weakerEngagementUnit,
      action:
        weakerEngagementUnit === "Both"
          ? "Use more interactive class activities or formative checks to improve engagement across both units."
          : `Introduce more active learning checks in ${weakerEngagementUnit} to improve student engagement.`,
    },
    {
      unit: higherRiskUnit,
      action:
        higherRiskUnit === "Both"
          ? "Review high-risk students across both units and prioritise early academic support."
          : `Prioritise ${higherRiskUnit} for early intervention because it shows the stronger risk signal.`,
    },
    {
      unit: "Both",
      action:
        "Compare weekly trends regularly instead of relying only on overall averages, because risk may increase during specific teaching weeks.",
    },
  ];

  return {
    keyDifferences,
    concernUnit,
    concernReason,
    sharedIssues,
    recommendations,
  };
}

export default function UnitComparisonInsightsPanel({ primary, secondary }) {
  const parsed = useMemo(
    () => buildRuleBasedInsight(primary, secondary),
    [primary, secondary]
  );

  return (
    <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl shadow-sm p-6">
      <h2 className="text-xs font-semibold uppercase tracking-widest text-gray-400 dark:text-gray-500 mb-1">
        Comparison Analysis
      </h2>

{/*       <span className="inline-flex items-center gap-1 text-[11px] font-medium text-[#748DAE] bg-[#748DAE]/10 border border-[#748DAE]/30 rounded-full px-2 py-0.5 mb-4"> */}
{/*         ✦ AI-powered */}
{/*       </span> */}

      <p className="text-xs text-gray-400 dark:text-gray-500 mb-5">
        Rule-based insight generated from dashboard metrics.
      </p>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <div>
          <h3 className="text-sm font-semibold text-gray-900 dark:text-white mb-3">
            Key differences
          </h3>

          <div className="space-y-3">
            {parsed.keyDifferences.map((d, i) => (
              <div
                key={i}
                className="rounded-xl border border-[#9ECAD6] bg-[#9ECAD6]/10 p-4 text-sm leading-6 text-gray-700 dark:text-gray-200"
              >
                {d}
              </div>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-sm font-semibold text-gray-900 dark:text-white mb-3">
            Unit needing more attention
          </h3>

          <div className="rounded-xl border border-[#F5CBCB] bg-[#F5CBCB]/20 p-4 text-sm leading-6 text-gray-700 dark:text-gray-200">
            <span className="font-semibold">{parsed.concernUnit}</span> —{" "}
            {parsed.concernReason}
          </div>
        </div>

        <div>
          <h3 className="text-sm font-semibold text-gray-900 dark:text-white mb-3">
            Shared challenges
          </h3>

          <div className="space-y-3">
            {parsed.sharedIssues.map((s, i) => (
              <div
                key={i}
                className="rounded-xl border border-[#748DAE] bg-[#748DAE]/10 p-4 text-sm leading-6 text-gray-700 dark:text-gray-200"
              >
                {s}
              </div>
            ))}
          </div>
        </div>

        <div className="xl:col-span-2">
          <h3 className="text-sm font-semibold text-gray-900 dark:text-white mb-3">
            Targeted recommendations
          </h3>

          <div className="space-y-3">
            {parsed.recommendations.map((rec, i) => {
              const isA = rec.unit === primary.unitCode;
              const isBoth = rec.unit === "Both";
              const accent = isA ? "#9ECAD6" : isBoth ? "#aaa" : "#748DAE";

              return (
                <div
                  key={i}
                  className="rounded-xl p-4 text-sm leading-6 text-gray-700 dark:text-gray-200"
                  style={{
                    border: `1px solid ${accent}40`,
                    background: `${accent}12`,
                  }}
                >
                  <span
                    className="block text-[11px] font-semibold uppercase tracking-wide mb-1"
                    style={{ color: accent }}
                  >
                    {rec.unit}
                  </span>

                  {rec.action}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
